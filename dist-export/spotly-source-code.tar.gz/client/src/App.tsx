import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ScrollProvider } from "@/contexts/scroll-context";
import { AuthGuardProvider } from "@/contexts/auth-guard";
import NotFound from "@/pages/not-found";

import SplashPage from "@/pages/splash";
import LandingPage from "@/pages/landing";
import AuthPage from "@/pages/auth";
import RegisterPage from "@/pages/register";
import RoleSelectionPage from "@/pages/role-selection";

import CustomerHome from "@/pages/customer/home";
import CustomerBookings from "@/pages/customer/bookings";
import CustomerAccount from "@/pages/customer/account";
import CustomerContacts from "@/pages/customer/contacts";
import CustomerLocationSetup from "@/pages/customer/location-setup";
import BookingFlow from "@/pages/customer/booking-flow";

import WorkerHome from "@/pages/worker/home";
import WorkerAccount from "@/pages/worker/account";
import WorkerLocationSetup from "@/pages/worker/location-setup";

import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminServices from "@/pages/admin/services";
import AdminCustomers from "@/pages/admin/customers";
import AdminWorkers from "@/pages/admin/workers";
import AdminBookings from "@/pages/admin/bookings";
import AdminDisclaimers from "@/pages/admin/disclaimers";
import AdminSettings from "@/pages/admin/settings";
import AdminPincodes from "@/pages/admin/pincodes";

import DisclaimerPage from "@/pages/disclaimer";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/splash" component={SplashPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/auth/otp" component={AuthPage} />
      <Route path="/register" component={RegisterPage} />
      <Route path="/role-selection" component={RoleSelectionPage} />
      <Route path="/disclaimer" component={DisclaimerPage} />
      
      {/* Customer Routes */}
      <Route path="/customer/location-setup" component={CustomerLocationSetup} />
      <Route path="/customer/home" component={CustomerHome} />
      <Route path="/customer/bookings" component={CustomerBookings} />
      <Route path="/customer/account" component={CustomerAccount} />
      <Route path="/customer/contacts" component={CustomerContacts} />
      <Route path="/customer/book/:id" component={BookingFlow} />

      {/* Worker Routes */}
      <Route path="/worker/service-selection">{() => { window.location.href = "/worker/home"; return null; }}</Route>
      <Route path="/worker/location-setup" component={WorkerLocationSetup} />
      <Route path="/worker/home" component={WorkerHome} />
      <Route path="/worker/account" component={WorkerAccount} />

      {/* Admin Routes */}
      <Route path="/admin" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/services" component={AdminServices} />
      <Route path="/admin/pincodes" component={AdminPincodes} />
      <Route path="/admin/customers" component={AdminCustomers} />
      <Route path="/admin/workers" component={AdminWorkers} />
      <Route path="/admin/bookings" component={AdminBookings} />
      <Route path="/admin/disclaimers" component={AdminDisclaimers} />
      <Route path="/admin/settings" component={AdminSettings} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ScrollProvider>
          <AuthGuardProvider>
            <Toaster />
            <Router />
          </AuthGuardProvider>
        </ScrollProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
