import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import { Bell, Phone, MapPin, Check, Calendar, User, Loader2, ChevronDown, Map, Navigation, X, Car, Bike, Rocket, Mail, Plus, ParkingCircle, Trash2, Pencil, Clock, ThumbsUp, IndianRupee, Wallet, TrendingUp, BadgeDollarSign, CircleDollarSign, Banknote, Sparkles, ArrowRight, Star } from "lucide-react";
import { BANNERS } from "@/lib/mock-data";
import { getApiUrl } from "@/lib/api-config";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import React, { useRef, useState, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { useScroll } from "@/contexts/scroll-context";
import { useAuthGuard } from "@/contexts/auth-guard";

interface City {
  id: string;
  name: string;
  state: string;
  isActive: boolean;
  displayOrder: number;
}

interface Service {
  id: string;
  name: string;
  icon: string;
  description: string;
  isActive: boolean;
  displayOrder: number;
}

const formatServiceName = (name: string): string => {
  return name.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
};


export default function CustomerHome() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { requireLogin } = useAuthGuard();
  const [showCustomerCare, setShowCustomerCare] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [userName, setUserName] = useState(localStorage.getItem("userName") || "");
  const [selectedCity, setSelectedCity] = useState<string>("");
  const [showLocationPopup, setShowLocationPopup] = useState(false);
  const [isLocatingGPS, setIsLocatingGPS] = useState(false);
  const [pendingCity, setPendingCity] = useState<string>("");
  const [cityNotServed, setCityNotServed] = useState(false);
  const [detectedCityName, setDetectedCityName] = useState("");
  const [showCitySelector, setShowCitySelector] = useState(false);
  const [comingSoonMode, setComingSoonMode] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<Array<{id: string; type: string; title: string; message: string; createdAt: string; isRead: boolean}>>([]);
  const unreadCount = notifications.filter(n => !n.isRead).length;
  const [supportPhone, setSupportPhone] = useState("+91 98765 43210");
  const [supportEmail, setSupportEmail] = useState("info@spotlyindia.org");
  const [adVideoUrl, setAdVideoUrl] = useState("");
  const [adVideoEnabled, setAdVideoEnabled] = useState(true);

  // Function to fetch notifications
  const fetchNotifications = async () => {
    const userId = localStorage.getItem("userId");
    if (userId) {
      try {
        const response = await fetch(getApiUrl(`/api/notifications/${userId}`));
        if (response.ok) {
          const data = await response.json();
          setNotifications(data.notifications || []);
        }
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    }
  };

  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'booking_accepted': return '✅';
      case 'booking_cancelled': return '❌';
      case 'worker_assigned': return '👷';
      case 'new_job': return '📋';
      case 'broadcast': return '📢';
      default: return '🔔';
    }
  };

  // Format timestamp in human-readable format
  const formatTimestamp = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hr ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  // State for clearing notifications
  const [isClearingNotifications, setIsClearingNotifications] = useState(false);

  // Clear all notifications
  const handleClearNotifications = async () => {
    const userId = localStorage.getItem("userId");
    if (!userId) return;
    
    setIsClearingNotifications(true);
    try {
      const response = await fetch(getApiUrl(`/api/notifications/${userId}/clear`), {
        method: 'DELETE'
      });
      if (response.ok) {
        setNotifications([]);
      }
    } catch (error) {
      console.error("Failed to clear notifications:", error);
    } finally {
      setIsClearingNotifications(false);
    }
  };

  // Fetch cities from active pincodes
  const { data: pincodesData } = useQuery({
    queryKey: ["pincodes"],
    queryFn: async () => {
      const res = await fetch(getApiUrl("/api/pincodes"));
      if (!res.ok) throw new Error("Failed to fetch pincodes");
      return res.json();
    },
  });

  // Get unique cities from active pincodes only
  const cities: City[] = useMemo(() => {
    const pincodes = pincodesData?.pincodes || [];
    const activePincodes = pincodes.filter((p: any) => p.isActive);
    const uniqueCities: Record<string, City> = {};
    
    activePincodes.forEach((p: any) => {
      if (p.cityId && p.cityName && !uniqueCities[p.cityId]) {
        uniqueCities[p.cityId] = {
          id: p.cityId,
          name: p.cityName,
          state: "",
          isActive: true,
          displayOrder: p.displayOrder || 0
        };
      }
    });
    
    return Object.values(uniqueCities);
  }, [pincodesData?.pincodes]);

  // Fetch services from API
  const { data: servicesData } = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const res = await fetch(getApiUrl("/api/services"));
      if (!res.ok) throw new Error("Failed to fetch services");
      return res.json();
    },
  });

  const services: Service[] = servicesData?.services || [];

  const userId = localStorage.getItem("userId");
  const PAGE_SIZE = 20;
  const [myBookings, setMyBookings] = useState<any[]>([]);
  const [totalBookings, setTotalBookings] = useState(0);
  const [bookingsPage, setBookingsPage] = useState(0);
  const [isLoadingBookings, setIsLoadingBookings] = useState(true);
  const [isLoadingMoreBookings, setIsLoadingMoreBookings] = useState(false);

  const fetchMyBookings = async (reset = false) => {
    if (!userId) { setIsLoadingBookings(false); return; }
    try {
      const offset = reset ? 0 : bookingsPage * PAGE_SIZE;
      const res = await fetch(getApiUrl(`/api/bookings/customer/${userId}?limit=${PAGE_SIZE}&offset=${offset}`));
      if (!res.ok) throw new Error("Failed to fetch bookings");
      const data = await res.json();
      if (reset) {
        setMyBookings(data.bookings || []);
        setBookingsPage(1);
      } else {
        setMyBookings(prev => [...prev, ...(data.bookings || [])]);
        setBookingsPage(prev => prev + 1);
      }
      setTotalBookings(data.total ?? (data.bookings?.length || 0));
    } catch (error) {
      console.error("Failed to fetch bookings:", error);
    }
    setIsLoadingBookings(false);
    setIsLoadingMoreBookings(false);
  };

  const loadMoreBookings = async () => {
    if (isLoadingMoreBookings || myBookings.length >= totalBookings) return;
    setIsLoadingMoreBookings(true);
    const offset = bookingsPage * PAGE_SIZE;
    try {
      const res = await fetch(getApiUrl(`/api/bookings/customer/${userId}?limit=${PAGE_SIZE}&offset=${offset}`));
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      if ((data.bookings || []).length > 0) {
        setMyBookings(prev => [...prev, ...(data.bookings || [])]);
        setBookingsPage(prev => prev + 1);
      }
    } catch {}
    setIsLoadingMoreBookings(false);
  };

  useEffect(() => {
    fetchMyBookings(true);
  }, [userId]);
  const [interestCounts, setInterestCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    const fetchInterestCounts = async () => {
      if (myBookings.length === 0) return;
      try {
        const ids = myBookings.map((b: any) => b.id).join(",");
        const res = await fetch(getApiUrl(`/api/interests/counts?ids=${ids}`));
        if (res.ok) {
          const data = await res.json();
          setInterestCounts(data.counts || {});
        }
      } catch {}
    };
    fetchInterestCounts();
  }, [myBookings.length]);

  const handleDeleteSpace = async (bookingId: string) => {
    setIsDeleting(true);
    try {
      const response = await fetch(getApiUrl(`/api/bookings/${bookingId}`), { method: "DELETE" });
      if (response.ok) {
        setMyBookings(prev => prev.filter((b: any) => b.id !== bookingId));
        setTotalBookings(prev => prev - 1);
      }
    } catch (error) {
      console.error("Failed to delete space:", error);
    }
    setIsDeleting(false);
    setDeleteConfirm(null);
  };

  const getParkingIcon = (serviceName: string) => {
    const name = serviceName.toLowerCase();
    if (name.includes("car") && name.includes("bike")) return "both";
    if (name.includes("bike")) return "bike";
    return "car";
  };

  useEffect(() => {
    // Role protection - redirect workers to their home
    const userRole = localStorage.getItem("userRole");
    if (userRole === "worker") {
      setLocation("/worker/home");
      return;
    }
    
    // Fetch user profile and premium status from API
    const fetchUserProfile = async () => {
      const userId = localStorage.getItem("userId");
      if (userId) {
        try {
          const response = await fetch(getApiUrl(`/api/users/${userId}`));
          if (response.ok) {
            const data = await response.json();
            if (data.name) {
              setUserName(data.name);
            }
          }
        } catch (error) {
          console.error("Failed to fetch user profile:", error);
          // Fallback to localStorage
          const name = localStorage.getItem("userName");
          if (name) setUserName(name);
        }
      }
    };
    
    fetchUserProfile();
    
    // Fetch coming soon mode setting
    const fetchComingSoonMode = async () => {
      try {
        const response = await fetch(getApiUrl("/api/settings/coming_soon_mode"));
        if (response.ok) {
          const data = await response.json();
          setComingSoonMode(data.setting?.value === "true");
        } else {
          setComingSoonMode(false);
        }
      } catch (error) {
        setComingSoonMode(false);
      }
    };
    
    // Fetch support phone and email from settings
    const fetchSupportSettings = async () => {
      try {
        const [phoneRes, emailRes] = await Promise.all([
          fetch(getApiUrl("/api/settings/support_phone")),
          fetch(getApiUrl("/api/settings/support_email"))
        ]);
        if (phoneRes.ok) {
          const data = await phoneRes.json();
          if (data.setting?.value) setSupportPhone(data.setting.value);
        }
        if (emailRes.ok) {
          const data = await emailRes.json();
          if (data.setting?.value) setSupportEmail(data.setting.value);
        }
      } catch (error) {
        console.error("Failed to fetch support settings:", error);
      }
    };
    fetchSupportSettings();
    fetchComingSoonMode();
    
    const fetchAdVideo = async () => {
      try {
        const [urlRes, enabledRes] = await Promise.all([
          fetch(getApiUrl("/api/settings/ad_video_url")),
          fetch(getApiUrl("/api/settings/ad_video_enabled"))
        ]);
        if (urlRes.ok) {
          const data = await urlRes.json();
          if (data.setting?.value) setAdVideoUrl(data.setting.value);
        }
        if (enabledRes.ok) {
          const data = await enabledRes.json();
          if (data.setting?.value !== undefined) setAdVideoEnabled(data.setting.value === "true");
        }
      } catch (error) {}
    };
    fetchAdVideo();
    
    // Initial fetch of notifications
    fetchNotifications();
    
    // Sync city to database
    const syncCityToDatabase = async () => {
      const sessionToken = localStorage.getItem("sessionToken");
      const savedCityName = localStorage.getItem("selectedServiceAreaName") || localStorage.getItem("userDetectedCity");
      if (sessionToken && savedCityName) {
        try {
          await fetch(getApiUrl("/api/users/me"), {
            method: "PATCH",
            headers: { 
              "Content-Type": "application/json",
              "Authorization": `Bearer ${sessionToken}`
            },
            body: JSON.stringify({ city: savedCityName }),
          });
        } catch (e) {
          console.error("Failed to sync user city:", e);
        }
      }
    };
    syncCityToDatabase();
  }, [setLocation]);
  
  // Refetch notifications when the sheet opens
  useEffect(() => {
    if (notificationsOpen) {
      fetchNotifications();
    }
  }, [notificationsOpen]);

  // Auto-detect city from GPS location or use saved location from signup
  useEffect(() => {
    if (cities.length === 0) return;
    
    // Check if city already saved
    const savedCity = localStorage.getItem("selectedCity");
    if (savedCity && cities.find(c => c.id === savedCity)) {
      setSelectedCity(savedCity);
      return;
    }
    
    // Check for auto-detected city from location setup
    const detectedCityName = localStorage.getItem("userDetectedCity");
    if (detectedCityName) {
      const matchedCity = cities.find(c => 
        c.name.toLowerCase() === detectedCityName.toLowerCase() ||
        detectedCityName.toLowerCase().includes(c.name.toLowerCase()) ||
        c.name.toLowerCase().includes(detectedCityName.toLowerCase())
      );
      if (matchedCity) {
        setSelectedCity(matchedCity.id);
        localStorage.setItem("selectedCity", matchedCity.id);
        return;
      }
    }
    
    // No city selected - user can select from the location popup
    // Don't auto-default to any city
  }, [cities]);

  const [locationNotAvailable, setLocationNotAvailable] = useState(false);
  const [detectedLocationName, setDetectedLocationName] = useState("");

  const handleLocateMe = () => {
    setIsLocatingGPS(true);
    setLocationNotAvailable(false);
    setDetectedLocationName("");
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude, accuracy } = position.coords;
          console.log(`Location accuracy: ${accuracy}m, Lat: ${latitude}, Lng: ${longitude}`);
          
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1&accept-language=en`
            );
            const data = await response.json();
            const cityName = data.address?.city || data.address?.town || data.address?.village || data.address?.county || data.address?.state_district || "";
            const stateName = data.address?.state || "";
            const displayLocation = cityName || "Unknown location";
            
            setDetectedLocationName(displayLocation);
            
            // Normalize city names for matching
            const normalizeCity = (name: string) => {
              const normalized = name.toLowerCase().trim();
              if (normalized.includes("bengaluru") || normalized.includes("bangalore")) return "bangalore";
              if (normalized.includes("mumbai") || normalized.includes("bombay")) return "mumbai";
              if (normalized.includes("chennai") || normalized.includes("madras")) return "chennai";
              if (normalized.includes("kolkata") || normalized.includes("calcutta")) return "kolkata";
              if (normalized.includes("delhi") || normalized.includes("new delhi")) return "delhi";
              return normalized;
            };
            
            const normalizedDetected = cityName ? normalizeCity(cityName) : "";
            const matchedCity = cities.find(c => {
              const normalizedAdmin = normalizeCity(c.name);
              return normalizedAdmin === normalizedDetected ||
                normalizedDetected.includes(normalizedAdmin) ||
                normalizedAdmin.includes(normalizedDetected);
            });
            
            if (matchedCity) {
              setPendingCity(matchedCity.id);
              setLocationNotAvailable(false);
            } else {
              // City not in service area
              setPendingCity("");
              setLocationNotAvailable(true);
            }
          } catch (error) {
            console.error("Error getting location:", error);
            setLocationNotAvailable(true);
            setDetectedLocationName("Unable to detect location");
          } finally {
            setIsLocatingGPS(false);
          }
        },
        (error) => {
          console.error("Geolocation error:", error);
          setIsLocatingGPS(false);
          setLocationNotAvailable(true);
          setDetectedLocationName("Location access denied");
        },
        {
          enableHighAccuracy: true,
          timeout: 30000,
          maximumAge: 0
        }
      );
    } else {
      setIsLocatingGPS(false);
      setLocationNotAvailable(true);
      setDetectedLocationName("Location not supported");
    }
  };

  const handleLocationOk = () => {
    if (pendingCity) {
      handleCityChange(pendingCity);
      // Clear the "city not served" message when user manually selects a city
      setCityNotServed(false);
    }
    setShowLocationPopup(false);
  };

  const handleLocationClear = () => {
    setPendingCity("");
    setSelectedCity("");
    localStorage.removeItem("selectedCity");
    setShowLocationPopup(false);
  };

  const handleCityChange = (cityId: string) => {
    setSelectedCity(cityId);
    localStorage.setItem("selectedCity", cityId);
    setCityNotServed(false);
  };

  const selectedCityName = cities.find(c => c.id === selectedCity)?.name || "Select City";

  const plugin = useRef(
    Autoplay({ delay: 3000, stopOnInteraction: true })
  );

  const { scrollY } = useScroll();
  const isScrolled = scrollY > 80;

  // Full-screen Coming Soon page without header/footer
  if (comingSoonMode === true) {
    return (
      <div className="min-h-screen bg-white flex flex-col relative overflow-hidden">
        {/* Top curved purple section */}
        <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] pt-16 pb-32 px-6 relative">
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-white rounded-t-[3rem]"></div>
          
          {/* Decorative circles */}
          <div className="absolute top-10 right-10 w-20 h-20 border-2 border-white/20 rounded-full"></div>
          <div className="absolute top-24 right-6 w-8 h-8 bg-white/10 rounded-full"></div>
          <div className="absolute top-8 left-8 w-4 h-4 bg-yellow-400 rounded-full animate-pulse"></div>
          
          {/* Header */}
          <div className="text-center relative z-10">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              <span className="text-white/90 text-xs font-medium">Coming Soon</span>
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Spotly</h1>
            <p className="text-purple-200 text-sm">Car & Bike Parking</p>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1 px-6 -mt-8 relative z-10">
          {/* Rocket card */}
          <div className="bg-white rounded-3xl shadow-xl shadow-purple-200/50 p-8 mb-6 border border-purple-100">
            <div className="flex items-center justify-center mb-6">
              <div className="relative">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-purple-50 rounded-full flex items-center justify-center">
                  <Rocket className="w-12 h-12 text-primary" />
                </div>
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                  <Sparkles className="w-3 h-3 text-yellow-800" />
                </div>
              </div>
            </div>
            <h2 className="text-xl font-bold text-gray-900 text-center mb-3">
              We're Launching Soon!
            </h2>
            <p className="text-gray-500 text-center text-sm leading-relaxed">
              Find and list car & bike parking spaces in your city. Safe, convenient, and affordable parking solutions coming soon.
            </p>
          </div>
          
          {/* Services preview */}
          <div className="mb-6">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4 text-center">What's Coming</p>
            <div className="flex justify-center gap-3">
              <div className="flex flex-col items-center">
                <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center mb-2">
                  <Car className="w-7 h-7 text-green-600" />
                </div>
                <span className="text-xs text-gray-600">Car Parking</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-2">
                  <Bike className="w-7 h-7 text-blue-600" />
                </div>
                <span className="text-xs text-gray-600">Bike Parking</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center mb-2">
                  <ParkingCircle className="w-7 h-7 text-purple-600" />
                </div>
                <span className="text-xs text-gray-600">Car & Bike</span>
              </div>
            </div>
          </div>
          
          {/* Bottom message */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-5 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Bell className="w-4 h-4 text-white" />
              </div>
            </div>
            <p className="text-gray-700 font-medium text-sm">Stay Tuned!</p>
            <p className="text-gray-500 text-xs mt-1">We'll notify you when we launch</p>
          </div>
        </div>
        
        {/* Bottom decoration */}
        <div className="h-6 bg-gradient-to-t from-purple-50 to-transparent"></div>
      </div>
    );
  }

  const userCity = localStorage.getItem("userDetectedCity") || localStorage.getItem("selectedServiceAreaName") || "";
  const userState = localStorage.getItem("userState") || "";
  const locationLabel = userCity || "Location not set";

  return (
    <MobileLayout showNav userType="customer">
      <div className="pb-8 bg-neutral-50 min-h-full">
        {/* Sticky Header - appears on scroll */}
        <div 
          className={`fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-4 py-3 shadow-lg transition-all duration-300 ${
            isScrolled ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
          }`}
        >
          <div className="flex items-center justify-between max-w-md mx-auto">
            <div>
              <p className="text-white font-semibold text-sm">{userName}</p>
              <p className="text-purple-200 text-xs">Space Provider</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowCustomerCare(true)}
                className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10"
                data-testid="button-care-sticky"
              >
                <Phone size={16} className="drop-shadow-sm" />
              </button>
              <button
                onClick={() => setNotificationsOpen(true)}
                className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10 relative"
                data-testid="button-notifications-sticky"
              >
                <Bell size={16} className="drop-shadow-sm" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full ring-2 ring-white flex items-center justify-center text-[10px] font-bold">{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </button>
            </div>
          </div>
        </div>
        
        {/* Gradient Header */}
        <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-6 pt-6 pb-12 relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-pink-500/30 to-purple-500/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-indigo-500/25 to-blue-500/15 rounded-full blur-2xl -translate-x-1/2 translate-y-1/2"></div>
          <div className="absolute top-12 left-1/3 w-20 h-20 bg-pink-400/20 rounded-full blur-2xl"></div>
          <div className="absolute top-6 right-1/4 w-12 h-12 bg-yellow-400/15 rounded-full blur-xl"></div>
          <div className="absolute bottom-8 right-8 w-16 h-16 bg-cyan-400/15 rounded-full blur-xl"></div>
          {/* Subtle pattern overlay */}
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 80%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize: '60px 60px' }}></div>
          
          {/* Header content */}
          <div className="relative z-10 flex items-start justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-white drop-shadow-sm">{userName}</h2>
              <div className="flex items-center gap-1.5 mt-1" data-testid="text-location-label-customer">
                <MapPin size={13} className="text-purple-200/80" />
                <p className="text-purple-200/90 text-sm font-medium tracking-wide">{locationLabel}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setShowCustomerCare(true)}
                className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10"
                data-testid="button-customer-care-home"
              >
                <Phone size={18} className="drop-shadow-sm" />
              </button>
              <button 
                onClick={() => setNotificationsOpen(true)}
                className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10 relative"
                data-testid="button-notifications-home"
              >
                <Bell size={18} className="drop-shadow-sm" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full ring-2 ring-white flex items-center justify-center text-[10px] font-bold">{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </button>
              <button 
                onClick={() => setLocation("/customer/contacts")}
                className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10"
                data-testid="button-account-home"
              >
                <User size={18} className="drop-shadow-sm" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Main content area with overlap */}
        <div className="px-6 -mt-4 relative z-10">
          {/* Quick Stats */}
          <div className="bg-white rounded-2xl shadow-lg shadow-purple-100/50 p-4 mb-6 border border-purple-50">
            <div className="flex items-center justify-around">
              <div className="text-center">
                <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-1">
                  <Rocket className="w-5 h-5 text-green-600" />
                </div>
                <p className="text-xs font-semibold text-gray-700">Instant</p>
                <p className="text-[10px] text-gray-400">Connect</p>
              </div>
              <div className="w-px h-10 bg-gray-200"></div>
              <div className="text-center">
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-1">
                  <MapPin className="w-5 h-5 text-blue-600" />
                </div>
                <p className="text-xs font-semibold text-gray-700">Nearby</p>
                <p className="text-[10px] text-gray-400">Seekers</p>
              </div>
              <div className="w-px h-10 bg-gray-200"></div>
              <div className="text-center">
                <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-1">
                  <ParkingCircle className="w-5 h-5 text-orange-600" />
                </div>
                <p className="text-xs font-semibold text-gray-700">24/7</p>
                <p className="text-[10px] text-gray-400">Parking</p>
              </div>
            </div>
          </div>
          
          {/* Hidden city selector for form functionality */}
          <div className="hidden">
            <Select value={selectedCity} onValueChange={handleCityChange}>
              <SelectTrigger data-testid="select-city">
                <SelectValue placeholder="Select your city" />
              </SelectTrigger>
              <SelectContent>
                {cities.map((city) => (
                  <SelectItem key={city.id} value={city.id} data-testid={`city-option-${city.id}`}>
                    {city.name}, {city.state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

            {/* City Not Served Message */}
            {cityNotServed && (
              <div className="px-6 mb-8">
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="w-8 h-8 text-amber-600" />
                  </div>
                  <h3 className="text-lg font-bold text-amber-800 mb-2">
                    Service Not Available
                  </h3>
                  <p className="text-amber-700 mb-4">
                    We don't provide services in <span className="font-semibold">{detectedCityName || "your location"}</span> yet. We are expanding soon!
                  </p>
                  <p className="text-sm text-amber-600 mb-4">
                    Currently available in: {cities.slice(0, 5).map(c => c.name).join(", ")}{cities.length > 5 ? ` +${cities.length - 5} more` : ""}
                  </p>
                  <button
                    onClick={() => setShowCitySelector(true)}
                    className="bg-primary text-white font-semibold px-6 py-3 rounded-xl hover:bg-primary/90 transition-colors"
                    data-testid="button-select-city-unsupported"
                  >
                    Select a Nearby City
                  </button>
                </div>
              </div>
            )}

        {/* My Space Lists */}
        {!cityNotServed && <div className="px-6 mb-8">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#4f0073] to-[#7b1fa2] flex items-center justify-center shadow-sm">
                <ParkingCircle size={16} className="text-white" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">My Space Lists</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm">{myBookings.length}</span>
            </div>
          </div>
          <div className="relative h-[3px] rounded-full bg-purple-100 mb-5 overflow-hidden">
            <motion.div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#4f0073] via-[#e040fb] to-[#4f0073] rounded-full"
              style={{ width: "40%" }}
              animate={{ x: ["-100%", "350%"] }}
              transition={{ duration: 2.5, repeat: 2, ease: "easeInOut" }}
            />
          </div>

          {myBookings.length === 0 ? (
            <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="relative overflow-hidden bg-gradient-to-b from-purple-50/80 via-white to-purple-50/40 rounded-3xl border border-purple-100/80 py-10 px-6"
              style={{ boxShadow: "0 4px 24px rgba(79, 0, 115, 0.08)" }}
            >
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-[#4f0073]/5 rounded-full blur-3xl -translate-y-1/2" />

              <div className="relative flex flex-col items-center">
                <div className="relative mb-6">
                  <motion.div
                    className="absolute inset-0 rounded-full bg-[#4f0073]/8"
                    animate={{ scale: [1, 2.5], opacity: [0.4, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
                    style={{ width: 80, height: 80, top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
                  />
                  <motion.div
                    className="absolute inset-0 rounded-full bg-[#4f0073]/6"
                    animate={{ scale: [1, 2.5], opacity: [0.3, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeOut", delay: 0.7 }}
                    style={{ width: 80, height: 80, top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
                  />
                  <div className="relative flex items-center gap-3">
                    <motion.div
                      initial={{ scale: 0, rotate: -20 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.1, type: "spring" }}
                      className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4f0073] to-[#9c27b0] flex items-center justify-center shadow-lg"
                      style={{ boxShadow: "0 6px 20px rgba(79, 0, 115, 0.3)" }}
                    >
                      <Car size={28} className="text-white" />
                    </motion.div>
                    <motion.div
                      initial={{ scale: 0, rotate: 20 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring" }}
                      className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#7b1fa2] to-[#e040fb] flex items-center justify-center shadow-lg"
                      style={{ boxShadow: "0 6px 20px rgba(123, 31, 162, 0.3)" }}
                    >
                      <Bike size={28} className="text-white" />
                    </motion.div>
                  </div>
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-center mb-6"
                >
                  <div className="inline-flex items-center gap-1.5 bg-amber-50 border border-amber-200 text-amber-700 rounded-full px-3 py-1 mb-3">
                    <Sparkles size={12} />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Get Started</span>
                  </div>
                  <h4 className="text-xl font-extrabold text-neutral-900 mb-2 leading-tight" data-testid="text-no-spaces">
                    No Spaces Posted Yet
                  </h4>
                  <p className="text-neutral-500 text-[13px] leading-relaxed max-w-[280px] mx-auto">
                    Your parking spot could be earning you money right now. List it and connect with seekers nearby!
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="w-full max-w-[280px] space-y-3"
                >
                  <motion.button
                    onClick={() => { if (!requireLogin("post a parking space")) return; setLocation("/customer/bookings"); }}
                    className="w-full flex items-center justify-center gap-2.5 px-6 py-3.5 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl transition-all duration-300"
                    style={{ boxShadow: "0 6px 24px rgba(79, 0, 115, 0.35)" }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    data-testid="button-add-space"
                  >
                    <Plus size={20} className="bg-white/20 rounded-lg p-0.5" />
                    <span>Add New Space</span>
                    <ArrowRight size={16} />
                  </motion.button>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="flex items-center gap-4 mt-6 pt-5 border-t border-purple-100 w-full max-w-[280px]"
                >
                  {[
                    { icon: Clock, text: "Quick Setup" },
                    { icon: IndianRupee, text: "Earn Rent" },
                    { icon: TrendingUp, text: "High Demand" },
                  ].map((item, i) => (
                    <div key={item.text} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-8 h-8 rounded-xl bg-purple-100 flex items-center justify-center">
                        <item.icon size={14} className="text-[#4f0073]" />
                      </div>
                      <span className="text-[10px] font-semibold text-neutral-600">{item.text}</span>
                    </div>
                  ))}
                </motion.div>
              </div>
            </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, type: "spring", stiffness: 100 }}
                className="mt-5 w-full"
              >
                <div className="relative overflow-hidden rounded-3xl" style={{ boxShadow: "0 8px 32px rgba(79, 0, 115, 0.25), 0 2px 8px rgba(0,0,0,0.1)" }}>
                  <div className="absolute inset-0 bg-gradient-to-br from-[#4f0073] via-[#7b1fa2] to-[#e040fb]" />
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-3xl -translate-y-8 translate-x-8" />
                    <div className="absolute bottom-0 left-0 w-24 h-24 bg-yellow-300 rounded-full blur-2xl translate-y-6 -translate-x-4" />
                    <div className="absolute top-1/2 right-1/4 w-16 h-16 bg-pink-300 rounded-full blur-2xl" />
                  </div>

                  <motion.div className="absolute top-3 right-3 opacity-15" animate={{ rotate: [0, 15, 0], scale: [1, 1.1, 1] }} transition={{ duration: 4, repeat: Infinity }}>
                    <Banknote size={50} className="text-white" />
                  </motion.div>
                  <motion.div className="absolute bottom-8 left-3 opacity-10" animate={{ rotate: [0, -10, 0] }} transition={{ duration: 3, repeat: Infinity, delay: 1 }}>
                    <CircleDollarSign size={30} className="text-yellow-200" />
                  </motion.div>

                  <div className="relative z-10 p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <motion.div
                        className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30"
                        animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                        transition={{ duration: 3, repeat: Infinity }}
                      >
                        <IndianRupee size={20} className="text-yellow-300" />
                      </motion.div>
                      <div className="flex items-center gap-1.5">
                        <Sparkles size={14} className="text-yellow-300" />
                        <span className="text-[10px] font-semibold text-yellow-200 uppercase tracking-wider">Start Earning Today</span>
                      </div>
                    </div>

                    <h3 className="text-[17px] font-extrabold text-white leading-snug mb-1.5">
                      Turn Your Empty Space<br />Into <span className="text-yellow-300">Monthly Income!</span>
                    </h3>
                    <p className="text-[11px] text-white/75 leading-relaxed mb-4">
                      Snap a photo of your unused parking spot, post it in seconds, and let seekers find you. It's that simple!
                    </p>

                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {[
                        { icon: Wallet, label: "Earn Rent", sub: "Monthly" },
                        { icon: TrendingUp, label: "High Demand", sub: "Growing" },
                        { icon: Star, label: "Easy Setup", sub: "2 Minutes" },
                      ].map((item, i) => (
                        <motion.div
                          key={item.label}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.7 + i * 0.1 }}
                          className="bg-white/15 backdrop-blur-sm rounded-xl p-2.5 text-center border border-white/10"
                        >
                          <item.icon size={16} className="text-yellow-300 mx-auto mb-1" />
                          <p className="text-[10px] font-bold text-white leading-tight">{item.label}</p>
                          <p className="text-[9px] text-white/60">{item.sub}</p>
                        </motion.div>
                      ))}
                    </div>

                    <motion.div
                      className="flex items-center justify-center gap-2 bg-yellow-400 hover:bg-yellow-300 text-[#4f0073] rounded-xl py-2.5 px-4 cursor-pointer transition-colors"
                      whileTap={{ scale: 0.97 }}
                      onClick={() => setLocation("/customer/bookings")}
                      style={{ boxShadow: "0 4px 16px rgba(250, 204, 21, 0.4)" }}
                    >
                      <Plus size={16} className="font-bold" />
                      <span className="text-xs font-extrabold">Post Your First Space</span>
                      <ArrowRight size={14} />
                    </motion.div>
                  </div>

                  <div className="relative z-10 bg-white/10 backdrop-blur-sm px-5 py-2.5 border-t border-white/10">
                    <div className="flex items-center justify-center gap-1.5">
                      <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 1.5, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full bg-green-400" />
                      <span className="text-[10px] text-white/80 font-medium">People are actively searching for parking near you</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </>
          ) : (
            <div className="space-y-5 py-1 px-1">
              {myBookings.map((booking: any) => {
                const iconType = getParkingIcon(booking.serviceName);
                const rentMatch = booking.comments?.match(/Rent: ₹(\d+)/);
                const rentAmount = rentMatch ? rentMatch[1] : null;
                const descMatch = booking.comments?.match(/\| (.+)/);
                const descText = descMatch ? descMatch[1] : null;
                const postedDate = new Date(booking.bookedAt);
                const locationShort = booking.location?.split(",").slice(0, 2).join(",").trim() || booking.location;

                return (
                  <div
                    key={booking.id}
                    className="bg-white rounded-2xl border border-neutral-200"
                    style={{ boxShadow: "0 6px 24px rgba(0, 0, 0, 0.15), 0 2px 10px rgba(79, 0, 115, 0.1)" }}
                    data-testid={`space-card-${booking.id}`}
                  >
                    <div className="flex p-4 gap-4 relative">
                      {(interestCounts[booking.id] || 0) > 0 && (
                        <div className="absolute top-3 right-3 bg-primary text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm" data-testid={`badge-interest-${booking.id}`}>
                          <ThumbsUp size={10} className="fill-white" />
                          {interestCounts[booking.id]} interested
                        </div>
                      )}
                      <div className="flex flex-col items-center justify-center gap-1 min-w-[56px]">
                        {(iconType === "car" || iconType === "both") && (
                          <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                            <Car size={24} className="text-[#4f0073]" />
                          </div>
                        )}
                        {(iconType === "bike" || iconType === "both") && (
                          <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                            <Bike size={24} className="text-[#4f0073]" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-neutral-900 text-sm mb-1">{booking.serviceName}</h4>
                        <div className="flex items-center gap-1.5 text-neutral-500 text-xs mb-1">
                          <MapPin size={12} />
                          <span className="truncate">{locationShort}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-neutral-400 text-xs mb-1">
                          <Clock size={12} />
                          <span>{postedDate.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })} at {postedDate.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}</span>
                        </div>
                        {rentAmount && (
                          <span className="inline-block mt-1 px-2.5 py-0.5 bg-green-50 text-green-700 text-xs font-bold rounded-full">₹{rentAmount}/month</span>
                        )}
                      </div>
                    </div>
                    <div className="flex border-t border-neutral-100 rounded-b-2xl overflow-hidden">
                      <button
                        onClick={() => setLocation(`/customer/bookings?edit=${booking.id}`)}
                        className="flex-1 flex items-center justify-center gap-2 py-3 bg-[#4f0073] text-white text-xs font-bold hover:bg-[#3d0059] transition-colors"
                        data-testid={`button-edit-space-${booking.id}`}
                      >
                        <Pencil size={14} />
                        Edit Space
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(booking.id)}
                        className="flex-1 flex items-center justify-center gap-2 py-3 bg-red-600 text-white text-xs font-bold hover:bg-red-700 transition-colors"
                        data-testid={`button-delete-space-${booking.id}`}
                      >
                        <Trash2 size={14} />
                        Delete Space
                      </button>
                    </div>
                  </div>
                );
              })}
              {myBookings.length < totalBookings && (
                <div className="flex flex-col items-center gap-2 py-5">
                  <p className="text-xs text-neutral-400">
                    Showing {myBookings.length} of {totalBookings} spaces
                  </p>
                  <button
                    onClick={() => { vibrate(); loadMoreBookings(); }}
                    disabled={isLoadingMoreBookings}
                    className="flex items-center gap-2.5 px-7 py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white text-sm font-bold rounded-full shadow-xl shadow-[#4f0073]/25 active:scale-95 transition-all disabled:opacity-60"
                    data-testid="button-load-more-bookings"
                  >
                    {isLoadingMoreBookings ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Loading more spaces...
                      </>
                    ) : (
                      <>
                        <ParkingSquare size={16} />
                        Load More Spaces
                        <ChevronDown size={14} />
                      </>
                    )}
                  </button>
                </div>
              )}
              <button
                onClick={() => setLocation("/customer/bookings")}
                className="w-full flex items-center justify-center gap-2 py-3.5 border-2 border-dashed border-purple-300 text-[#4f0073] font-semibold rounded-2xl hover:bg-purple-50 active:scale-95 transition-all"
                data-testid="button-add-more-space"
              >
                <Plus size={18} />
                Add New Space
              </button>

              <div className="mt-4">
                <div className="relative overflow-hidden bg-gradient-to-br from-green-50 via-emerald-50 to-amber-50 rounded-2xl border border-green-200/60 p-4" style={{ boxShadow: "0 4px 16px rgba(16, 185, 129, 0.12)" }}>
                  <div className="absolute top-1 right-1 opacity-10">
                    <Banknote size={50} className="text-green-700 rotate-12" />
                  </div>
                  <div className="flex items-start gap-3 relative z-10">
                    <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-md">
                      <IndianRupee size={20} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-green-800 mb-0.5 leading-tight">
                        More Spaces = More Earnings!
                      </p>
                      <p className="text-[11px] text-green-700/80 leading-relaxed">
                        Have another empty spot? Post it now and double your monthly rental income. Seekers are waiting!
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2.5 mt-2.5 pt-2.5 border-t border-green-200/50 relative z-10">
                    <div className="flex items-center gap-1 text-[11px] text-green-700 font-medium">
                      <Wallet size={12} className="text-green-600" />
                      <span>Earn Monthly</span>
                    </div>
                    <div className="w-1 h-1 rounded-full bg-green-400" />
                    <div className="flex items-center gap-1 text-[11px] text-green-700 font-medium">
                      <TrendingUp size={12} className="text-green-600" />
                      <span>High Demand</span>
                    </div>
                    <div className="w-1 h-1 rounded-full bg-green-400" />
                    <div className="flex items-center gap-1 text-[11px] text-green-700 font-medium">
                      <BadgeDollarSign size={12} className="text-green-600" />
                      <span>Quick Setup</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>}

        {/* Marketing Banners */}
        <div className="px-6 mb-8">
           <h3 className="text-base font-bold text-neutral-900 mb-4">Special Offers</h3>
           <Carousel
            plugins={[plugin.current]}
            className="w-full"
            opts={{
              align: "start",
              loop: true,
            }}
          >
            <CarouselContent>
              {BANNERS.map((banner) => (
                <CarouselItem key={banner.id}>
                  <div className="relative aspect-[2/1] rounded-3xl overflow-hidden">
                    <img src={banner.image} alt={banner.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                       <h4 className="text-white font-bold text-lg">{banner.title}</h4>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
          
          {adVideoUrl && adVideoEnabled && (
            <div className="mt-6">
              <div className="relative aspect-[2/1] rounded-3xl overflow-hidden shadow-lg">
                <video
                  src={adVideoUrl}
                  className="w-full h-full object-cover"
                  autoPlay
                  loop
                  muted
                  playsInline
                />
              </div>
            </div>
          )}

          {/* Tagline */}
          <p className="text-left font-bold text-neutral-500/30 mt-6" style={{ fontSize: '30px' }}>
            India's Quickest Way to Find Car & Bike Parking Spaces
          </p>
        </div>

        {/* Notifications Sheet */}
        <Sheet open={notificationsOpen} onOpenChange={setNotificationsOpen}>
          <SheetContent side="right" className="w-[70vw] p-0 bg-white shadow-2xl border-none">
            <SheetHeader className="border-b p-4 sticky top-0 bg-white flex flex-row items-center justify-between">
              <SheetTitle className="text-lg font-bold">Notifications</SheetTitle>
              {notifications.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearNotifications}
                  disabled={isClearingNotifications}
                  className="text-red-500 hover:text-red-600 hover:bg-red-50 text-xs"
                  data-testid="button-clear-notifications-home"
                >
                  {isClearingNotifications ? "Clearing..." : "Clear All"}
                </Button>
              )}
            </SheetHeader>
            
            <div className="overflow-y-auto h-[calc(100vh-100px)]">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-neutral-500">
                  <Bell className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No notifications yet</p>
                </div>
              ) : (
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 cursor-pointer transition-colors hover:bg-neutral-50 ${
                        !notification.isRead ? "bg-primary/5" : ""
                      }`}
                      data-testid={`notification-home-${notification.id}`}
                    >
                      <div className="flex gap-3 items-start">
                        <div className="text-xl mt-1">{getNotificationIcon(notification.type)}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-sm text-neutral-900">
                              {notification.title}
                            </h3>
                            {!notification.isRead && (
                              <span className="w-2 h-2 bg-primary rounded-full"></span>
                            )}
                          </div>
                          <p className="text-xs text-neutral-600 mt-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-xs text-neutral-400 mt-2">
                            {formatTimestamp(notification.createdAt)}
                          </p>
                        </div>
                        {!notification.isRead && (
                          <Check className="w-4 h-4 text-primary flex-shrink-0 mt-1" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>

      </div>

      <AnimatePresence>
        {showCustomerCare && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowCustomerCare(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <Phone size={32} className="text-primary" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-1">Help & Support</h3>
              <p className="text-neutral-500 text-xs mb-5">We're here to help!</p>
              <div className="space-y-2 text-left">
                <a href={`tel:${supportPhone.replace(/\s/g, '')}`} className="flex items-center gap-3 p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors" data-testid="link-call-support-home">
                  <div className="w-9 h-9 bg-green-500 rounded-full flex items-center justify-center"><Phone className="w-4 h-4 text-white" /></div>
                  <div className="text-left"><p className="font-semibold text-neutral-900 text-sm">Call Us</p><p className="text-xs text-neutral-600">{supportPhone}</p></div>
                </a>
                <a href={`mailto:${supportEmail}`} className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors" data-testid="link-email-support-home">
                  <div className="w-9 h-9 bg-blue-500 rounded-full flex items-center justify-center"><Mail className="w-4 h-4 text-white" /></div>
                  <div className="text-left"><p className="font-semibold text-neutral-900 text-sm">Email Us</p><p className="text-xs text-neutral-600">{supportEmail}</p></div>
                </a>
              </div>
              <button onClick={() => setShowCustomerCare(false)} className="mt-5 w-full py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors" data-testid="button-close-care-home">Close</button>
            </motion.div>
          </motion.div>
        )}

        {showCitySelector && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowCitySelector(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 shadow-2xl max-w-md w-full max-h-[80vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <MapPin size={32} className="text-primary" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 text-center mb-1">Select Your City</h3>
              <p className="text-neutral-500 text-xs text-center mb-4">Choose a city where you'd like to find seekers</p>
              <div className="flex-1 overflow-y-auto space-y-2">
                {cities.map((city) => (
                  <button key={city.id} onClick={() => { handleCityChange(city.id); setShowCitySelector(false); }} className="w-full flex items-center gap-3 p-3 rounded-xl border border-neutral-200 hover:border-primary hover:bg-primary/5 transition-all" data-testid={`city-select-${city.id}`}>
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-neutral-900">{city.name}</p>
                      <p className="text-xs text-neutral-500">{city.state}</p>
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}

        {deleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
            onClick={() => setDeleteConfirm(null)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                <Trash2 size={32} className="text-red-500" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Delete This Space?</h3>
              <p className="text-neutral-500 text-sm mb-6">This action cannot be undone. Your space listing will be permanently removed.</p>
              <div className="flex gap-3">
                <button
                  onClick={() => setDeleteConfirm(null)}
                  className="flex-1 py-3 bg-neutral-100 text-neutral-700 font-bold rounded-2xl hover:bg-neutral-200 transition-colors"
                  data-testid="button-keep-space"
                >
                  Keep
                </button>
                <button
                  onClick={() => handleDeleteSpace(deleteConfirm)}
                  disabled={isDeleting}
                  className="flex-1 py-3 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  data-testid="button-confirm-delete"
                >
                  {isDeleting ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </MobileLayout>
  );
}
