import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Phone, Mail, Play, X } from "lucide-react";
import { vibrate } from "@/lib/vibrate";
import { getApiUrl } from "@/lib/api-config";
import logo from "@assets/spotly_logo_transparent.png";
import phoneHand from "@assets/Landing-page-banner-1_1778892826031.png";

export default function LandingPage() {
  const [, setLocation] = useLocation();
  const [videoUrl, setVideoUrl] = useState("");
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [showVideo, setShowVideo] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    const userRole = localStorage.getItem("userRole");
    if (userId && userRole) {
      if (userRole === "customer") setLocation("/customer/home");
      else if (userRole === "worker") setLocation("/worker/home");
    }
  }, [setLocation]);

  useEffect(() => {
    (async () => {
      try {
        const [urlRes, enabledRes] = await Promise.all([
          fetch(getApiUrl("/api/settings/ad_video_url")),
          fetch(getApiUrl("/api/settings/ad_video_enabled")),
        ]);
        if (urlRes.ok) {
          const d = await urlRes.json();
          if (d.setting?.value) setVideoUrl(d.setting.value);
        }
        if (enabledRes.ok) {
          const d = await enabledRes.json();
          if (d.setting?.value !== undefined) setVideoEnabled(d.setting.value === "true");
        }
      } catch (e) {
        console.error("Failed to load demo video:", e);
      }
    })();
  }, []);

  const handleGetStarted = () => {
    vibrate();
    sessionStorage.setItem("fromLanding", "1");
    setLocation("/splash");
  };

  const handlePlayVideo = () => {
    vibrate();
    setShowVideo(true);
  };

  const handleCloseVideo = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
    setShowVideo(false);
  };

  const showPlayBtn = videoEnabled && !!videoUrl;

  return (
    <div
      className="fixed inset-0 w-screen h-screen overflow-hidden flex flex-col text-white"
      style={{
        background:
          "radial-gradient(ellipse at 50% 25%, rgba(147,51,234,0.55) 0%, rgba(79,0,115,0.95) 55%, #2e0044 100%)",
      }}
      data-testid="page-landing"
    >
      <div
        className="absolute inset-0 opacity-[0.07] pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
          backgroundSize: "16px 16px",
        }}
      />

      <header className="flex items-center justify-between px-6 md:px-12 pt-4 md:pt-6 pb-2 relative z-10">
        <img src={logo} alt="Spotly" className="h-9 md:h-12 w-auto" data-testid="img-logo" />
        <span className="text-xs md:text-sm font-medium text-white/70 tracking-wide">Car & Bike Parking</span>
      </header>

      <div className="flex-1 w-full max-w-6xl mx-auto px-6 md:px-12 py-4 md:py-6 flex flex-col md:flex-row items-center md:items-center justify-between gap-4 md:gap-8 relative z-10 min-h-0">
        <div className="flex-1 flex flex-col items-start gap-4 md:gap-6 max-w-xl">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="text-left"
          >
            <h1 className="text-3xl md:text-5xl font-extrabold leading-tight" data-testid="text-headline">
              The easiest way to find<br /> parking nearby
            </h1>
            <p className="text-sm md:text-lg text-white/80 mt-3 md:mt-4">
              Connecting parking owners with seekers — verified, simple, monthly.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.18 }}
            className="flex items-center gap-3 md:gap-4 flex-wrap"
          >
            <button
              onClick={handleGetStarted}
              className="px-8 md:px-12 py-3 md:py-4 bg-yellow-400 hover:bg-yellow-300 text-[#2e0044] font-extrabold rounded-2xl shadow-xl shadow-black/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 text-sm md:text-base"
              data-testid="button-get-started"
            >
              Get Started
              <ArrowRight className="w-4 h-4 md:w-5 md:h-5" />
            </button>

            {showPlayBtn && (
              <button
                onClick={handlePlayVideo}
                className="group flex items-center gap-2 px-6 md:px-8 py-3 md:py-4 bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/30 rounded-2xl text-white font-semibold text-sm md:text-base transition-all active:scale-[0.98] shadow-lg"
                data-testid="button-play-demo"
                aria-label="Play demo video"
              >
                <span className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-yellow-400 text-[#2e0044] flex items-center justify-center group-hover:scale-110 transition-transform shrink-0">
                  <Play className="w-3 h-3 md:w-3.5 md:h-3.5 fill-current ml-px" />
                </span>
                How It Works
              </button>
            )}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex-shrink-0 flex items-center justify-center h-full max-h-full"
        >
          <img
            src={phoneHand}
            alt="Spotly app preview"
            className="h-[55vh] md:h-full md:max-h-[115vh] w-auto object-contain drop-shadow-2xl scale-125 md:scale-[1.55] origin-right"
            data-testid="img-phone-hand"
          />
        </motion.div>
      </div>

      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 px-6 md:px-12 py-2.5 md:py-4 text-[10px] md:text-xs leading-snug text-white/85 relative z-10" data-testid="footer-landing">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-1 md:gap-4">
          <div>
            <p className="mb-1">
              139/81, Unit 101 Oxford Towers, HAL Old Airport Road, Kodihalli, Bengaluru, Karnataka – 560008.
            </p>
            <div className="flex flex-wrap gap-x-4 gap-y-0.5">
              <a href="tel:+919742545584" className="flex items-center gap-1 hover:text-yellow-300" data-testid="link-mobile">
                <Phone className="w-2.5 h-2.5 md:w-3 md:h-3" /> +91-97425 45584
              </a>
              <a href="mailto:info@spotlyindia.org" className="flex items-center gap-1 hover:text-yellow-300" data-testid="link-email">
                <Mail className="w-2.5 h-2.5 md:w-3 md:h-3" /> info@spotlyindia.org
              </a>
            </div>
          </div>
          <p className="text-white/65 text-[9px] md:text-[11px] md:text-right">
            ©2026 Spotly. All Rights Reserved. Powered by Zeboto.
          </p>
        </div>
      </footer>

      <AnimatePresence>
        {showVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={handleCloseVideo}
            data-testid="modal-video"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="relative w-full max-w-4xl bg-black rounded-2xl overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={handleCloseVideo}
                className="absolute top-3 right-3 z-10 w-10 h-10 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center transition-colors"
                data-testid="button-close-video"
                aria-label="Close video"
              >
                <X className="w-5 h-5" />
              </button>
              <video
                ref={videoRef}
                src={videoUrl}
                controls
                autoPlay
                playsInline
                className="w-full h-auto max-h-[80vh] bg-black"
                data-testid="video-demo"
              >
                Your browser does not support the video tag.
              </video>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
