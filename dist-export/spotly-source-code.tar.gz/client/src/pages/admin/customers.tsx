import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { adminFetch } from "@/lib/api-config";
import { Label } from "@/components/ui/label";
import { 
  Globe,
  MapPin, 
  Users, 
  LogOut,
  TrendingUp,
  Calendar,
  Briefcase,
  User,
  Phone,
  Search,
  Settings,
  Download,
  ParkingSquare,
  Pencil,
  Trash2,
  X,
  Save,
  Loader2
} from "lucide-react";
import logo from "@assets/spotly_logo_transparent.png";
import * as XLSX from "xlsx";

interface UserData {
  id: string;
  name: string;
  email: string | null;
  mobile: string;
  role: string;
  city?: string | null;
  createdAt?: string | null;
  spacesPosted?: number;
}

interface City {
  id: string;
  name: string;
  isActive: boolean;
}

export default function AdminCustomers() {
  const [, setLocation] = useLocation();
  const [customers, setCustomers] = useState<UserData[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [editName, setEditName] = useState("");
  const [editCity, setEditCity] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);

  useEffect(() => {
    const isAdmin = localStorage.getItem("isAdmin");
    if (!isAdmin) {
      setLocation("/admin");
      return;
    }
    fetchCustomers();
    fetchCities();
  }, []);

  const fetchCities = async () => {
    try {
      const res = await adminFetch("/api/admin/cities");
      if (res.ok) {
        const data = await res.json();
        setCities(data.cities || []);
      }
    } catch (error) {
      console.error("Failed to fetch cities:", error);
    }
  };

  const fetchCustomers = async () => {
    try {
      const res = await adminFetch("/api/admin/users");
      if (res.ok) {
        const data = await res.json();
        const customerList = (data.users || []).filter((u: UserData) => u.role === "customer");
        setCustomers(customerList);
      }
    } catch (error) {
      console.error("Failed to fetch space providers:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminLevel");
    setLocation("/admin");
  };

  const handleEdit = (customer: UserData) => {
    setEditingUser(customer);
    setEditName(customer.name);
    setEditCity(customer.city || "");
  };

  const handleSaveEdit = async () => {
    if (!editingUser) return;
    setIsSaving(true);
    try {
      const res = await adminFetch(`/api/admin/users/${editingUser.id}`, {
        method: "PATCH",
        body: JSON.stringify({ name: editName, city: editCity }),
      });
      if (res.ok) {
        setCustomers(prev => prev.map(c => c.id === editingUser.id ? { ...c, name: editName, city: editCity } : c));
        setEditingUser(null);
      }
    } catch (error) {
      console.error("Failed to update user:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/users/${id}`, { method: "DELETE" });
      if (res.ok) {
        setCustomers(prev => prev.filter(c => c.id !== id));
        setDeleteUserId(null);
      }
    } catch (error) {
      console.error("Failed to delete user:", error);
    }
  };

  const filteredCustomers = customers.filter(customer => {
    const query = searchQuery.toLowerCase();
    const matchesSearch = (
      customer.name.toLowerCase().includes(query) ||
      customer.mobile.includes(query)
    );
    const matchesCity = selectedCity === "all" || customer.city === selectedCity;
    return matchesSearch && matchesCity;
  }).sort((a, b) => {
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return dateB - dateA;
  });

  const exportToExcel = () => {
    const exportData = filteredCustomers.map(customer => ({
      "Name": customer.name,
      "Mobile": customer.mobile,
      "City": customer.city || "-",
      "Registration Date": customer.createdAt
        ? new Date(customer.createdAt).toLocaleDateString()
        : "-",
      "Spaces Posted": customer.spacesPosted ?? 0
    }));
    
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Space Providers");
    XLSX.writeFile(wb, `space_providers_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const navItems = [
    { label: "Dashboard", path: "/admin/dashboard", icon: TrendingUp },
    { label: "Parking Types", path: "/admin/services", icon: Briefcase },
    { label: "Service States", path: "/admin/pincodes", icon: Globe },
    { label: "Space Providers", path: "/admin/customers", icon: Users, active: true },
    { label: "Space Seekers", path: "/admin/workers", icon: Users },
    { label: "Parking Spaces", path: "/admin/bookings", icon: Calendar },
    { label: "Settings", path: "/admin/settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-neutral-100">
      <header className="bg-primary text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Spotly" className="h-9 w-auto object-contain" />
            <div>
              <h1 className="text-xl font-bold">Spotly Admin</h1>
              <p className="text-sm text-white/70">Space Provider Management</p>
            </div>
          </div>
          <Button
            variant="ghost"
            onClick={() => setShowLogoutConfirm(true)}
            className="text-white hover:bg-white/20"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-sm mx-4 shadow-xl">
            <h3 className="text-lg font-bold text-neutral-900 mb-2">Confirm Logout</h3>
            <p className="text-neutral-600 mb-6">Are you sure you want to logout from the admin panel?</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowLogoutConfirm(false)}>
                Cancel
              </Button>
              <Button className="flex-1 bg-red-600 hover:bg-red-700" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto p-6">
        <nav className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {navItems.map((item) => (
            <Button
              key={item.path}
              variant={item.active ? "default" : "outline"}
              onClick={() => setLocation(item.path)}
              className="rounded-full whitespace-nowrap"
              data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <item.icon size={16} className="mr-2" />
              {item.label}
            </Button>
          ))}
        </nav>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <h2 className="text-xl font-bold" data-testid="text-page-title">Space Providers ({filteredCustomers.length})</h2>
          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="h-10 pl-10 pr-8 rounded-lg border border-neutral-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 appearance-none cursor-pointer min-w-[160px]"
                data-testid="select-city-filter"
              >
                <option value="all">All Cities</option>
                {cities.filter(c => c.isActive).map((city) => (
                  <option key={city.id} value={city.name}>{city.name}</option>
                ))}
              </select>
            </div>
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
              <Input
                placeholder="Search by name or mobile..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-providers"
              />
            </div>
            <Button 
              onClick={exportToExcel}
              variant="outline"
              className="whitespace-nowrap"
              data-testid="button-export-providers"
            >
              <Download size={16} className="mr-2" />
              Export Excel
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredCustomers.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center">
            <Users className="w-16 h-16 mx-auto mb-4 text-neutral-300" />
            <h3 className="text-lg font-bold text-neutral-900 mb-2" data-testid="text-empty-title">No Space Providers Found</h3>
            <p className="text-neutral-500" data-testid="text-empty-message">
              {searchQuery ? "No space providers match your search" : "No space providers registered yet"}
            </p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                State-wise Breakdown
<thead className="bg-neutral-50 border-b">
                  <tr>
                    <th className="text-left p-4 font-semibold text-neutral-600">Space Provider</th>
                    <th className="text-left p-4 font-semibold text-neutral-600">Mobile</th>
                    <th className="text-left p-4 font-semibold text-neutral-600">City</th>
                    <th className="text-left p-4 font-semibold text-neutral-600">Registration Date</th>
                    <th className="text-left p-4 font-semibold text-neutral-600">Spaces Posted</th>
                    <th className="text-center p-4 font-semibold text-neutral-600">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredCustomers.map((customer) => (
                    <tr key={customer.id} className="hover:bg-neutral-50" data-testid={`row-provider-${customer.id}`}>
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <User className="text-blue-600" size={18} />
                          </div>
                          <div>
                            <p className="font-medium text-neutral-900" data-testid={`text-provider-name-${customer.id}`}>{customer.name}</p>
                            <p className="text-xs text-neutral-500">ID: {customer.id.slice(0, 8)}...</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2 text-neutral-600">
                          <Phone size={14} />
                          <span data-testid={`text-provider-mobile-${customer.id}`}>{customer.mobile}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        {customer.city ? (
                          <div className="flex items-center gap-2 text-neutral-600">
                            <MapPin size={14} />
                            <span data-testid={`text-provider-city-${customer.id}`}>{customer.city}</span>
                          </div>
                        ) : (
                          <span className="text-neutral-400">-</span>
                        )}
                      </td>
                      <td className="p-4 text-neutral-600 text-sm" data-testid={`text-provider-date-${customer.id}`}>
                        {customer.createdAt
                          ? new Date(customer.createdAt).toLocaleDateString()
                          : "-"
                        }
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2 text-neutral-600">
                          <ParkingSquare size={14} />
                          <span data-testid={`text-provider-spaces-${customer.id}`}>{customer.spacesPosted ?? 0}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEdit(customer)}
                            className="w-8 h-8 rounded-lg border border-blue-300 bg-white text-blue-600 flex items-center justify-center hover:bg-blue-50 transition-colors"
                            data-testid={`button-edit-provider-${customer.id}`}
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            onClick={() => setDeleteUserId(customer.id)}
                            className="w-8 h-8 rounded-lg border border-red-300 bg-white text-red-600 flex items-center justify-center hover:bg-red-50 transition-colors"
                            data-testid={`button-delete-provider-${customer.id}`}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {editingUser && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl p-6 max-w-md mx-4 shadow-xl w-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-neutral-900">Edit Space Provider</h3>
                <button onClick={() => setEditingUser(null)} className="w-8 h-8 rounded-full bg-neutral-100 flex items-center justify-center hover:bg-neutral-200">
                  <X size={16} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-neutral-700">Name</Label>
                  <Input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="mt-1"
                    data-testid="input-edit-name"
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-700">Mobile</Label>
                  <Input
                    value={editingUser.mobile}
                    disabled
                    className="mt-1 bg-neutral-50"
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-700">City</Label>
                  <Input
                    value={editCity}
                    onChange={(e) => setEditCity(e.target.value)}
                    className="mt-1"
                    data-testid="input-edit-city"
                  />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <Button variant="outline" className="flex-1" onClick={() => setEditingUser(null)}>
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-[#4f0073] hover:bg-[#3d0059]"
                  onClick={handleSaveEdit}
                  disabled={isSaving}
                  data-testid="button-save-edit"
                >
                  {isSaving ? <Loader2 size={16} className="animate-spin mr-2" /> : <Save size={16} className="mr-2" />}
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        )}

        {deleteUserId && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl p-6 max-w-sm mx-4 shadow-xl">
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Delete Space Provider</h3>
              <p className="text-neutral-600 mb-6">Are you sure you want to delete this space provider? This action cannot be undone.</p>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => setDeleteUserId(null)}>
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-red-600 hover:bg-red-700"
                  onClick={() => handleDelete(deleteUserId)}
                  data-testid="button-confirm-delete"
                >
                  <Trash2 size={16} className="mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
