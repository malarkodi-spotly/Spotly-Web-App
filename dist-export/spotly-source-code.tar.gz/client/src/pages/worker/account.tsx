import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import { LogOut, Loader2, Share2, Trash2, FileText, User, ChevronRight, HelpCircle, Phone, Mail, CheckCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import { getApiUrl } from "@/lib/api-config";
import { motion, AnimatePresence } from "framer-motion";
import { isGuest } from "@/lib/guest";
import GuestAccountView from "@/components/guest-account-view";

export default function WorkerAccount() {
  const [, setLocation] = useLocation();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);
  const [showHelpSupport, setShowHelpSupport] = useState(false);
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [appVersion, setAppVersion] = useState("1.0.0");
  const [supportPhone, setSupportPhone] = useState("+91 9742545584");
  const [supportEmail, setSupportEmail] = useState("info@spotlyindia.org");

  useEffect(() => {
    const fetchProfiles = async () => {
      const userId = localStorage.getItem("userId");
      if (userId) {
        try {
          const userResponse = await fetch(getApiUrl(`/api/users/${userId}`));
          if (userResponse.ok) {
            const userData = await userResponse.json();
            setName(userData.name || "");
            setEmail(userData.email || "");
            setMobile(userData.mobile || "");
          }
        } catch (error) {
          console.error("Failed to fetch profiles:", error);
        }
      }
      setIsLoading(false);
    };
    
    const fetchSettings = async () => {
      try {
        const [versionRes, phoneRes, emailRes] = await Promise.all([
          fetch(getApiUrl("/api/settings/app_version")),
          fetch(getApiUrl("/api/settings/support_phone")),
          fetch(getApiUrl("/api/settings/support_email"))
        ]);
        if (versionRes.ok) {
          const data = await versionRes.json();
          if (data.setting?.value) setAppVersion(data.setting.value);
        }
        if (phoneRes.ok) {
          const data = await phoneRes.json();
          if (data.setting?.value) setSupportPhone(data.setting.value);
        }
        if (emailRes.ok) {
          const data = await emailRes.json();
          if (data.setting?.value) setSupportEmail(data.setting.value);
        }
      } catch (error) {
        console.error("Failed to fetch settings:", error);
      }
    };
    
    fetchProfiles();
    fetchSettings();
  }, []);

  const handleLogoutConfirm = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userMobile");
    localStorage.removeItem("userRole");
    localStorage.removeItem("sessionToken");
    localStorage.removeItem("workerAge");
    localStorage.removeItem("workerGender");
    localStorage.removeItem("workerServices");
    localStorage.removeItem("workerConditions");
    localStorage.removeItem("isNewRegistration");
    localStorage.removeItem("disclaimerAccepted");
    setShowLogoutConfirm(false);
    setLocation("/role-selection");
  };

  const handleDeleteAccount = async () => {
    const userId = localStorage.getItem("userId");
    const sessionToken = localStorage.getItem("sessionToken");
    if (!userId) return;
    
    if (!sessionToken) {
      alert("Session expired. Please log in again to delete your account.");
      localStorage.clear();
      setLocation("/role-selection");
      return;
    }
    
    setIsDeleting(true);
    try {
      const response = await fetch(getApiUrl(`/api/users/${userId}`), {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${sessionToken}` }
      });
      
      if (response.ok) {
        localStorage.clear();
        setShowDeleteConfirm(false);
        setLocation("/role-selection");
      } else if (response.status === 401) {
        alert("Session expired. Please log in again to delete your account.");
        localStorage.clear();
        setLocation("/role-selection");
      } else {
        const data = await response.json();
        alert(data.error || "Failed to delete account. Please try again.");
      }
    } catch (error) {
      console.error("Failed to delete account:", error);
      alert("Network error. Please try again.");
    }
    setIsDeleting(false);
  };

  const handleShareApp = async () => {
    const shareData = {
      title: 'Spotly - Car & Bike Parking',
      text: 'Find parking spaces easily with Spotly app. Download now!',
      url: window.location.origin
    };
    
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      await navigator.clipboard.writeText(window.location.origin);
      alert('Link copied to clipboard!');
    }
  };

  const handleOpenProfile = () => {
    setEditName(name);
    setEditEmail(email);
    setShowProfileDialog(true);
  };

  const handleSaveProfile = async () => {
    const userId = localStorage.getItem("userId");
    if (!userId) return;
    
    setIsSaving(true);
    try {
      const response = await fetch(getApiUrl(`/api/users/${userId}`), {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editName, email: editEmail || "" })
      });
      
      if (response.ok) {
        setName(editName);
        setEmail(editEmail);
        localStorage.setItem("userName", editName);
        setShowProfileDialog(false);
        setShowSaveSuccess(true);
      }
    } catch (error) {
      console.error("Failed to save profile:", error);
    }
    setIsSaving(false);
  };

  const menuItems = [
    { icon: User, label: "Edit Profile", action: handleOpenProfile },
    { icon: Share2, label: "Share App", action: handleShareApp },
    { icon: FileText, label: "Policies", action: () => setShowPolicies(true) },
    { icon: HelpCircle, label: "Help & Support", action: () => setShowHelpSupport(true) },
    { icon: LogOut, label: "Logout", action: () => setShowLogoutConfirm(true), danger: true },
    { icon: Trash2, label: "Delete Account", action: () => setShowDeleteConfirm(true), danger: true },
  ];

  if (isGuest()) {
    return <GuestAccountView role="worker" />;
  }

  return (
    <MobileLayout showNav userType="worker">
      <div className="pb-8">
        <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-4 pt-3 pb-10 relative overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute top-1 right-3 w-16 h-16 rounded-full bg-white/10 blur-sm" />
            <div className="absolute -bottom-2 -left-2 w-18 h-18 rounded-full bg-pink-400/15 blur-md" />
            <div className="absolute top-3 left-1/3 w-8 h-8 rounded-full bg-yellow-300/10" />
            <div className="absolute bottom-3 right-1/4 w-6 h-6 rounded-full bg-cyan-300/10" />
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-6 bg-gradient-to-t from-black/10 to-transparent" />
          <h2 className="text-xl font-bold font-heading text-white relative z-10 drop-shadow-md">My Profile</h2>
          <p className="text-white/70 text-sm relative z-10 mt-1">Space Seeker</p>
        </div>

        <div className="px-4 pb-5 space-y-4 -mt-7 relative z-10">
          <div className="flex items-center gap-3.5 p-3.5 bg-white rounded-2xl border border-purple-100" style={{ boxShadow: "0 3px 14px rgba(79,0,115,0.10), 0 1px 3px rgba(0,0,0,0.05)" }}>
            {isLoading ? (
              <div className="flex items-center gap-3.5 w-full">
                <div className="bg-purple-100 rounded-full animate-pulse" style={{ width: '4.5rem', height: '4.5rem' }} />
                <div className="flex-1">
                  <div className="h-5 bg-purple-100 rounded w-32 mb-2 animate-pulse" />
                  <div className="h-4 bg-purple-100 rounded w-28 animate-pulse" />
                </div>
              </div>
            ) : (
              <>
                <div className="relative">
                  <div className="bg-gradient-to-br from-[#4f0073] via-[#9c27b0] to-[#e040fb] rounded-full flex items-center justify-center text-white font-bold text-2xl shadow-md shadow-purple-300/40 ring-2 ring-white" style={{ width: '4.5rem', height: '4.5rem' }}>
                    {name?.charAt(0)?.toUpperCase() || "U"}
                  </div>
                  <div className="absolute -bottom-1 -right-1 bg-green-400 rounded-full border-2 border-white flex items-center justify-center" style={{ width: '1.4rem', height: '1.4rem' }}>
                    <CheckCircle size={12} className="text-white" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-lg text-neutral-900 truncate" data-testid="text-user-name">
                    {name || "User"}
                  </h3>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <Phone size={14} className="text-[#7b1fa2]" />
                    <p className="text-neutral-600 text-sm font-medium" data-testid="text-user-mobile">
                      +91 {mobile}
                    </p>
                  </div>
                  {email && (
                    <div className="flex items-center gap-1.5 mt-1">
                      <Mail size={14} className="text-[#7b1fa2]" />
                      <p className="text-neutral-500 text-sm truncate" data-testid="text-user-email">{email}</p>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          <div className="bg-white rounded-3xl border border-neutral-100 overflow-hidden">
            {menuItems.map((item, index) => (
              <button
                key={index}
                onClick={item.action}
                className={`w-full flex items-center justify-between p-4 hover:bg-neutral-50 transition-colors ${
                  index !== menuItems.length - 1 ? "border-b border-neutral-100" : ""
                }`}
                data-testid={`button-menu-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    item.danger ? "bg-red-50 text-red-500" : "bg-neutral-100 text-neutral-600"
                  }`}>
                    <item.icon size={18} />
                  </div>
                  <span className={`font-medium ${item.danger ? "text-red-500" : "text-neutral-900"}`}>
                    {item.label}
                  </span>
                </div>
                <ChevronRight size={16} className="text-neutral-300" />
              </button>
            ))}
          </div>
          
          <div className="text-center">
            <p className="text-xs text-neutral-400">Version {appVersion}</p>
          </div>
        </div>

        <AnimatePresence>
        {showProfileDialog && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowProfileDialog(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 shadow-2xl max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <User size={32} className="text-primary" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 text-center mb-1">Edit Profile</h3>
              <p className="text-neutral-500 text-xs text-center mb-5">Update your personal information</p>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Full Name</Label>
                  <Input id="edit-name" value={editName} onChange={(e) => setEditName(e.target.value)} placeholder="Enter your name" className="h-12 rounded-xl" data-testid="input-edit-name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email">Email</Label>
                  <Input id="edit-email" type="email" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} placeholder="Enter your email" className="h-12 rounded-xl" data-testid="input-edit-email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-mobile">Mobile Number</Label>
                  <Input id="edit-mobile" value={mobile ? `+91 ${mobile}` : ""} disabled className="h-12 rounded-xl bg-neutral-100 text-neutral-500 cursor-not-allowed" data-testid="input-edit-mobile" />
                  <p className="text-xs text-neutral-400">Mobile number cannot be changed</p>
                </div>
              </div>
              <div className="flex gap-3 mt-5">
                <button onClick={() => setShowProfileDialog(false)} className="flex-1 py-3 bg-neutral-100 text-neutral-700 font-bold rounded-2xl hover:bg-neutral-200 transition-colors">Cancel</button>
                <button onClick={handleSaveProfile} disabled={isSaving || !editName.trim()} className="flex-1 py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors disabled:opacity-50 flex items-center justify-center gap-2" data-testid="button-save-profile">
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Changes"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {showSaveSuccess && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowSaveSuccess(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={32} className="text-green-600" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Profile Updated!</h3>
              <p className="text-neutral-500 text-xs mb-5">Your profile has been updated successfully.</p>
              <button onClick={() => setShowSaveSuccess(false)} className="w-full py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors" data-testid="button-close-save-success">Done</button>
            </motion.div>
          </motion.div>
        )}

        {showPolicies && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-4" onClick={() => setShowPolicies(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 shadow-2xl max-w-lg w-full max-h-[85vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <FileText size={32} className="text-primary" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 text-center mb-4">Terms & Conditions</h3>
              <div className="flex-1 overflow-y-auto pr-2 space-y-5 text-sm">
                <section>
                  <h2 className="text-base font-bold text-primary mb-3">1. Terms of Service</h2>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">1.1 Platform Overview</h3><p className="text-neutral-600 leading-relaxed">Spotly is a mobile-based platform that connects parking Space Providers with Space Seekers. Space Providers can list their available car and bike parking spaces, and Space Seekers can browse and connect with them for parking needs.</p></div>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">1.2 User Roles</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-2"><li><strong>Space Providers:</strong> Individuals with available parking spaces can register to list their spaces with details like location, rent, and photos. Upon registration, Space Providers consent to their listing details being displayed to registered Space Seekers.</li><li><strong>Space Seekers:</strong> Users looking for parking spaces can register to browse available listings and contact Space Providers directly. Only registered Space Seekers can view provider contact details.</li></ul></div>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">1.3 User Responsibilities</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>Users must use the platform responsibly and in good faith.</li><li>All interactions, agreements, negotiations, payments, or services arranged are between users only.</li><li>Spotly does not verify users, mediate disputes, or act as an employer, agent, or contractor.</li></ul></div>
                  <div><h3 className="font-semibold text-neutral-800 mb-1">1.4 Prohibited Use</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>Misusing the app to harass, scam, or defraud other users is strictly prohibited.</li><li>Users must not share false information or impersonate other users.</li></ul></div>
                </section>
                <section>
                  <h2 className="text-base font-bold text-primary mb-3">2. Privacy Policy</h2>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">2.1 Information Collected</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>Space Providers: Name, contact number, parking space details (location, rent, photos).</li><li>Space Seekers: Name, contact information, and location preferences.</li></ul></div>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">2.2 Purpose of Data Collection</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>To facilitate communication between Space Providers and Space Seekers for parking arrangements.</li><li>To display Space Provider contact details and parking space listings only to registered Space Seekers.</li></ul></div>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">2.3 Consent to Share Contact Information</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>By registering, Space Providers consent to their parking space details being shared with registered Space Seekers for parking-related communication.</li><li>Users are responsible for safeguarding their own privacy during interactions.</li></ul></div>
                  <div><h3 className="font-semibold text-neutral-800 mb-1">2.4 Data Security</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>Spotly stores data securely, but cannot guarantee user behavior outside the platform.</li><li>Users are advised to communicate responsibly and verify information before engaging in any service or payment.</li></ul></div>
                </section>
                <section>
                  <h2 className="text-base font-bold text-primary mb-3">3. Payment Policy</h2>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">3.1 Premium Services / Subscription</h3><p className="text-neutral-600 leading-relaxed">Spotly may offer premium services or subscriptions for enhanced visibility or features.</p></div>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">3.2 Payment & Refunds</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>All payments must be completed through the app's payment gateway.</li><li><strong>Cancellation & Refund Policy:</strong> Once a payment for a premium subscription is made, it is non-refundable. Users must ensure they understand the payment before confirming.</li></ul></div>
                  <div><h3 className="font-semibold text-neutral-800 mb-1">3.3 User Responsibility</h3><p className="text-neutral-600 leading-relaxed">Users are responsible for managing their subscriptions, payments, and access to premium features.</p></div>
                </section>
                <section>
                  <h2 className="text-base font-bold text-primary mb-3">4. Liability & Disputes</h2>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">4.1 Platform Limitation</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>Spotly operates solely as a facilitation platform.</li><li>The company does not verify users, oversee services, guarantee quality, or mediate agreements.</li></ul></div>
                  <div className="mb-3"><h3 className="font-semibold text-neutral-800 mb-1">4.2 User Responsibility</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>All negotiations, service arrangements, payments, and disputes are the sole responsibility of the users.</li><li>Users engage with the platform at their own risk, and Spotly is not liable for any disputes, losses, or damages.</li></ul></div>
                  <div><h3 className="font-semibold text-neutral-800 mb-1">4.3 Dispute Resolution</h3><ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1"><li>Users should attempt to resolve disputes directly with the other party.</li><li>Spotly will not intervene or act as a mediator.</li></ul></div>
                </section>
              </div>
              <button onClick={() => setShowPolicies(false)} className="w-full py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors mt-4">Close</button>
            </motion.div>
          </motion.div>
        )}

        {showHelpSupport && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowHelpSupport(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <Phone size={32} className="text-primary" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-1">Help & Support</h3>
              <p className="text-neutral-500 text-xs mb-5">We're here to help!</p>
              <div className="space-y-2 text-left">
                <a href={`tel:${supportPhone.replace(/\s/g, '')}`} className="flex items-center gap-3 p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors" data-testid="link-call-support">
                  <div className="w-9 h-9 bg-green-500 rounded-full flex items-center justify-center"><Phone className="w-4 h-4 text-white" /></div>
                  <div className="text-left"><p className="font-semibold text-neutral-900 text-sm">Call Us</p><p className="text-xs text-neutral-600">{supportPhone}</p></div>
                </a>
                <a href={`mailto:${supportEmail}`} className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors" data-testid="link-email-support">
                  <div className="w-9 h-9 bg-blue-500 rounded-full flex items-center justify-center"><Mail className="w-4 h-4 text-white" /></div>
                  <div className="text-left"><p className="font-semibold text-neutral-900 text-sm">Email Us</p><p className="text-xs text-neutral-600">{supportEmail}</p></div>
                </a>
              </div>
              <button onClick={() => setShowHelpSupport(false)} className="mt-5 w-full py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors" data-testid="button-close-help">Close</button>
            </motion.div>
          </motion.div>
        )}

        {showLogoutConfirm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowLogoutConfirm(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center mx-auto mb-4">
                <LogOut size={32} className="text-orange-500" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Logout?</h3>
              <p className="text-neutral-500 text-xs mb-5">Are you sure you want to logout?</p>
              <div className="flex gap-3">
                <button onClick={() => setShowLogoutConfirm(false)} className="flex-1 py-3 bg-neutral-100 text-neutral-700 font-bold rounded-2xl hover:bg-neutral-200 transition-colors">Cancel</button>
                <button onClick={handleLogoutConfirm} className="flex-1 py-3 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 transition-colors flex items-center justify-center gap-2"><LogOut size={16} /> Logout</button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {showDeleteConfirm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6" onClick={() => setShowDeleteConfirm(false)}>
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.85, opacity: 0 }} className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                <Trash2 size={32} className="text-red-500" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Delete Account?</h3>
              <p className="text-neutral-500 text-xs mb-5">This action cannot be undone. All your data will be permanently deleted.</p>
              <div className="flex gap-3">
                <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 py-3 bg-neutral-100 text-neutral-700 font-bold rounded-2xl hover:bg-neutral-200 transition-colors" disabled={isDeleting}>Cancel</button>
                <button onClick={handleDeleteAccount} disabled={isDeleting} className="flex-1 py-3 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                  {isDeleting ? <Loader2 size={16} className="animate-spin" /> : <><Trash2 size={16} /> Delete</>}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
        </AnimatePresence>
      </div>
    </MobileLayout>
  );
}
