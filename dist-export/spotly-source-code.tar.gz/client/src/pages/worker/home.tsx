import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import {
  MapPin,
  Bell,
  Loader2,
  Phone,
  Mail,
  Car,
  Bike,
  IndianRupee,
  Calendar,
  Clock,
  Eye,
  EyeOff,
  MessageCircle,
  Crown,
  Check,
  X,
  Shield,
  Zap,
  Star,
  Search,
  Navigation,
  XCircle,
  ImageIcon,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ThumbsUp,
  ParkingCircle,
  LocateFixed,
} from "lucide-react";
import { vibrate } from "@/lib/vibrate";
import { useAuthGuard } from "@/contexts/auth-guard";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { getApiUrl } from "@/lib/api-config";
import { useScroll } from "@/contexts/scroll-context";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

interface ParkingSpace {
  id: string;
  customerId: string;
  serviceName: string;
  location: string;
  comments: string | null;
  date: string;
  time: string;
  bookedAt: string;
  rent: number;
  description: string;
  parkingType: "car" | "bike" | "both";
  ownerPhone: string;
  ownerName: string;
  latitude: number | null;
  longitude: number | null;
  photos: string[];
}

export default function WorkerHome() {
  const [, setLocation] = useLocation();
  const [userName, setUserName] = useState(localStorage.getItem("userName") || "");
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [parkingSpaces, setParkingSpaces] = useState<ParkingSpace[]>([]);
  const [totalSpaces, setTotalSpaces] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const PAGE_SIZE = 20;
  const [selectedSpace, setSelectedSpace] = useState<ParkingSpace | null>(null);
  const [showSpaceDetail, setShowSpaceDetail] = useState(false);
  const [showSubscriptionPopup, setShowSubscriptionPopup] = useState(false);
  const [choosePlan, setChoosePlan] = useState<string | null>(null);
  const [showPaymentProcessing, setShowPaymentProcessing] = useState(false);
  const [showPaymentSuccess, setShowPaymentSuccess] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<{ name: string; price: number; views: number; key: string } | null>(null);
  const [isPremium, setIsPremium] = useState(false);
  const [premiumPlan, setPremiumPlan] = useState<string | null>(null);
  const [premiumViewsRemaining, setPremiumViewsRemaining] = useState(0);
  const [premiumExpiresAt, setPremiumExpiresAt] = useState<string | null>(null);
  const [showPremiumDetails, setShowPremiumDetails] = useState(false);
  const [revealedContacts, setRevealedContacts] = useState<Set<string>>(new Set());
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [spaceFilter, setSpaceFilter] = useState<"all" | "viewed" | "unviewed">("all");
  const [isSearching, setIsSearching] = useState(false);
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [placeholderText, setPlaceholderText] = useState("");
  const [isTyping, setIsTyping] = useState(true);
  const placeholderExamples = [
    "HSR Layout",
    "J P Nagar",
    "Koramangala",
    "Indiranagar",
    "Whitefield",
    "Electronic City",
    "Marathahalli",
    "BTM Layout",
  ];
  const [userLocation, setUserLocation] = useState("");
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [showPhotoViewer, setShowPhotoViewer] = useState(false);
  const [viewingPhotos, setViewingPhotos] = useState<string[]>([]);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);
  const [interestCounts, setInterestCounts] = useState<Record<string, number>>({});
  const [userInterests, setUserInterests] = useState<Set<string>>(new Set());
  const [interestLoading, setInterestLoading] = useState<string | null>(null);
  const [showSupportPopup, setShowSupportPopup] = useState(false);
  const [supportPhone, setSupportPhone] = useState("+91 98765 43210");
  const [supportEmail, setSupportEmail] = useState("info@spotlyindia.org");
  const [adVideoUrl, setAdVideoUrl] = useState("");
  const [adVideoEnabled, setAdVideoEnabled] = useState(true);
  const [comingSoonMode, setComingSoonMode] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<
    Array<{
      id: string;
      type: string;
      title: string;
      message: string;
      createdAt: string;
      isRead: boolean;
    }>
  >([]);
  const [isClearingNotifications, setIsClearingNotifications] = useState(false);
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const calcDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  };

  const [locationReady, setLocationReady] = useState(false);

  useEffect(() => {
    const savedLat = localStorage.getItem("userLatitude");
    const savedLng = localStorage.getItem("userLongitude");
    if (savedLat && savedLng) {
      const lat = parseFloat(savedLat);
      const lng = parseFloat(savedLng);
      if (!isNaN(lat) && !isNaN(lng)) {
        setUserCoords({ lat, lng });
        setLocationReady(true);
      }
    }
    // Hard fallback so the spaces list always loads even if the
    // geolocation prompt is dismissed or never resolves (common in iframes).
    const fallbackTimer = setTimeout(() => setLocationReady(true), 4000);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          clearTimeout(fallbackTimer);
          const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setUserCoords(coords);
          localStorage.setItem("userLatitude", coords.lat.toString());
          localStorage.setItem("userLongitude", coords.lng.toString());
          setLocationReady(true);
          const uid = localStorage.getItem("userId");
          if (uid) {
            fetch(getApiUrl(`/api/workers/${uid}/location`), {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ latitude: coords.lat, longitude: coords.lng }),
            }).catch(() => {});
          }
        },
        () => {
          clearTimeout(fallbackTimer);
          setLocationReady(true);
        },
        { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }
      );
    } else {
      clearTimeout(fallbackTimer);
      setLocationReady(true);
    }

    return () => clearTimeout(fallbackTimer);
  }, []);

  const fetchNotifications = async () => {
    const userId = localStorage.getItem("userId");
    if (userId) {
      try {
        const response = await fetch(getApiUrl(`/api/notifications/${userId}`));
        if (response.ok) {
          const data = await response.json();
          setNotifications(data.notifications || []);
        }
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "booking_accepted": return "✅";
      case "booking_cancelled": return "❌";
      case "worker_assigned": return "👷";
      case "new_job": return "📋";
      case "broadcast": return "📢";
      default: return "🔔";
    }
  };

  const formatTimestamp = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hr ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
    return date.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
  };

  const handleClearNotifications = async () => {
    const userId = localStorage.getItem("userId");
    if (!userId) return;
    setIsClearingNotifications(true);
    try {
      const response = await fetch(getApiUrl(`/api/notifications/${userId}/clear`), { method: "DELETE" });
      if (response.ok) setNotifications([]);
    } catch (error) {
      console.error("Failed to clear notifications:", error);
    } finally {
      setIsClearingNotifications(false);
    }
  };

  useEffect(() => {
    const userRole = localStorage.getItem("userRole");
    if (userRole === "customer") {
      setLocation("/customer/home");
      return;
    }
  }, [setLocation]);

  useEffect(() => { fetchNotifications(); }, []);

  useEffect(() => {
    if (searchQuery || isSearchFocused) return;
    const currentWord = placeholderExamples[placeholderIndex];
    let charIndex = 0;
    let deleting = false;
    let timeout: ReturnType<typeof setTimeout>;

    const animate = () => {
      if (!deleting) {
        charIndex++;
        setPlaceholderText(currentWord.slice(0, charIndex));
        if (charIndex === currentWord.length) {
          deleting = true;
          timeout = setTimeout(animate, 1500);
          return;
        }
        timeout = setTimeout(animate, 80);
      } else {
        charIndex--;
        setPlaceholderText(currentWord.slice(0, charIndex));
        if (charIndex === 0) {
          setPlaceholderIndex((prev) => (prev + 1) % placeholderExamples.length);
          return;
        }
        timeout = setTimeout(animate, 40);
      }
    };

    timeout = setTimeout(animate, 300);
    return () => clearTimeout(timeout);
  }, [placeholderIndex, searchQuery, isSearchFocused]);

  useEffect(() => {
    const fetchComingSoonMode = async () => {
      try {
        const response = await fetch(getApiUrl("/api/settings/coming_soon_mode"));
        if (response.ok) {
          const data = await response.json();
          setComingSoonMode(data.setting?.value === "true");
        } else {
          setComingSoonMode(false);
        }
      } catch (error) {
        setComingSoonMode(false);
      }
    };
    fetchComingSoonMode();
    
    const fetchAdVideo = async () => {
      try {
        const [urlRes, enabledRes] = await Promise.all([
          fetch(getApiUrl("/api/settings/ad_video_url")),
          fetch(getApiUrl("/api/settings/ad_video_enabled"))
        ]);
        if (urlRes.ok) {
          const data = await urlRes.json();
          if (data.setting?.value) setAdVideoUrl(data.setting.value);
        }
        if (enabledRes.ok) {
          const data = await enabledRes.json();
          if (data.setting?.value !== undefined) setAdVideoEnabled(data.setting.value === "true");
        }
      } catch (error) {}
    };
    fetchAdVideo();
  }, []);

  useEffect(() => { if (notificationsOpen) fetchNotifications(); }, [notificationsOpen]);

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    const storedName = localStorage.getItem("userName");
    if (storedName) setUserName(storedName);
    if (userId) {
      const fetchUserData = async () => {
        try {
          const [userRes, viewedRes] = await Promise.all([
            fetch(getApiUrl(`/api/users/${userId}`)),
            fetch(getApiUrl(`/api/users/${userId}/viewed-contacts`)),
          ]);
          if (userRes.ok) {
            const data = await userRes.json();
            if (data.name) setUserName(data.name);
            const isExpired = data.premiumExpiresAt && new Date(data.premiumExpiresAt) < new Date();
            const hasViews = data.premiumPlan === "premium" || (data.premiumViewsRemaining ?? 0) > 0;
            const activePremium = !!data.isPremium && !isExpired && hasViews;
            setIsPremium(activePremium);
            setPremiumPlan(activePremium ? (data.premiumPlan || null) : null);
            setPremiumViewsRemaining(activePremium ? (data.premiumViewsRemaining ?? 0) : 0);
            setPremiumExpiresAt(activePremium ? (data.premiumExpiresAt || null) : null);
          }
          if (viewedRes.ok) {
            const viewedData = await viewedRes.json();
            if (viewedData.viewedBookingIds?.length > 0) {
              setRevealedContacts(new Set(viewedData.viewedBookingIds));
            }
          }
        } catch (error) {
          console.error("Failed to fetch user data:", error);
        }
      };
      fetchUserData();
    }
  }, []);

  const getParkingType = (serviceName: string): "car" | "bike" | "both" => {
    const name = serviceName.toLowerCase();
    if (name.includes("car") && name.includes("bike")) return "both";
    if (name.includes("bike")) return "bike";
    return "car";
  };

  const maskPhone = (phone: string) => {
    if (!phone || phone.length < 4) return "XXXXXXXXXX";
    const cleaned = phone.replace(/\D/g, "");
    if (cleaned.length >= 10) {
      return cleaned.slice(0, 2) + "XXXXXX" + cleaned.slice(-2);
    }
    return phone.slice(0, 2) + "XXXXXXXX";
  };

  const parseBooking = (b: any): ParkingSpace => {
    const rentMatch = b.comments?.match(/Rent: ₹(\d+)/);
    const commentsWithoutPhotos = b.comments?.replace(/\[PHOTOS\].*?\[\/PHOTOS\]/s, "") || "";
    const descMatch = commentsWithoutPhotos.match(/\| (.+)/);
    const photosMatch = b.comments?.match(/\[PHOTOS\](.*?)\[\/PHOTOS\]/s);
    let parsedPhotos: string[] = [];
    if (photosMatch) {
      try { parsedPhotos = JSON.parse(photosMatch[1]); } catch { }
    }
    return {
      id: b.id,
      customerId: b.customerId,
      serviceName: b.serviceName,
      location: b.location || "Location not set",
      comments: b.comments,
      date: b.date,
      time: b.time,
      bookedAt: b.bookedAt,
      rent: rentMatch ? parseInt(rentMatch[1]) : 0,
      description: descMatch ? descMatch[1].trim() : "Parking space available for rent",
      parkingType: getParkingType(b.serviceName),
      ownerPhone: b.ownerPhone || "",
      ownerName: b.ownerName || "Space Owner",
      latitude: b.latitude != null ? b.latitude : null,
      longitude: b.longitude != null ? b.longitude : null,
      photos: parsedPhotos,
    };
  };

  const RADIUS_KM = 3;

  const buildPendingUrl = (offset: number) => {
    const params = new URLSearchParams();
    const lat = localStorage.getItem("userLatitude");
    const lng = localStorage.getItem("userLongitude");
    if (lat && lng) {
      params.set("lat", lat);
      params.set("lng", lng);
      params.set("radius", String(RADIUS_KM));
    } else {
      const cityId = localStorage.getItem("selectedCity") || "";
      if (cityId) params.set("city", cityId);
    }
    params.set("limit", String(PAGE_SIZE));
    params.set("offset", String(offset));
    return getApiUrl(`/api/bookings/pending?${params.toString()}`);
  };

  const fetchParkingSpaces = async () => {
    try {
      const response = await fetch(buildPendingUrl(0));
      const data = await response.json();
      const spaces: ParkingSpace[] = (data.bookings || []).map(parseBooking);
      setParkingSpaces(spaces);
      setTotalSpaces(data.total ?? spaces.length);
      setCurrentPage(1);
      if (spaces.length > 0) fetchInterestData(spaces.map(s => s.id));
    } catch (error) {
      console.error("Failed to fetch parking spaces:", error);
      setParkingSpaces([]);
      setTotalSpaces(0);
    }
    setIsLoading(false);
  };

  const loadMoreSpaces = async () => {
    if (isLoadingMore || parkingSpaces.length >= totalSpaces) return;
    setIsLoadingMore(true);
    try {
      const offset = currentPage * PAGE_SIZE;
      const response = await fetch(buildPendingUrl(offset));
      const data = await response.json();
      const newSpaces: ParkingSpace[] = (data.bookings || []).map(parseBooking);
      if (newSpaces.length > 0) {
        setParkingSpaces(prev => [...prev, ...newSpaces]);
        setCurrentPage(prev => prev + 1);
        fetchInterestData(newSpaces.map(s => s.id));
      }
    } catch (error) {
      console.error("Failed to load more spaces:", error);
    }
    setIsLoadingMore(false);
  };

  useEffect(() => {
    if (locationReady) {
      fetchParkingSpaces();
    }
  }, [locationReady]);

  useEffect(() => {
    if (searchQuery.trim()) {
      setIsSearching(true);
      const timer = setTimeout(() => setIsSearching(false), 500);
      return () => clearTimeout(timer);
    } else {
      setIsSearching(false);
    }
  }, [searchQuery]);

  const handleAutoLocate = async () => {
    setIsLocating(true);
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 });
      });
      const { latitude, longitude } = position.coords;
      setUserCoords({ lat: latitude, lng: longitude });
      localStorage.setItem("userLatitude", latitude.toString());
      localStorage.setItem("userLongitude", longitude.toString());
      const uid = localStorage.getItem("userId");
      if (uid) {
        fetch(getApiUrl(`/api/workers/${uid}/location`), {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ latitude, longitude }),
        }).catch(() => {});
      }
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=16`);
      if (res.ok) {
        const data = await res.json();
        const area = data.address?.suburb || data.address?.neighbourhood || data.address?.village || data.address?.city_district || data.address?.city || "";
        setSearchQuery(area);
        setUserLocation(area);
      }
    } catch (error) {
      console.error("Location detection failed:", error);
      alert("Could not detect your location. Please search manually.");
    }
    setIsLocating(false);
  };

  const filteredSpaces = parkingSpaces.filter((space) => {
    if (spaceFilter === "viewed" && !revealedContacts.has(space.id)) return false;
    if (spaceFilter === "unviewed" && revealedContacts.has(space.id)) return false;
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase().trim();
    const haystack = [
      space.location,
      space.serviceName,
      space.ownerName,
      space.description,
    ].join(" ").toLowerCase();
    if (haystack.includes(query)) return true;
    const tokens = query.split(/[\s,.-]+/).filter((t) => t.length >= 2);
    if (tokens.length === 0) return true;
    return tokens.some((tok) => haystack.includes(tok));
  }).sort((a, b) => {
    if (userCoords) {
      const distA = a.latitude && a.longitude ? calcDistance(userCoords.lat, userCoords.lng, a.latitude, a.longitude) : 99999;
      const distB = b.latitude && b.longitude ? calcDistance(userCoords.lat, userCoords.lng, b.latitude, b.longitude) : 99999;
      if (distA !== distB) return distA - distB;
    }
    const aInterested = userInterests.has(a.id) ? 1 : 0;
    const bInterested = userInterests.has(b.id) ? 1 : 0;
    return bInterested - aInterested;
  });

  const handleViewPhotos = (e: React.MouseEvent, photos: string[]) => {
    e.stopPropagation();
    setViewingPhotos(photos);
    setActivePhotoIndex(0);
    setShowPhotoViewer(true);
  };

  const handleSpaceClick = (space: ParkingSpace) => {
    setSelectedSpace(space);
    setShowSpaceDetail(true);
  };

  const handleViewContactForSpace = async (spaceId: string) => {
    if (!isPremium) {
      setShowSubscriptionPopup(true);
      return;
    }

    if (revealedContacts.has(spaceId)) return;

    const userId = localStorage.getItem("userId");
    if (!userId) return;

    if (premiumPlan !== "premium" && premiumViewsRemaining <= 0) {
      setShowSubscriptionPopup(true);
      return;
    }

    try {
      const res = await fetch(getApiUrl(`/api/users/${userId}/premium/use-view`), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (res.ok) {
        const data = await res.json();
        setPremiumViewsRemaining(data.viewsRemaining ?? premiumViewsRemaining - 1);
        setRevealedContacts(prev => new Set(prev).add(spaceId));
        fetch(getApiUrl(`/api/users/${userId}/viewed-contacts`), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ bookingId: spaceId }),
        }).catch(() => {});
      } else {
        const errData = await res.json();
        if (errData.expired || errData.error?.includes("No views")) {
          setIsPremium(false);
          setPremiumPlan(null);
          setShowSubscriptionPopup(true);
        }
      }
    } catch (error) {
      console.error("Failed to use premium view:", error);
    }
  };

  const handleViewContact = async () => {
    if (!selectedSpace) return;
    handleViewContactForSpace(selectedSpace.id);
  };

  const getDistanceText = (space: ParkingSpace): string | null => {
    if (!userCoords || !space.latitude || !space.longitude) return null;
    const dist = calcDistance(userCoords.lat, userCoords.lng, space.latitude, space.longitude);
    if (dist < 1) return `${Math.round(dist * 1000)}m away`;
    return `${dist.toFixed(1)} km away`;
  };

  const [plans, setPlans] = useState([
    { name: "Basic", price: 199, views: 10, key: "basic" },
    { name: "Standard", price: 299, views: 20, key: "standard" },
    { name: "Premium", price: 399, views: -1, key: "premium" },
  ]);

  useEffect(() => {
    fetch(getApiUrl("/api/settings/premium-plans"))
      .then(res => res.json())
      .then(data => {
        if (data.plans) {
          setPlans(data.plans.filter((p: any) => p.enabled));
        }
      })
      .catch(() => {});
  }, []);

  const handleSelectPlan = (plan: typeof plans[0]) => {
    setSelectedPlan(plan);
    setShowSubscriptionPopup(false);
    setShowPaymentProcessing(true);

    setTimeout(async () => {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        setShowPaymentProcessing(false);
        return;
      }

      try {
        const res = await fetch(getApiUrl(`/api/users/${userId}/premium`), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ plan: plan.key, amount: plan.price * 100 }),
        });

        if (res.ok) {
          const data = await res.json();
          setIsPremium(true);
          setPremiumPlan(data.user.premiumPlan);
          setPremiumViewsRemaining(data.user.premiumViewsRemaining);
          setPremiumExpiresAt(data.user.premiumExpiresAt);
          setShowPaymentProcessing(false);
          setShowPaymentSuccess(true);
        } else {
          setShowPaymentProcessing(false);
          alert("Payment failed. Please try again.");
        }
      } catch (error) {
        console.error("Payment error:", error);
        setShowPaymentProcessing(false);
        alert("Payment failed. Please try again.");
      }
    }, 2000);
  };

  const openDirections = (e: React.MouseEvent, space: ParkingSpace) => {
    e.stopPropagation();
    let url: string;
    if (space.latitude && space.longitude) {
      url = `https://www.google.com/maps/dir/?api=1&destination=${space.latitude},${space.longitude}`;
    } else {
      url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(space.location)}`;
    }
    window.open(url, "_blank");
  };


  const { requireLogin } = useAuthGuard();

  const handleInterest = async (e: React.MouseEvent, spaceId: string) => {
    e.stopPropagation();
    if (!requireLogin("show interest in this space")) return;
    const userId = localStorage.getItem("userId");
    if (!userId) return;
    setInterestLoading(spaceId);
    try {
      if (userInterests.has(spaceId)) {
        const res = await fetch(getApiUrl(`/api/interests/${spaceId}`), {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId }),
        });
        if (res.ok) {
          const data = await res.json();
          setUserInterests(prev => { const next = new Set(prev); next.delete(spaceId); return next; });
          setInterestCounts(prev => ({ ...prev, [spaceId]: data.count }));
        }
      } else {
        const res = await fetch(getApiUrl(`/api/interests/${spaceId}`), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId }),
        });
        if (res.ok) {
          const data = await res.json();
          setUserInterests(prev => new Set([...prev, spaceId]));
          setInterestCounts(prev => ({ ...prev, [spaceId]: data.count }));
        }
      }
    } catch (error) {
      console.error("Interest toggle failed:", error);
    }
    setInterestLoading(null);
  };


  const fetchInterestData = async (spaceIds: string[]) => {
    const userId = localStorage.getItem("userId");
    try {
      if (spaceIds.length > 0) {
        const countsRes = await fetch(getApiUrl(`/api/interests/counts?ids=${spaceIds.join(",")}`));
        if (countsRes.ok) {
          const data = await countsRes.json();
          setInterestCounts(prev => ({ ...prev, ...(data.counts || {}) }));
        }
      }
      if (userId) {
        const userRes = await fetch(getApiUrl(`/api/interests/user/${userId}`));
        if (userRes.ok) {
          const data = await userRes.json();
          setUserInterests(new Set(data.bookingIds || []));
        }
      }
    } catch (error) {
      console.error("Failed to fetch interest data:", error);
    }
  };

  const formatDisplayDate = (dateStr: string) => {
    if (!dateStr) return "";
    try {
      const date = new Date(dateStr + "T00:00:00");
      return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
    } catch { return dateStr; }
  };

  const timeAgo = (bookedAt: string) => {
    if (!bookedAt) return "";
    try {
      const posted = new Date(bookedAt);
      if (isNaN(posted.getTime())) return "";
      const now = new Date();
      const diffMs = now.getTime() - posted.getTime();
      if (diffMs < 0) return "just now";
      const diffSecs = Math.floor(diffMs / 1000);
      if (diffSecs < 60) return "just now";
      const diffMins = Math.floor(diffSecs / 60);
      if (diffMins < 60) return `${diffMins}m ago`;
      const diffHrs = Math.floor(diffMins / 60);
      if (diffHrs < 24) return `${diffHrs}h ago`;
      const diffDays = Math.floor(diffHrs / 24);
      if (diffDays < 30) return `${diffDays}d ago`;
      const diffMonths = Math.floor(diffDays / 30);
      return `${diffMonths}mo ago`;
    } catch { return ""; }
  };

  const userCity = localStorage.getItem("userDetectedCity") || localStorage.getItem("selectedServiceAreaName") || "";
  const userState = localStorage.getItem("userState") || localStorage.getItem("workerState") || "";
  const locationLabel = userCity || "Location not set";

  const { scrollY } = useScroll();
  const isScrolled = scrollY > 80;

  if (comingSoonMode === true) {
    return (
      <div className="min-h-screen bg-white flex flex-col relative overflow-hidden">
        <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] pt-16 pb-32 px-6 relative">
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-white rounded-t-[3rem]"></div>
          <div className="absolute top-10 left-10 w-20 h-20 border-2 border-white/20 rounded-full"></div>
          <div className="absolute top-24 left-6 w-8 h-8 bg-white/10 rounded-full"></div>
          <div className="absolute top-8 right-8 w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
          <div className="text-center relative z-10">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
              <span className="text-white/90 text-xs font-medium">Space Seeker</span>
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Spotly</h1>
            <p className="text-purple-200 text-sm">Find Parking Near You</p>
          </div>
        </div>
        <div className="flex-1 px-6 -mt-8 relative z-10">
          <div className="bg-white rounded-3xl shadow-xl shadow-purple-200/50 p-8 mb-6 border border-purple-100">
            <div className="flex items-center justify-center mb-6">
              <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-purple-50 rounded-full flex items-center justify-center">
                <Car className="w-12 h-12 text-primary" />
              </div>
            </div>
            <h2 className="text-xl font-bold text-gray-900 text-center mb-3">Parking Spaces Coming!</h2>
            <p className="text-gray-500 text-center text-sm leading-relaxed">
              Find available parking spaces near you. Safe, affordable, and convenient.
            </p>
          </div>
          <div className="bg-gradient-to-r from-purple-50 to-violet-50 rounded-2xl p-5 text-center mb-4">
            <p className="text-gray-700 font-medium text-sm">Launching Soon!</p>
            <p className="text-gray-500 text-xs mt-1">We'll notify you when spaces are available</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <MobileLayout showNav userType="worker">
      <div className="pb-8 bg-neutral-50 min-h-full">
        {/* Sticky Header */}
        <div
          className={`fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-4 py-3 shadow-lg transition-all duration-300 ${isScrolled ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'}`}
        >
          <div className="flex items-center justify-between max-w-md mx-auto">
            <div className="flex items-center gap-3">
              <div>
                <p className="text-white font-semibold text-sm">{userName}</p>
                <p className="text-purple-200 text-xs">Space Seeker</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSupportPopup(true)}
                className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10"
                data-testid="button-support-sticky"
              >
                <Phone size={16} className="drop-shadow-sm" />
              </button>
              <button
                onClick={() => setNotificationsOpen(true)}
                className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10 relative"
                data-testid="button-notifications-sticky"
              >
                <Bell size={16} className="drop-shadow-sm" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full ring-2 ring-white flex items-center justify-center text-[10px] font-bold">{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Gradient Header */}
        <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-6 pt-6 pb-10 relative overflow-hidden">
          <div className="absolute top-4 right-4 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-400/20 rounded-full blur-xl -translate-x-1/2 translate-y-1/2"></div>
          <div className="relative z-10 flex items-start justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-white">{userName}</h2>
              <div className="flex items-center gap-1.5 mt-1" data-testid="text-location-label-worker">
                <MapPin size={13} className="text-purple-200/80" />
                <p className="text-purple-200 text-sm font-medium">{locationLabel}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSupportPopup(true)}
                className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10"
                data-testid="button-support-worker"
              >
                <Phone size={18} className="drop-shadow-sm" />
              </button>
              <button
                onClick={() => setNotificationsOpen(true)}
                className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/25 transition-all shadow-lg shadow-purple-900/10 relative"
                data-testid="button-notifications-worker"
              >
                <Bell size={18} className="drop-shadow-sm" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full ring-2 ring-white flex items-center justify-center text-[10px] font-bold">{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Search Box */}
        <div className="px-4 -mt-4 relative z-40 mb-4">
          <div className="bg-white rounded-2xl shadow-md shadow-neutral-200/60 border border-neutral-100 flex items-center overflow-hidden">
            <div className="pl-4 pr-2">
              {isSearching ? (
                <Loader2 size={18} className="text-primary animate-spin" />
              ) : (
                <Search size={18} className="text-neutral-400" />
              )}
            </div>
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
                placeholder={isSearchFocused ? "Type area, city or locality..." : ""}
                className="w-full py-3.5 px-2 text-sm text-neutral-800 outline-none bg-transparent relative z-10"
                data-testid="input-search-spaces"
              />
              {!searchQuery && !isSearchFocused && (
                <div className="absolute inset-0 flex items-center px-2 pointer-events-none">
                  <span className="text-neutral-400 text-sm">Search "</span>
                  <span className="text-[#7b1fa2] text-sm font-medium">{placeholderText}</span>
                  <span className="text-[#7b1fa2] text-sm font-medium animate-pulse">|</span>
                  <span className="text-neutral-400 text-sm">"</span>
                </div>
              )}
            </div>
            {searchQuery && (
              <button
                onClick={() => { setSearchQuery(""); setUserLocation(""); }}
                className="p-2 text-neutral-400 hover:text-neutral-600 transition-colors"
                data-testid="button-clear-search"
              >
                <XCircle size={18} />
              </button>
            )}
            <button
              onClick={() => { vibrate(); handleAutoLocate(); }}
              disabled={isLocating}
              className="flex items-center gap-1.5 px-3 py-3.5 hover:bg-primary/20 text-primary transition-colors border-l border-neutral-100"
              data-testid="button-auto-locate"
            >
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center relative">
                {isLocating ? (
                  <Loader2 size={18} className="animate-spin" />
                ) : (
                  <>
                    <LocateFixed size={18} className="text-primary animate-pulse" />
                    <span className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping" />
                  </>
                )}
              </div>
            </button>
          </div>
          {userLocation && (
            <p className="text-xs text-primary mt-2 ml-1 flex items-center gap-1">
              <MapPin size={10} />
              Showing results near: {userLocation}
            </p>
          )}

        </div>

        {/* Parking Spaces List */}
        <div className="px-4 relative z-10">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#4f0073] to-[#7b1fa2] flex items-center justify-center shadow-sm">
                <ParkingCircle size={16} className="text-white" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">Available Parking Spaces</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm">{filteredSpaces.length}</span>
              <button
                onClick={() => { if (!requireLogin("subscribe to Premium")) return; isPremium ? setShowPremiumDetails(true) : setShowSubscriptionPopup(true); }}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all active:scale-95 ${
                  isPremium
                    ? "bg-gradient-to-r from-yellow-400 to-yellow-500 text-white shadow-sm"
                    : "bg-gradient-to-r from-purple-100 to-purple-50 text-primary border border-purple-200"
                }`}
                data-testid="button-premium"
              >
                <Crown size={12} />
                {isPremium ? (premiumPlan === "premium" ? "Unlimited" : `${premiumViewsRemaining}/${premiumPlan === "basic" ? 10 : 20}`) : "Premium"}
              </button>
            </div>
          </div>
          <div className="relative h-[3px] rounded-full bg-purple-100 mb-3 overflow-hidden">
            <motion.div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#4f0073] via-[#e040fb] to-[#4f0073] rounded-full"
              style={{ width: "40%" }}
              animate={{ x: ["-100%", "350%"] }}
              transition={{ duration: 2.5, repeat: 2, ease: "easeInOut" }}
            />
          </div>

          {isPremium && <div className="flex items-center gap-2 mb-4">
            <button
              onClick={() => { vibrate(); setSpaceFilter("all"); }}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all active:scale-95 ${
                spaceFilter === "all"
                  ? "bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white shadow-sm"
                  : "bg-neutral-100 text-neutral-500 hover:bg-neutral-200"
              }`}
              data-testid="filter-all"
            >
              All
            </button>
            <button
              onClick={() => { vibrate(); setSpaceFilter("viewed"); }}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 ${
                spaceFilter === "viewed"
                  ? "bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white shadow-sm"
                  : "bg-neutral-100 text-neutral-500 hover:bg-neutral-200"
              }`}
              data-testid="filter-viewed"
            >
              <Eye size={12} />
              Viewed
              {revealedContacts.size > 0 && (
                <span className={`ml-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                  spaceFilter === "viewed" ? "bg-white/20" : "bg-primary/10 text-primary"
                }`}>{revealedContacts.size}</span>
              )}
            </button>
            <button
              onClick={() => { vibrate(); setSpaceFilter("unviewed"); }}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 ${
                spaceFilter === "unviewed"
                  ? "bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white shadow-sm"
                  : "bg-neutral-100 text-neutral-500 hover:bg-neutral-200"
              }`}
              data-testid="filter-unviewed"
            >
              <EyeOff size={12} />
              Unviewed
            </button>
          </div>}

          {isLoading || isLocating ? (
            <div className="flex flex-col items-center justify-center py-20">
              {isLocating ? (
                <>
                  <div className="relative w-32 h-32 flex items-center justify-center mb-6">
                    <motion.div
                      className="absolute inset-0 rounded-full border-2 border-[#4f0073]/30"
                      animate={{ scale: [1, 2.2], opacity: [0.6, 0] }}
                      transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut" }}
                    />
                    <motion.div
                      className="absolute inset-0 rounded-full border-2 border-[#7b1fa2]/25"
                      animate={{ scale: [1, 2.5], opacity: [0.5, 0] }}
                      transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut", delay: 0.4 }}
                    />
                    <motion.div
                      className="absolute inset-0 rounded-full border-2 border-[#e040fb]/20"
                      animate={{ scale: [1, 2.8], opacity: [0.4, 0] }}
                      transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut", delay: 0.8 }}
                    />
                    <motion.div
                      className="w-16 h-16 rounded-full bg-gradient-to-br from-[#4f0073] to-[#7b1fa2] flex items-center justify-center shadow-xl shadow-[#4f0073]/25"
                      animate={{ scale: [1, 1.08, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                    >
                      <LocateFixed className="w-7 h-7 text-white" />
                    </motion.div>
                  </div>
                  <p className="text-sm font-semibold text-neutral-700">Fetching nearest providers...</p>
                  <p className="text-xs text-neutral-400 mt-1">Detecting your location</p>
                </>
              ) : (
                <>
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#4f0073] to-[#7b1fa2] flex items-center justify-center mb-4 shadow-lg">
                    <Loader2 className="w-7 h-7 text-white animate-spin" />
                  </div>
                  <p className="text-sm font-semibold text-neutral-700">Loading parking spaces...</p>
                  <p className="text-xs text-neutral-400 mt-1">Finding spaces near you</p>
                </>
              )}
            </div>
          ) : filteredSpaces.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 px-6">
              <div className="relative mb-6">
                {searchQuery ? (
                  <div className="w-28 h-28 bg-gradient-to-br from-orange-50 to-orange-100 rounded-3xl flex items-center justify-center shadow-lg shadow-orange-100/50 border border-orange-200/40">
                    <Search className="w-14 h-14 text-orange-400" />
                  </div>
                ) : (
                  <div className="w-28 h-28 bg-gradient-to-br from-purple-50 via-white to-purple-100 rounded-3xl flex flex-col items-center justify-center shadow-lg shadow-purple-200/50 border border-purple-200/40 gap-1">
                    <div className="flex items-center gap-1">
                      <Car className="w-10 h-10 text-primary/70" />
                      <Bike className="w-8 h-8 text-primary/50" />
                    </div>
                    <ParkingCircle className="w-6 h-6 text-primary/40" />
                  </div>
                )}
              </div>
              {searchQuery ? (
                <>
                  <h4 className="text-lg font-bold text-neutral-800 mb-2" data-testid="text-no-results">No Results Found</h4>
                  <p className="text-neutral-500 text-sm text-center mb-6 max-w-[250px]">
                    No parking spaces match "{searchQuery}". Try a different search.
                  </p>
                  <button
                    onClick={() => { setSearchQuery(""); setUserLocation(""); }}
                    className="group flex items-center gap-3 px-6 py-3.5 border-2 border-[#4f0073] text-[#4f0073] font-semibold rounded-2xl hover:bg-purple-50 active:scale-95 transition-all duration-300"
                    data-testid="button-clear-search-results"
                  >
                    <Search size={20} />
                    Clear Search
                  </button>
                </>
              ) : (
                <>
                  <h4 className="text-lg font-bold text-neutral-800 mb-2" data-testid="text-no-spaces">No Parking Spaces Yet</h4>
                  <p className="text-neutral-500 text-sm text-center max-w-[250px]">
                    No spaces are available right now. Check back soon for new parking listings!
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-4 py-1">
              {filteredSpaces.map((space) => {
                const distanceText = getDistanceText(space);
                const isRevealed = isPremium && revealedContacts.has(space.id);
                return (
                <div
                  key={space.id}
                  className="bg-white rounded-2xl overflow-hidden transition-all duration-200"
                  style={{ boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08), 0 1px 6px rgba(79, 0, 115, 0.06)" }}
                  data-testid={`card-space-${space.id}`}
                >
                  <div className="p-4 relative overflow-hidden">
                    <div className="absolute -bottom-3 -right-3 opacity-[0.04] pointer-events-none">
                      {space.parkingType === "bike" ? (
                        <Bike size={100} className="text-neutral-900" />
                      ) : space.parkingType === "both" ? (
                        <div className="flex items-end gap-0">
                          <Car size={80} className="text-neutral-900" />
                          <Bike size={70} className="text-neutral-900 -ml-4" />
                        </div>
                      ) : (
                        <Car size={100} className="text-neutral-900" />
                      )}
                    </div>
                    <div className="flex items-start gap-3 mb-3">
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${space.parkingType === "bike" ? "bg-gradient-to-br from-blue-500 to-blue-600" : space.parkingType === "both" ? "bg-gradient-to-br from-[#4f0073] to-[#9c27b0]" : "bg-gradient-to-br from-green-500 to-emerald-600"}`}>
                        {space.parkingType === "bike" ? (
                          <Bike className="w-5 h-5 text-white" />
                        ) : space.parkingType === "both" ? (
                          <div className="flex items-center gap-0.5">
                            <Car className="w-3.5 h-3.5 text-white" />
                            <Bike className="w-3.5 h-3.5 text-white" />
                          </div>
                        ) : (
                          <Car className="w-5 h-5 text-white" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-neutral-900 text-sm">{space.serviceName}</h4>
                          {timeAgo(space.bookedAt) && (
                            <span className="text-[10px] font-semibold text-primary bg-primary/5 border border-primary/15 px-2 py-0.5 rounded-full flex-shrink-0 ml-2">
                              {timeAgo(space.bookedAt)}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-0.5">by {space.ownerName}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1">
                        <IndianRupee size={14} className="text-[#4f0073]" />
                        <span className="font-bold text-base text-[#4f0073]">{space.rent}</span>
                        <span className="text-[10px] text-neutral-400">/mo</span>
                      </div>
                      <div className="flex items-center gap-3">
                        {distanceText && (
                          <div className="flex items-center text-[11px] text-orange-600 font-semibold">
                            <Navigation size={10} className="mr-1 text-orange-500" />
                            {distanceText}
                          </div>
                        )}
                        <div className="flex items-center text-[11px] text-neutral-500">
                          <Calendar size={10} className="mr-1 text-neutral-400" />
                          {formatDisplayDate(space.date)}
                        </div>
                      </div>
                    </div>

                    {isPremium ? (
                      <div className="mb-2">
                        <div className="flex items-center gap-2 py-1">
                          <MapPin size={13} className="text-primary flex-shrink-0" />
                          <span className="text-[12px] text-neutral-600 truncate">{space.location}</span>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={(e) => { e.stopPropagation(); vibrate(); setShowSubscriptionPopup(true); }}
                        className="mb-2 flex items-center gap-2 py-1 w-full text-left"
                        data-testid={`button-location-premium-${space.id}`}
                      >
                        <MapPin size={13} className="text-neutral-300 flex-shrink-0" />
                        <span className="text-[12px] text-neutral-400 italic">Get Premium to view location</span>
                        <Crown size={10} className="text-yellow-500 ml-auto" />
                      </button>
                    )}

                    <div className="overflow-hidden">
                      <AnimatePresence mode="wait">
                        {isRevealed ? (
                          <motion.div
                            key={`revealed-${space.id}`}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.35, ease: "easeOut", delay: 0.15 }}
                            className="mb-2 flex items-center justify-between"
                          >
                            <div className="flex items-center gap-2">
                              <Phone size={13} className="text-green-600 flex-shrink-0" />
                              <span className="font-mono text-[13px] text-green-700 font-semibold" data-testid={`text-phone-${space.id}`}>{space.ownerPhone}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <a
                                href={`https://wa.me/91${space.ownerPhone}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="w-9 h-9 rounded-full bg-green-500 hover:bg-green-600 flex items-center justify-center transition-colors shadow-sm"
                                data-testid={`button-whatsapp-${space.id}`}
                              >
                                <MessageCircle size={16} className="text-white" />
                              </a>
                              <a
                                href={`tel:+91${space.ownerPhone}`}
                                onClick={(e) => e.stopPropagation()}
                                className="w-9 h-9 rounded-full bg-primary hover:bg-purple-800 flex items-center justify-center transition-colors shadow-sm"
                                data-testid={`button-call-${space.id}`}
                              >
                                <Phone size={16} className="text-white" />
                              </a>
                              {(space.latitude && space.longitude) && (
                                <button
                                  onClick={(e) => openDirections(e, space)}
                                  className="w-9 h-9 rounded-full bg-blue-500 hover:bg-blue-600 flex items-center justify-center transition-colors shadow-sm"
                                  data-testid={`button-directions-${space.id}`}
                                >
                                  <Navigation size={16} className="text-white" />
                                </button>
                              )}
                            </div>
                          </motion.div>
                        ) : (
                          <motion.div
                            key={`btn-${space.id}`}
                            exit={{ clipPath: "inset(0 0 0 100%)", opacity: 0 }}
                            transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
                            className="mb-3"
                          >
                            <button
                              onClick={(e) => { e.stopPropagation(); vibrate(); if (!requireLogin("view contact details")) return; handleViewContactForSpace(space.id); }}
                              className="w-full flex items-center justify-center gap-2 h-10 rounded-xl text-[12px] font-semibold bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white hover:from-[#3a0056] hover:to-[#6a1b9a] transition-all shadow-xl shadow-[#4f0073]/25 active:scale-[0.98]"
                              data-testid={`button-view-contacts-${space.id}`}
                            >
                              {isPremium ? (
                                <><Eye size={14} /> View Contact</>
                              ) : (
                                <><Crown size={14} className="text-yellow-300" /> Subscribe to View Contact</>
                              )}
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-neutral-100">
                      <button
                        onClick={(e) => { vibrate(); handleInterest(e, space.id); }}
                        disabled={interestLoading === space.id}
                        className={`h-8 px-3 rounded-full flex items-center gap-1.5 text-[11px] font-semibold border transition-all active:scale-95 ${userInterests.has(space.id) ? "bg-primary text-white border-primary" : "bg-white text-primary border-primary/30 hover:bg-purple-50"}`}
                        data-testid={`button-interested-${space.id}`}
                      >
                        <ThumbsUp size={12} className={userInterests.has(space.id) ? "fill-white" : ""} />
                        {userInterests.has(space.id) ? "Interested" : "I'm Interested"}
                      </button>
                      <div className="flex items-center gap-1.5">
                        {space.photos.length > 0 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              vibrate();
                              if (!requireLogin("view photos")) return;
                              if (!isPremium) { setShowSubscriptionPopup(true); return; }
                              handleViewPhotos(e, space.photos);
                            }}
                            className="h-8 px-2.5 rounded-full flex items-center gap-1 text-[11px] font-bold bg-orange-500 text-white hover:bg-orange-600 transition-colors shadow-sm"
                            data-testid={`button-photos-${space.id}`}
                          >
                            {isPremium ? <ImageIcon size={12} /> : <Crown size={12} />}
                            {space.photos.length}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                );
              })}

              {parkingSpaces.length > 0 && parkingSpaces.length < totalSpaces && (
                <div className="flex flex-col items-center gap-2 py-5">
                  <p className="text-xs text-neutral-400">
                    Showing {parkingSpaces.length} of {totalSpaces} spaces
                  </p>
                  <button
                    onClick={() => { vibrate(); loadMoreSpaces(); }}
                    disabled={isLoadingMore}
                    className="flex items-center gap-2.5 px-7 py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white text-sm font-bold rounded-full shadow-xl shadow-[#4f0073]/25 active:scale-95 transition-all disabled:opacity-60"
                    data-testid="button-load-more"
                  >
                    {isLoadingMore ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Loading more spaces...
                      </>
                    ) : (
                      <>
                        <ParkingCircle size={16} />
                        Load More Spaces
                        <ChevronDown size={14} />
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {adVideoUrl && adVideoEnabled && (
          <div className="px-6 mb-8">
            <div className="relative aspect-[2/1] rounded-3xl overflow-hidden shadow-lg">
              <video
                src={adVideoUrl}
                className="w-full h-full object-cover"
                autoPlay
                loop
                muted
                playsInline
              />
            </div>
          </div>
        )}

        <AnimatePresence>
        {/* Subscription Plans Popup */}
        {showSubscriptionPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
            onClick={() => { setShowSubscriptionPopup(false); setChoosePlan(null); }}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mx-auto mb-4">
                <Crown size={32} className="text-yellow-500" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-1">Subscribe to View</h3>
              <p className="text-neutral-500 text-xs mb-5">Choose a plan to view owner contact details</p>

              <div className="space-y-2.5 text-left">
                {plans.map((plan) => (
                  <button
                    key={plan.key}
                    onClick={() => { vibrate(); setChoosePlan(plan.key); }}
                    className={`w-full flex items-center justify-between rounded-xl px-4 py-3 transition-all active:scale-[0.98] relative ${
                      choosePlan === plan.key
                        ? "border-2 border-primary bg-purple-50 ring-2 ring-primary/20"
                        : plan.key === "standard"
                        ? "border-2 border-primary/40 bg-purple-50/40 hover:border-primary"
                        : plan.key === "premium"
                        ? "border border-yellow-300 bg-yellow-50/50 hover:border-yellow-400"
                        : "border border-neutral-200 hover:border-primary/50 hover:bg-purple-50/30"
                    }`}
                    data-testid={`plan-${plan.key}`}
                  >
                    {plan.key === "standard" && !choosePlan && (
                      <div className="absolute -top-2 right-3 bg-primary text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                        Popular
                      </div>
                    )}
                    {choosePlan === plan.key && (
                      <div className="absolute -top-2 right-3 bg-green-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Check size={10} /> Selected
                      </div>
                    )}
                    <div className="flex items-center gap-2.5">
                      {plan.key === "basic" ? (
                        <Shield className="w-5 h-5 text-blue-500" />
                      ) : plan.key === "standard" ? (
                        <Zap className="w-5 h-5 text-primary" />
                      ) : (
                        <Crown className="w-5 h-5 text-yellow-500" />
                      )}
                      <div className="text-left">
                        <span className="text-sm font-semibold block">{plan.name}</span>
                        <span className="text-[10px] text-neutral-400">
                          {plan.views === -1 ? "Unlimited views" : `${plan.views} views`}
                        </span>
                      </div>
                    </div>
                    <span className="text-sm font-bold text-primary">₹{plan.price}</span>
                  </button>
                ))}
              </div>

              <div className="flex gap-3 mt-5">
                <button
                  onClick={() => { setShowSubscriptionPopup(false); setChoosePlan(null); }}
                  className="flex-1 py-3 bg-neutral-100 text-neutral-700 font-bold rounded-2xl hover:bg-neutral-200 transition-colors"
                  data-testid="button-close-subscription"
                >
                  Maybe Later
                </button>
                <button
                  onClick={() => {
                    vibrate();
                    const plan = plans.find(p => p.key === choosePlan);
                    if (plan) handleSelectPlan(plan);
                  }}
                  disabled={!choosePlan}
                  className="flex-1 py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  data-testid="button-subscribe-submit"
                >
                  <Crown size={16} />
                  Subscribe
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Payment Processing Popup */}
        {showPaymentProcessing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4 animate-pulse">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Processing Payment</h3>
              <p className="text-neutral-500 text-xs">
                Please wait while we process your ₹{selectedPlan?.price} payment for {selectedPlan?.name} plan...
              </p>
            </motion.div>
          </motion.div>
        )}

        {/* Payment Success Popup */}
        {showPaymentSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
            onClick={() => setShowPaymentSuccess(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-1">Payment Successful!</h3>
              <p className="text-neutral-500 text-xs mb-4">
                You are now a <span className="font-bold text-primary capitalize">{selectedPlan?.name}</span> member!
              </p>

              <div className="w-full bg-purple-50 rounded-xl p-3 space-y-2 text-left">
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-500">Plan</span>
                  <span className="font-semibold capitalize">{selectedPlan?.name}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-500">Amount Paid</span>
                  <span className="font-semibold">₹{selectedPlan?.price}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-500">Views</span>
                  <span className="font-semibold">{selectedPlan?.views === -1 ? "Unlimited" : selectedPlan?.views}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-neutral-500">Valid For</span>
                  <span className="font-semibold">30 days</span>
                </div>
              </div>

              <button
                onClick={() => setShowPaymentSuccess(false)}
                className="mt-5 w-full py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors flex items-center justify-center gap-2"
                data-testid="button-payment-done"
              >
                <Star size={16} />
                Start Exploring
              </button>
            </motion.div>
          </motion.div>
        )}

        {/* Premium Details Popup */}
        {showPremiumDetails && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
            onClick={() => setShowPremiumDetails(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mx-auto mb-4">
                <Crown size={32} className="text-yellow-500" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-4">Your Premium Plan</h3>

              <div className="bg-gradient-to-br from-purple-50 to-yellow-50 rounded-xl p-4 space-y-3 text-left">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-neutral-500">Plan</span>
                  <span className="text-sm font-bold capitalize flex items-center gap-1">
                    {premiumPlan === "basic" && <Shield className="w-4 h-4 text-blue-500" />}
                    {premiumPlan === "standard" && <Zap className="w-4 h-4 text-primary" />}
                    {premiumPlan === "premium" && <Crown className="w-4 h-4 text-yellow-500" />}
                    {premiumPlan}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-neutral-500">Views Remaining</span>
                  <span className="text-sm font-bold">
                    {premiumPlan === "premium" ? "Unlimited" : `${premiumViewsRemaining}/${premiumPlan === "basic" ? 10 : 20}`}
                  </span>
                </div>
                {premiumExpiresAt && (
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-neutral-500">Expires</span>
                    <span className="text-sm font-bold">
                      {new Date(premiumExpiresAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex gap-3 mt-5">
                <button
                  onClick={() => setShowPremiumDetails(false)}
                  className="flex-1 py-3 bg-neutral-100 text-neutral-700 font-bold rounded-2xl hover:bg-neutral-200 transition-colors"
                  data-testid="button-close-premium-details"
                >
                  Close
                </button>
                {premiumPlan !== "premium" && premiumViewsRemaining <= 3 && (
                  <button
                    onClick={() => { setShowPremiumDetails(false); setShowSubscriptionPopup(true); }}
                    className="flex-1 py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors flex items-center justify-center gap-2"
                    data-testid="button-upgrade-plan"
                  >
                    <Zap size={16} />
                    Upgrade
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Photo Viewer Popup */}
        {showPhotoViewer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center px-4"
            onClick={() => setShowPhotoViewer(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-black/95 rounded-3xl overflow-hidden shadow-2xl max-w-md w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                <button
                  onClick={() => setShowPhotoViewer(false)}
                  className="absolute top-3 right-3 z-20 w-9 h-9 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                  data-testid="button-close-photos"
                >
                  <X size={18} />
                </button>

                <div className="relative w-full aspect-square bg-black flex items-center justify-center">
                  {viewingPhotos.length > 0 && (
                    <img
                      src={viewingPhotos[activePhotoIndex]}
                      alt={`Photo ${activePhotoIndex + 1}`}
                      className="w-full h-full object-contain"
                    />
                  )}

                  {viewingPhotos.length > 1 && (
                    <>
                      <button
                        onClick={() => setActivePhotoIndex((prev) => (prev - 1 + viewingPhotos.length) % viewingPhotos.length)}
                        className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                        data-testid="button-photo-prev"
                      >
                        <ChevronLeft size={20} />
                      </button>
                      <button
                        onClick={() => setActivePhotoIndex((prev) => (prev + 1) % viewingPhotos.length)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                        data-testid="button-photo-next"
                      >
                        <ChevronRight size={20} />
                      </button>
                    </>
                  )}
                </div>

                <div className="bg-black/80 px-4 py-3 flex items-center justify-center gap-2">
                  {viewingPhotos.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setActivePhotoIndex(index)}
                      className={`w-2.5 h-2.5 rounded-full transition-all ${index === activePhotoIndex ? "bg-white scale-110" : "bg-white/30"}`}
                      data-testid={`button-photo-dot-${index}`}
                    />
                  ))}
                  <span className="text-white/60 text-xs ml-2">{activePhotoIndex + 1}/{viewingPhotos.length}</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Help & Support Popup */}
        {showSupportPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
            onClick={() => setShowSupportPopup(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="bg-white rounded-3xl p-6 text-center shadow-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <Phone size={32} className="text-primary" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900 mb-1">Help & Support</h3>
              <p className="text-neutral-500 text-xs mb-5">We're here to help!</p>

              <div className="space-y-2 text-left">
                <a
                  href={`tel:${supportPhone.replace(/\s/g, '')}`}
                  className="flex items-center gap-3 p-3 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
                  data-testid="link-call-support-worker"
                >
                  <div className="w-9 h-9 bg-green-500 rounded-full flex items-center justify-center">
                    <Phone className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-neutral-900 text-sm">Call Us</p>
                    <p className="text-xs text-neutral-600">{supportPhone}</p>
                  </div>
                </a>
                <a
                  href={`mailto:${supportEmail}`}
                  className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
                  data-testid="link-email-support-worker"
                >
                  <div className="w-9 h-9 bg-blue-500 rounded-full flex items-center justify-center">
                    <Mail className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-neutral-900 text-sm">Email Us</p>
                    <p className="text-xs text-neutral-600">{supportEmail}</p>
                  </div>
                </a>
              </div>

              <button
                onClick={() => setShowSupportPopup(false)}
                className="mt-5 w-full py-3 bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-bold rounded-2xl hover:from-[#3d0059] hover:to-[#6a1b9a] shadow-xl shadow-[#4f0073]/25 transition-colors"
                data-testid="button-close-support-worker"
              >
                Close
              </button>
            </motion.div>
          </motion.div>
        )}
        </AnimatePresence>

        {/* Notifications Sheet */}
        <Sheet open={notificationsOpen} onOpenChange={setNotificationsOpen}>
          <SheetContent side="right" className="w-[70vw] p-0 bg-white shadow-2xl border-none">
            <SheetHeader className="border-b p-4 sticky top-0 bg-white flex flex-row items-center justify-between">
              <SheetTitle className="text-lg font-bold">Notifications</SheetTitle>
              {notifications.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearNotifications}
                  disabled={isClearingNotifications}
                  className="text-red-500 hover:text-red-600 hover:bg-red-50 text-xs"
                  data-testid="button-clear-notifications-worker"
                >
                  {isClearingNotifications ? "Clearing..." : "Clear All"}
                </Button>
              )}
            </SheetHeader>
            <div className="overflow-y-auto h-[calc(100vh-100px)]">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-neutral-500">
                  <Bell className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No notifications yet</p>
                </div>
              ) : (
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 cursor-pointer transition-colors hover:bg-neutral-50 ${!notification.isRead ? "bg-primary/5" : ""}`}
                      data-testid={`notification-worker-${notification.id}`}
                    >
                      <div className="flex gap-3 items-start">
                        <div className="text-xl mt-1">{getNotificationIcon(notification.type)}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-sm text-neutral-900">{notification.title}</h3>
                            {!notification.isRead && <span className="w-2 h-2 bg-primary rounded-full"></span>}
                          </div>
                          <p className="text-xs text-neutral-600 mt-1 line-clamp-2">{notification.message}</p>
                          <p className="text-xs text-neutral-400 mt-2">{formatTimestamp(notification.createdAt)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </MobileLayout>
  );
}
