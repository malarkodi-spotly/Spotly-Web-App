import { type User, type InsertUser, users, type WorkerProfile, type InsertWorkerProfile, workerProfiles, type City, type InsertCity, cities, type Booking, type InsertBooking, bookings, type Notification, type InsertNotification, notifications, type Service, type InsertService, services, type Payment, type InsertPayment, payments, type Disclaimer, type InsertDisclaimer, disclaimers, type AppSetting, type InsertAppSetting, appSettings, type ServicePincode, type InsertServicePincode, servicePincodes, type Interest, type InsertInterest, interests, viewedContacts } from "@shared/schema";
import { db } from "./db";
import { eq, and, asc, desc, sql, ne, or, isNull, inArray } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByMobile(mobile: string, role: string): Promise<User | undefined>;
  getUserByMobileAnyRole(mobile: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<Pick<User, 'name' | 'email' | 'city'>>): Promise<User | undefined>;
  updateUserVerification(id: string): Promise<User | undefined>;
  activatePremium(id: string): Promise<User | undefined>;
  activatePremiumWithPlan(id: string, plan: string, views: number): Promise<User | undefined>;
  usePremiumView(id: string): Promise<User | undefined>;
  
  // Worker profile methods
  createWorkerProfile(profile: InsertWorkerProfile): Promise<WorkerProfile>;
  getWorkerProfileByUserId(userId: string): Promise<WorkerProfile | undefined>;
  getAllWorkerProfiles(city?: string): Promise<(WorkerProfile & { name: string })[]>;
  updateWorkerProfile(userId: string, profile: Partial<InsertWorkerProfile>): Promise<WorkerProfile | undefined>;
  
  // City methods
  getAllCities(): Promise<City[]>;
  getActiveCities(): Promise<City[]>;
  createCity(city: InsertCity): Promise<City>;
  updateCity(id: string, city: Partial<InsertCity>): Promise<City | undefined>;
  deleteCity(id: string): Promise<void>;
  
  // Booking methods
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingById(id: string): Promise<Booking | undefined>;
  getBookingsByCustomer(customerId: string, limit?: number, offset?: number): Promise<{ bookings: Booking[]; total: number }>;
  getBookingsByWorker(workerId: string, status?: string): Promise<Booking[]>;
  getPendingBookings(city?: string, limit?: number, offset?: number, userLat?: number, userLng?: number, radiusKm?: number): Promise<{ bookings: Booking[]; total: number }>;
  updateBookingStatus(id: string, status: string, workerId?: string | null): Promise<Booking | undefined>;
  updateBooking(id: string, data: Partial<Booking>): Promise<Booking | undefined>;
  deleteBooking(id: string): Promise<void>;
  rateBooking(id: string, rating: number): Promise<Booking | undefined>;
  
  // Notification methods
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  markNotificationAsRead(id: string): Promise<Notification | undefined>;
  markAllNotificationsAsRead(userId: string): Promise<void>;
  updateWorkerProfileLocation(userId: string, latitude: number, longitude: number): Promise<void>;
  createNotificationForAllWorkers(notification: Omit<InsertNotification, 'userId'>, city?: string, excludeUserIds?: string[]): Promise<void>;
  createNotificationForNearbyWorkers(notification: Omit<InsertNotification, 'userId'>, lat: number, lng: number, radiusKm?: number): Promise<string[]>;
  createNotificationForAllCustomers(notification: Omit<InsertNotification, 'userId'>): Promise<void>;
  createNotificationForAll(notification: Omit<InsertNotification, 'userId'>): Promise<void>;
  
  // Disclaimer methods
  getAllDisclaimers(): Promise<Disclaimer[]>;
  getDisclaimerByLanguage(language: string): Promise<Disclaimer | undefined>;
  createDisclaimer(disclaimer: InsertDisclaimer): Promise<Disclaimer>;
  updateDisclaimer(id: string, disclaimer: Partial<InsertDisclaimer>): Promise<Disclaimer | undefined>;
  deleteDisclaimer(id: string): Promise<void>;
  
  // App Settings methods
  getAllSettings(): Promise<AppSetting[]>;
  getSetting(key: string): Promise<AppSetting | undefined>;
  upsertSetting(key: string, value: string, description?: string): Promise<AppSetting>;
  
  // Service Pincode methods
  getAllServicePincodes(): Promise<ServicePincode[]>;
  getActiveServicePincodes(): Promise<ServicePincode[]>;
  createServicePincode(pincode: InsertServicePincode): Promise<ServicePincode>;
  updateServicePincode(id: string, pincode: Partial<InsertServicePincode>): Promise<ServicePincode | undefined>;
  deleteServicePincode(id: string): Promise<void>;

  // Interest methods
  addInterest(bookingId: string, userId: string): Promise<Interest>;
  removeInterest(bookingId: string, userId: string): Promise<void>;
  getInterestCount(bookingId: string): Promise<number>;
  getInterestCounts(bookingIds: string[]): Promise<Record<string, number>>;
  getUserInterests(userId: string): Promise<string[]>;

  // Viewed contacts methods
  addViewedContact(userId: string, bookingId: string): Promise<void>;
  getViewedContacts(userId: string): Promise<string[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.id, id))
      .limit(1);
    return result[0];
  }

  async getUserByMobile(mobile: string, role: string): Promise<User | undefined> {
    const result = await db
      .select()
      .from(users)
      .where(and(eq(users.mobile, mobile), eq(users.role, role)))
      .limit(1);
    return result[0];
  }

  async getUserByMobileAnyRole(mobile: string): Promise<User | undefined> {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.mobile, mobile))
      .limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return result[0];
  }

  async updateUser(id: string, data: Partial<Pick<User, 'name' | 'email' | 'city'>>): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async updateUserVerification(id: string): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ isVerified: true })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async activatePremium(id: string): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ isPremium: true, premiumActivatedAt: new Date().toISOString() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async activatePremiumWithPlan(id: string, plan: string, views: number): Promise<User | undefined> {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);
    const result = await db
      .update(users)
      .set({
        isPremium: true,
        premiumActivatedAt: new Date().toISOString(),
        premiumPlan: plan,
        premiumViewsRemaining: views === -1 ? 9999 : views,
        premiumExpiresAt: expiresAt.toISOString(),
      })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async usePremiumView(id: string): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    if (user.premiumPlan === "premium") return user;
    const result = await db
      .update(users)
      .set({
        premiumViewsRemaining: sql`GREATEST(${users.premiumViewsRemaining} - 1, 0)`,
      })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async createWorkerProfile(profile: InsertWorkerProfile): Promise<WorkerProfile> {
    const result = await db
      .insert(workerProfiles)
      .values(profile)
      .returning();
    return result[0];
  }

  async getWorkerProfileByUserId(userId: string): Promise<WorkerProfile | undefined> {
    const result = await db
      .select()
      .from(workerProfiles)
      .where(eq(workerProfiles.userId, userId))
      .limit(1);
    return result[0];
  }

  async getAllWorkerProfiles(city?: string): Promise<(WorkerProfile & { name: string })[]> {
    let query = db
      .select({
        id: workerProfiles.id,
        userId: workerProfiles.userId,
        age: workerProfiles.age,
        gender: workerProfiles.gender,
        services: workerProfiles.services,
        location: workerProfiles.location,
        city: workerProfiles.city,
        latitude: workerProfiles.latitude,
        longitude: workerProfiles.longitude,
        rating: workerProfiles.rating,
        reviews: workerProfiles.reviews,
        mobile: sql<string>`COALESCE(${workerProfiles.mobile}, ${users.mobile})`.as('mobile'),
        whatsapp: sql<string>`COALESCE(${workerProfiles.whatsapp}, ${users.mobile})`.as('whatsapp'),
        foodType: workerProfiles.foodType,
        isFavorite: workerProfiles.isFavorite,
        workConditions: workerProfiles.workConditions,
        name: users.name,
      })
      .from(workerProfiles)
      .innerJoin(users, eq(workerProfiles.userId, users.id));
    
    if (city) {
      // Strictly filter by selected city only - workers must have matching city
      query = query.where(eq(workerProfiles.city, city)) as typeof query;
    }
    
    return await query;
  }

  async updateWorkerProfile(userId: string, profile: Partial<InsertWorkerProfile>): Promise<WorkerProfile | undefined> {
    const result = await db
      .update(workerProfiles)
      .set(profile)
      .where(eq(workerProfiles.userId, userId))
      .returning();
    return result[0];
  }

  async getAllCities(): Promise<City[]> {
    const result = await db
      .select()
      .from(cities)
      .orderBy(asc(cities.displayOrder));
    return result;
  }

  async getActiveCities(): Promise<City[]> {
    const result = await db
      .select()
      .from(cities)
      .where(eq(cities.isActive, true))
      .orderBy(asc(cities.displayOrder));
    return result;
  }

  async createCity(city: InsertCity): Promise<City> {
    const result = await db
      .insert(cities)
      .values(city)
      .returning();
    return result[0];
  }

  async updateCity(id: string, city: Partial<InsertCity>): Promise<City | undefined> {
    const result = await db
      .update(cities)
      .set(city)
      .where(eq(cities.id, id))
      .returning();
    return result[0];
  }

  async deleteCity(id: string): Promise<void> {
    await db
      .delete(cities)
      .where(eq(cities.id, id));
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const result = await db
      .insert(bookings)
      .values(booking)
      .returning();
    return result[0];
  }

  async getBookingById(id: string): Promise<Booking | undefined> {
    const result = await db
      .select()
      .from(bookings)
      .where(eq(bookings.id, id))
      .limit(1);
    return result[0];
  }

  async getBookingsByCustomer(customerId: string, limit?: number, offset?: number): Promise<{ bookings: Booking[]; total: number }> {
    const countResult = await db
      .select({ count: sql<number>`count(*)` })
      .from(bookings)
      .where(eq(bookings.customerId, customerId));
    const total = Number(countResult[0]?.count || 0);

    let query = db
      .select()
      .from(bookings)
      .where(eq(bookings.customerId, customerId))
      .orderBy(desc(bookings.bookedAt));

    if (limit != null) (query as any) = query.limit(limit);
    if (offset != null) (query as any) = query.offset(offset);

    const result = await query;
    return { bookings: result, total };
  }

  async getBookingsByWorker(workerId: string, status?: string): Promise<Booking[]> {
    if (status) {
      const result = await db
        .select()
        .from(bookings)
        .where(and(eq(bookings.workerId, workerId), eq(bookings.status, status)))
        .orderBy(desc(bookings.bookedAt));
      return result;
    }
    
    const result = await db
      .select()
      .from(bookings)
      .where(eq(bookings.workerId, workerId))
      .orderBy(desc(bookings.bookedAt));
    return result;
  }

  async getPendingBookings(cityId?: string, limit?: number, offset?: number, userLat?: number, userLng?: number, radiusKm?: number): Promise<{ bookings: Booking[]; total: number }> {
    const pendingCondition = and(eq(bookings.status, "pending"), sql`${bookings.workerId} IS NULL`);
    let whereCondition = pendingCondition;

    if (userLat != null && userLng != null && radiusKm != null) {
      whereCondition = and(
        eq(bookings.status, "pending"),
        sql`${bookings.workerId} IS NULL`,
        sql`${bookings.latitude} IS NOT NULL`,
        sql`${bookings.longitude} IS NOT NULL`,
        sql`(
          6371 * acos(
            cos(radians(${userLat})) * cos(radians(${bookings.latitude}))
            * cos(radians(${bookings.longitude}) - radians(${userLng}))
            + sin(radians(${userLat})) * sin(radians(${bookings.latitude}))
          )
        ) <= ${radiusKm}`
      );
    } else if (cityId) {
      const cityResult = await db.select().from(cities).where(eq(cities.id, cityId)).limit(1);
      const cityName = cityResult[0]?.name;
      
      if (cityName) {
        const lowerCityName = cityName.toLowerCase();
        const isBlr = lowerCityName === 'bangalore' || lowerCityName === 'bengaluru';
        
        whereCondition = and(
          eq(bookings.status, "pending"), 
          sql`${bookings.workerId} IS NULL`,
          or(
            sql`lower(${bookings.city}) = ${lowerCityName}`,
            isBlr ? sql`lower(${bookings.city}) IN ('bangalore', 'bengaluru')` : sql`false`,
            sql`${bookings.city} IS NULL`,
            sql`lower(${bookings.location}) LIKE '%' || ${lowerCityName} || '%'`,
            isBlr ? sql`lower(${bookings.location}) LIKE '%bengaluru%' OR lower(${bookings.location}) LIKE '%bangalore%'` : sql`false`
          )
        );
      }
    }

    const countResult = await db
      .select({ count: sql<number>`count(*)` })
      .from(bookings)
      .where(whereCondition);
    const total = Number(countResult[0]?.count || 0);

    let query = db
      .select()
      .from(bookings)
      .where(whereCondition)
      .orderBy(desc(bookings.bookedAt));

    if (limit != null) (query as any) = query.limit(limit);
    if (offset != null) (query as any) = query.offset(offset);

    const result = await query;
    return { bookings: result, total };
  }

  async updateBookingStatus(id: string, status: string, workerId?: string | null): Promise<Booking | undefined> {
    const updateData: Partial<Booking> = { status };
    // Handle workerId - if explicitly passed (even as null), update it
    if (workerId !== undefined) {
      updateData.workerId = workerId;
    }
    
    // For accepting a job, only allow if booking is still pending (prevents double acceptance)
    if (status === "accepted" && workerId) {
      const result = await db
        .update(bookings)
        .set(updateData)
        .where(and(eq(bookings.id, id), eq(bookings.status, "pending")))
        .returning();
      return result[0]; // Returns undefined if booking was already accepted
    }
    
    const result = await db
      .update(bookings)
      .set(updateData)
      .where(eq(bookings.id, id))
      .returning();
    return result[0];
  }

  async updateBooking(id: string, data: Partial<Booking>): Promise<Booking | undefined> {
    const result = await db
      .update(bookings)
      .set(data)
      .where(eq(bookings.id, id))
      .returning();
    return result[0];
  }

  async deleteBooking(id: string): Promise<void> {
    await db.transaction(async (tx) => {
      await tx.delete(interests).where(eq(interests.bookingId, id));
      await tx.delete(viewedContacts).where(eq(viewedContacts.bookingId, id));
      await tx.delete(notifications).where(eq(notifications.bookingId, id));
      await tx.delete(bookings).where(eq(bookings.id, id));
    });
  }

  async rateBooking(id: string, rating: number): Promise<Booking | undefined> {
    const result = await db
      .update(bookings)
      .set({ rating, ratedAt: new Date().toISOString() })
      .where(eq(bookings.id, id))
      .returning();
    return result[0];
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const result = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return result[0];
  }

  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    const result = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
    return result;
  }

  async markNotificationAsRead(id: string): Promise<Notification | undefined> {
    const result = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return result[0];
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, userId));
  }

  async updateWorkerProfileLocation(userId: string, latitude: number, longitude: number): Promise<void> {
    await db
      .update(workerProfiles)
      .set({ latitude, longitude })
      .where(eq(workerProfiles.userId, userId));
  }

  async createNotificationForAllWorkers(notification: Omit<InsertNotification, 'userId'>, city?: string, excludeUserIds?: string[]): Promise<void> {
    let workerIds: { id: string }[];
    
    if (city) {
      const workersInCity = await db
        .select({ userId: workerProfiles.userId })
        .from(workerProfiles)
        .where(eq(workerProfiles.city, city));
      
      workerIds = workersInCity.map(w => ({ id: w.userId }));
    } else {
      workerIds = await db
        .select({ id: users.id })
        .from(users)
        .where(eq(users.role, "worker"));
    }
    
    const excludeSet = new Set(excludeUserIds || []);
    const valuesToInsert = workerIds
      .filter(w => !excludeSet.has(w.id))
      .map(w => ({ ...notification, userId: w.id }));
    
    if (valuesToInsert.length > 0) {
      const batchSize = 100;
      for (let i = 0; i < valuesToInsert.length; i += batchSize) {
        await db.insert(notifications).values(valuesToInsert.slice(i, i + batchSize));
      }
    }
  }

  async createNotificationForNearbyWorkers(notification: Omit<InsertNotification, 'userId'>, lat: number, lng: number, radiusKm: number = 10): Promise<string[]> {
    const allProfiles = await db
      .select({ userId: workerProfiles.userId, latitude: workerProfiles.latitude, longitude: workerProfiles.longitude })
      .from(workerProfiles);

    const toRad = (deg: number) => deg * Math.PI / 180;
    const haversine = (lat1: number, lng1: number, lat2: number, lng2: number) => {
      const R = 6371;
      const dLat = toRad(lat2 - lat1);
      const dLng = toRad(lng2 - lng1);
      const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };

    const nearbyWorkerIds = allProfiles
      .filter(p => p.latitude && p.longitude && haversine(lat, lng, p.latitude, p.longitude) <= radiusKm)
      .map(p => p.userId);

    if (nearbyWorkerIds.length > 0) {
      const valuesToInsert = nearbyWorkerIds.map(id => ({ ...notification, userId: id }));
      const batchSize = 100;
      for (let i = 0; i < valuesToInsert.length; i += batchSize) {
        await db.insert(notifications).values(valuesToInsert.slice(i, i + batchSize));
      }
    }
    return nearbyWorkerIds;
  }

  async createNotificationForAllCustomers(notification: Omit<InsertNotification, 'userId'>): Promise<void> {
    const customers = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.role, "customer"));
    
    if (customers.length > 0) {
      const valuesToInsert = customers.map(c => ({ ...notification, userId: c.id }));
      const batchSize = 100;
      for (let i = 0; i < valuesToInsert.length; i += batchSize) {
        await db.insert(notifications).values(valuesToInsert.slice(i, i + batchSize));
      }
    }
  }

  async createNotificationForAll(notification: Omit<InsertNotification, 'userId'>): Promise<void> {
    const allUsers = await db
      .select({ id: users.id })
      .from(users);
    
    if (allUsers.length > 0) {
      const valuesToInsert = allUsers.map(u => ({ ...notification, userId: u.id }));
      const batchSize = 100;
      for (let i = 0; i < valuesToInsert.length; i += batchSize) {
        await db.insert(notifications).values(valuesToInsert.slice(i, i + batchSize));
      }
    }
  }

  async clearNotificationsByUser(userId: string): Promise<void> {
    await db
      .delete(notifications)
      .where(eq(notifications.userId, userId));
  }

  async getAllUsers(): Promise<User[]> {
    const result = await db
      .select()
      .from(users);
    return result;
  }

  async getAllBookings(): Promise<Booking[]> {
    const result = await db
      .select()
      .from(bookings)
      .orderBy(desc(bookings.bookedAt));
    return result;
  }

  // Service methods
  async getAllServices(): Promise<Service[]> {
    const result = await db
      .select()
      .from(services)
      .orderBy(asc(services.displayOrder));
    return result;
  }

  async getActiveServices(): Promise<Service[]> {
    const result = await db
      .select()
      .from(services)
      .where(eq(services.isActive, true))
      .orderBy(asc(services.displayOrder));
    return result;
  }

  async createService(service: InsertService): Promise<Service> {
    const result = await db
      .insert(services)
      .values(service)
      .returning();
    return result[0];
  }

  async updateService(id: string, service: Partial<InsertService>): Promise<Service | undefined> {
    const result = await db
      .update(services)
      .set(service)
      .where(eq(services.id, id))
      .returning();
    return result[0];
  }

  async deleteService(id: string): Promise<void> {
    await db
      .delete(services)
      .where(eq(services.id, id));
  }

  // Admin: Delete user and related data
  async deleteUser(id: string): Promise<void> {
    // Get this user's bookings first so we can clean up child records that reference them
    const userBookings = await db.select({ id: bookings.id }).from(bookings).where(eq(bookings.customerId, id));
    const bookingIds = userBookings.map(b => b.id);

    // Delete all related data first (foreign key constraints)
    await db.delete(workerProfiles).where(eq(workerProfiles.userId, id));
    await db.delete(notifications).where(eq(notifications.userId, id));
    // Delete interests created by this user
    await db.delete(interests).where(eq(interests.userId, id));
    // Delete viewedContacts created by this user
    await db.delete(viewedContacts).where(eq(viewedContacts.userId, id));
    // Delete interests + viewedContacts pointing to this user's bookings (if any)
    if (bookingIds.length > 0) {
      await db.delete(interests).where(inArray(interests.bookingId, bookingIds));
      await db.delete(viewedContacts).where(inArray(viewedContacts.bookingId, bookingIds));
    }
    // Delete bookings where user is customer or worker
    await db.delete(bookings).where(eq(bookings.customerId, id));
    await db.delete(bookings).where(eq(bookings.workerId, id));
    // Delete payments
    await db.delete(payments).where(eq(payments.customerId, id));
    // Finally delete the user
    await db.delete(users).where(eq(users.id, id));
  }

  // Admin: Create worker with profile
  async createWorkerWithProfile(userData: InsertUser, profileData: Partial<InsertWorkerProfile>): Promise<{ user: User; profile: WorkerProfile }> {
    const user = await db
      .insert(users)
      .values({ ...userData, role: "worker", isVerified: true })
      .returning();
    
    const profile = await db
      .insert(workerProfiles)
      .values({ ...profileData, userId: user[0].id })
      .returning();
    
    return { user: user[0], profile: profile[0] };
  }

  // Admin: Delete worker profile
  async deleteWorkerProfile(userId: string): Promise<void> {
    await db.delete(workerProfiles).where(eq(workerProfiles.userId, userId));
  }

  // Payment methods
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const result = await db
      .insert(payments)
      .values(payment)
      .returning();
    return result[0];
  }

  async getAllPayments(plan?: string): Promise<Payment[]> {
    const conditions: any[] = [];
    if (plan) {
      const planUpper = plan.toUpperCase();
      if (planUpper === "STANDARD") {
        conditions.push(or(
          sql`${payments.reference} LIKE ${'PREM-STANDARD%'}`,
          sql`${payments.reference} LIKE ${'PREM-STD%'}`
        ));
      } else {
        conditions.push(sql`${payments.reference} LIKE ${`PREM-${planUpper}%`}`);
      }
    }
    const result = await db
      .select()
      .from(payments)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(payments.paidAt));
    return result;
  }

  async getPaymentsByDateRange(startDate: string, endDate: string, plan?: string): Promise<Payment[]> {
    const conditions: any[] = [
      sql`${payments.paidAt} >= ${startDate}`,
      sql`${payments.paidAt} <= ${endDate}`
    ];
    if (plan) {
      const planUpper = plan.toUpperCase();
      if (planUpper === "STANDARD") {
        conditions.push(or(
          sql`${payments.reference} LIKE ${'PREM-STANDARD%'}`,
          sql`${payments.reference} LIKE ${'PREM-STD%'}`
        ));
      } else {
        conditions.push(sql`${payments.reference} LIKE ${`PREM-${planUpper}%`}`);
      }
    }
    const result = await db
      .select()
      .from(payments)
      .where(and(...conditions))
      .orderBy(desc(payments.paidAt));
    return result;
  }

  async getPaymentTotals(startDate?: string, endDate?: string, plan?: string): Promise<{ total: number; count: number }> {
    const conditions: any[] = [eq(payments.status, "completed")];

    if (startDate && endDate) {
      conditions.push(sql`${payments.paidAt} >= ${startDate}`);
      conditions.push(sql`${payments.paidAt} <= ${endDate}`);
    }

    if (plan) {
      const planUpper = plan.toUpperCase();
      if (planUpper === "STANDARD") {
        conditions.push(or(
          sql`${payments.reference} LIKE ${'PREM-STANDARD%'}`,
          sql`${payments.reference} LIKE ${'PREM-STD%'}`
        ));
      } else {
        conditions.push(sql`${payments.reference} LIKE ${`PREM-${planUpper}%`}`);
      }
    }

    const query = db
      .select({
        total: sql<number>`COALESCE(SUM(${payments.amount}), 0)`,
        count: sql<number>`COUNT(*)`
      })
      .from(payments)
      .where(and(...conditions));

    const result = await query;
    return {
      total: Number(result[0]?.total || 0),
      count: Number(result[0]?.count || 0)
    };
  }

  async getAllDisclaimers(): Promise<Disclaimer[]> {
    const result = await db
      .select()
      .from(disclaimers)
      .orderBy(asc(disclaimers.language));
    return result;
  }

  async getDisclaimerByLanguage(language: string): Promise<Disclaimer | undefined> {
    const result = await db
      .select()
      .from(disclaimers)
      .where(and(eq(disclaimers.language, language), eq(disclaimers.isActive, true)))
      .limit(1);
    return result[0];
  }

  async createDisclaimer(disclaimer: InsertDisclaimer): Promise<Disclaimer> {
    const result = await db
      .insert(disclaimers)
      .values({ ...disclaimer, updatedAt: new Date().toISOString() })
      .returning();
    return result[0];
  }

  async updateDisclaimer(id: string, disclaimer: Partial<InsertDisclaimer>): Promise<Disclaimer | undefined> {
    const result = await db
      .update(disclaimers)
      .set({ ...disclaimer, updatedAt: new Date().toISOString() })
      .where(eq(disclaimers.id, id))
      .returning();
    return result[0];
  }

  async deleteDisclaimer(id: string): Promise<void> {
    await db.delete(disclaimers).where(eq(disclaimers.id, id));
  }

  async getAllSettings(): Promise<AppSetting[]> {
    const result = await db
      .select()
      .from(appSettings)
      .orderBy(asc(appSettings.key));
    return result;
  }

  async getSetting(key: string): Promise<AppSetting | undefined> {
    const result = await db
      .select()
      .from(appSettings)
      .where(eq(appSettings.key, key))
      .limit(1);
    return result[0];
  }

  async upsertSetting(key: string, value: string, description?: string): Promise<AppSetting> {
    const existing = await this.getSetting(key);
    if (existing) {
      const result = await db
        .update(appSettings)
        .set({ value, description, updatedAt: new Date().toISOString() })
        .where(eq(appSettings.key, key))
        .returning();
      return result[0];
    } else {
      const result = await db
        .insert(appSettings)
        .values({ key, value, description, updatedAt: new Date().toISOString() })
        .returning();
      return result[0];
    }
  }

  async getAllServicePincodes(): Promise<ServicePincode[]> {
    const result = await db
      .select()
      .from(servicePincodes)
      .orderBy(asc(servicePincodes.displayOrder));
    return result;
  }

  async getActiveServicePincodes(): Promise<ServicePincode[]> {
    const result = await db
      .select()
      .from(servicePincodes)
      .where(eq(servicePincodes.isActive, true))
      .orderBy(asc(servicePincodes.displayOrder));
    return result;
  }

  async createServicePincode(pincode: InsertServicePincode): Promise<ServicePincode> {
    const result = await db
      .insert(servicePincodes)
      .values(pincode)
      .returning();
    return result[0];
  }

  async updateServicePincode(id: string, pincode: Partial<InsertServicePincode>): Promise<ServicePincode | undefined> {
    const result = await db
      .update(servicePincodes)
      .set(pincode)
      .where(eq(servicePincodes.id, id))
      .returning();
    return result[0];
  }

  async deleteServicePincode(id: string): Promise<void> {
    await db.delete(servicePincodes).where(eq(servicePincodes.id, id));
  }

  async addInterest(bookingId: string, userId: string): Promise<Interest> {
    const result = await db
      .insert(interests)
      .values({ bookingId, userId })
      .onConflictDoNothing()
      .returning();
    if (result[0]) return result[0];
    const existing = await db
      .select()
      .from(interests)
      .where(and(eq(interests.bookingId, bookingId), eq(interests.userId, userId)))
      .limit(1);
    return existing[0];
  }

  async removeInterest(bookingId: string, userId: string): Promise<void> {
    await db
      .delete(interests)
      .where(and(eq(interests.bookingId, bookingId), eq(interests.userId, userId)));
  }

  async getInterestCount(bookingId: string): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(interests)
      .where(eq(interests.bookingId, bookingId));
    return result[0]?.count || 0;
  }

  async getInterestCounts(bookingIds: string[]): Promise<Record<string, number>> {
    if (bookingIds.length === 0) return {};
    const result = await db
      .select({
        bookingId: interests.bookingId,
        count: sql<number>`count(*)::int`,
      })
      .from(interests)
      .where(sql`${interests.bookingId} IN (${sql.join(bookingIds.map(id => sql`${id}`), sql`, `)})`)
      .groupBy(interests.bookingId);
    const counts: Record<string, number> = {};
    for (const row of result) {
      counts[row.bookingId] = row.count;
    }
    return counts;
  }

  async getUserInterests(userId: string): Promise<string[]> {
    const result = await db
      .select({ bookingId: interests.bookingId })
      .from(interests)
      .where(eq(interests.userId, userId));
    return result.map(r => r.bookingId);
  }

  async addViewedContact(userId: string, bookingId: string): Promise<void> {
    await db
      .insert(viewedContacts)
      .values({ userId, bookingId })
      .onConflictDoNothing();
  }

  async getViewedContacts(userId: string): Promise<string[]> {
    const result = await db
      .select({ bookingId: viewedContacts.bookingId })
      .from(viewedContacts)
      .where(eq(viewedContacts.userId, userId));
    return result.map(r => r.bookingId);
  }
}

export const storage = new DatabaseStorage();
