import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import { Camera, Navigation, IndianRupee, Plus, X, Loader2, CheckCircle2, Pencil, Car, Bike, Check } from "lucide-react";
import { getApiUrl } from "@/lib/api-config";
import { motion, AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";

interface ParkingTypeOption {
  id: string;
  name: string;
  isActive: boolean;
}

export default function CustomerBookings() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [photos, setPhotos] = useState<string[]>([]);
  const [parkingType, setParkingType] = useState("");
  const [selectedServiceId, setSelectedServiceId] = useState("");
  const [parkingTypes, setParkingTypes] = useState<ParkingTypeOption[]>([]);
  const [address, setAddress] = useState("");
  const [rent, setRent] = useState("");
  const [description, setDescription] = useState("");
  const [isDetecting, setIsDetecting] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [editBookingId, setEditBookingId] = useState<string | null>(null);
  const [detectedLat, setDetectedLat] = useState<number | null>(null);
  const [detectedLng, setDetectedLng] = useState<number | null>(null);
  const [sessionValid, setSessionValid] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const validateSession = async () => {
      const userId = localStorage.getItem("userId");
      if (!userId) {
        setLocation("/auth?role=customer");
        return;
      }
      try {
        const res = await fetch(getApiUrl(`/api/users/${userId}`));
        if (!res.ok) {
          localStorage.removeItem("userId");
          localStorage.removeItem("userRole");
          localStorage.removeItem("userMobile");
          setLocation("/auth?role=customer");
          return;
        }
        setSessionValid(true);
      } catch {
        localStorage.removeItem("userId");
        localStorage.removeItem("userRole");
        localStorage.removeItem("userMobile");
        setLocation("/auth?role=customer");
        return;
      }
    };
    validateSession();

    const fetchParkingTypes = async () => {
      try {
        const res = await fetch(getApiUrl("/api/services"));
        if (res.ok) {
          const data = await res.json();
          setParkingTypes((data.services || []).filter((s: any) => s.isActive));
        }
      } catch (error) {
        console.error("Failed to fetch parking types:", error);
      }
    };
    fetchParkingTypes();

    const params = new URLSearchParams(window.location.search);
    const editId = params.get("edit");
    if (editId) {
      setEditMode(true);
      setEditBookingId(editId);
      const fetchBooking = async () => {
        try {
          const res = await fetch(getApiUrl(`/api/bookings/${editId}`));
          if (res.ok) {
            const data = await res.json();
            const booking = data.booking;
            if (booking) {
              setParkingType(booking.serviceName || "");
              setSelectedServiceId(booking.serviceId || "");
              setAddress((booking.location || "").replace(/[0-9]/g, ''));
              const rentMatch = booking.comments?.match(/Rent: ₹(\d+)/);
              if (rentMatch) setRent(rentMatch[1]);
              const descMatch = booking.comments?.match(/\| (.+)/);
              if (descMatch) {
                const descText = descMatch[1].replace(/\[PHOTOS\].*\[\/PHOTOS\]/s, '').trim();
                setDescription(descText.replace(/[0-9]/g, '').slice(0, 60));
              }
              const photosMatch = booking.comments?.match(/\[PHOTOS\](.*?)\[\/PHOTOS\]/s);
              if (photosMatch) {
                try {
                  const parsedPhotos = JSON.parse(photosMatch[1]);
                  if (Array.isArray(parsedPhotos)) setPhotos(parsedPhotos);
                } catch {}
              }
            }
          }
        } catch (error) {
          console.error("Failed to fetch booking:", error);
        }
      };
      fetchBooking();
    }
  }, []);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const remaining = 4 - photos.length;
    const filesToProcess = Array.from(files).slice(0, remaining);

    filesToProcess.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos((prev) => [...prev, event.target!.result as string].slice(0, 4));
        }
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAutoDetect = () => {
    if (!navigator.geolocation) return;

    setIsDetecting(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setDetectedLat(latitude);
        setDetectedLng(longitude);
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&accept-language=en`
          );
          const data = await response.json();
          setAddress((data.display_name || "").replace(/[0-9]/g, ''));
        } catch {
          setAddress("Location detected");
        }
        setIsDetecting(false);
      },
      () => {
        setIsDetecting(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSubmit = async () => {
    setSubmitError("");
    if (!parkingType || !selectedServiceId) {
      setSubmitError("Please select a parking type.");
      return;
    }
    if (!address) {
      setSubmitError("Please enter an address or use Auto Detect.");
      return;
    }
    if (!rent) {
      setSubmitError("Please enter the monthly rent amount.");
      return;
    }
    if (!description.trim()) {
      setSubmitError("Please select a description for your parking space.");
      return;
    }
    setIsSubmitting(true);

    try {
      if (editMode && editBookingId) {
        const response = await fetch(getApiUrl(`/api/bookings/${editBookingId}`), {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            serviceName: parkingType,
            location: address,
            comments: `Rent: ₹${rent}/month${description ? ` | ${description}` : ""}${photos.length > 0 ? `[PHOTOS]${JSON.stringify(photos)}[/PHOTOS]` : ""}`,
            date: new Date().toISOString().split("T")[0],
            time: new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
          }),
        });

        if (response.ok) {
          queryClient.invalidateQueries({ queryKey: ["myBookings"] });
          setShowSuccess(true);
        } else {
          const errorData = await response.json().catch(() => ({ error: "Something went wrong" }));
          setSubmitError(errorData.error || "Failed to update space. Please try again.");
        }
      } else {
        const userId = localStorage.getItem("userId");
        if (!userId) {
          alert("Your session has expired. Please log in again.");
          setLocation("/auth?role=customer");
          setIsSubmitting(false);
          return;
        }
        const userCity = localStorage.getItem("selectedServiceAreaName") || localStorage.getItem("userDetectedCity") || null;
        const bookingData: Record<string, any> = {
          customerId: userId,
          serviceId: selectedServiceId,
          serviceName: parkingType,
          location: address,
          city: userCity,
          comments: `Rent: ₹${rent}/month${description ? ` | ${description}` : ""}${photos.length > 0 ? `[PHOTOS]${JSON.stringify(photos)}[/PHOTOS]` : ""}`,
          date: new Date().toISOString().split("T")[0],
          time: new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
          bookedAt: new Date().toISOString(),
          status: "pending",
        };
        if (detectedLat !== null && detectedLng !== null) {
          bookingData.latitude = detectedLat;
          bookingData.longitude = detectedLng;
        }
        const response = await fetch(getApiUrl("/api/bookings"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(bookingData),
        });

        if (response.ok) {
          queryClient.invalidateQueries({ queryKey: ["myBookings"] });
          setShowSuccess(true);
        } else {
          const errorData = await response.json().catch(() => ({}));
          const errorMsg = errorData.error || errorData.message || "";
          if (errorMsg.toLowerCase().includes("user not found") || errorMsg.toLowerCase().includes("log in") || response.status === 401) {
            localStorage.removeItem("userId");
            localStorage.removeItem("userRole");
            localStorage.removeItem("userMobile");
            alert("Your session has expired. Please log in again.");
            setLocation("/auth?role=customer");
            return;
          }
          setSubmitError(errorMsg || "Failed to post space. Please try again.");
        }
      }
    } catch (error) {
      console.error("Failed to save space:", error);
      setSubmitError("Network error. Please check your connection and try again.");
    }

    setIsSubmitting(false);
  };

  const isFormValid = parkingType && selectedServiceId && address && rent && description.trim();

  if (!sessionValid) {
    return (
      <MobileLayout showNav userType="customer">
        <div className="min-h-full bg-gray-50 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#4f0073]" />
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout showNav userType="customer">
      <div className="min-h-full bg-gray-50">
        <div className="sticky top-0 z-30 bg-gradient-to-r from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-6 pt-6 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              {editMode ? <Pencil size={20} className="text-white" /> : <Plus size={22} className="text-white" />}
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{editMode ? "Edit Space" : "Post a Space"}</h1>
              <p className="text-purple-200 text-sm">{editMode ? "Update your parking space details" : "Fill in details to list your parking space"}</p>
            </div>
          </div>

          {(() => {
            const filled = [
              !!parkingType,
              !!address.trim(),
              !!rent.trim(),
              !!description.trim(),
              photos.length > 0,
            ].filter(Boolean).length;
            const total = 5;
            const pct = Math.round((filled / total) * 100);
            const barColor =
              pct === 100
                ? "from-green-300 to-green-400"
                : pct >= 80
                ? "from-emerald-300 to-green-400"
                : pct >= 60
                ? "from-yellow-300 to-amber-400"
                : pct >= 40
                ? "from-orange-300 to-orange-400"
                : pct >= 20
                ? "from-pink-300 to-red-400"
                : "from-red-300 to-red-500";
            const label =
              pct === 100
                ? "Ready to post!"
                : pct >= 80
                ? "Almost done"
                : pct >= 60
                ? "Good progress"
                : pct >= 40
                ? "Keep going"
                : pct >= 20
                ? "Just started"
                : "Get started";
            return (
              <div className="mt-4" data-testid="form-strength-container">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-semibold text-white/85">Form completion</span>
                  <span
                    className="text-[11px] font-bold text-white"
                    data-testid="text-form-strength-percent"
                  >
                    {pct}% · {label}
                  </span>
                </div>
                <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden backdrop-blur-sm">
                  <div
                    className={`h-full bg-gradient-to-r ${barColor} rounded-full transition-all duration-500 ease-out shadow-sm`}
                    style={{ width: `${pct}%` }}
                    data-testid="bar-form-strength"
                  />
                </div>
              </div>
            );
          })()}
        </div>

        <div className="px-5 py-6 space-y-6">
          <div>
            <label className="text-sm font-semibold text-neutral-800 mb-2 block">
              Photos
            </label>
            <p className="text-xs text-neutral-500 mb-3">Upload up to 4 photos of your parking space (optional)</p>
            <div className="flex gap-3 flex-wrap">
              {photos.map((photo, index) => (
                <div key={index} className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-purple-200 shadow-sm">
                  <img src={photo} alt={`Space ${index + 1}`} className="w-full h-full object-cover" />
                  <button
                    onClick={() => removePhoto(index)}
                    className="absolute top-1 right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center shadow-md"
                    data-testid={`button-remove-photo-${index}`}
                  >
                    <X size={12} className="text-white" />
                  </button>
                </div>
              ))}
              {photos.length < 4 && (
                <label
                  className="w-20 h-20 rounded-2xl border-2 border-dashed border-purple-300 bg-purple-50 flex flex-col items-center justify-center gap-1 hover:border-purple-500 hover:bg-purple-100 transition-all cursor-pointer"
                  data-testid="button-add-photos"
                >
                  <Camera size={22} className="text-[#4f0073]" />
                  <span className="text-[10px] font-semibold text-[#4f0073]">Add Photos</span>
                  <span className="text-[10px] text-neutral-400">{photos.length}/4</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={handlePhotoUpload}
                  />
                </label>
              )}
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold text-neutral-800 mb-2 block">
              Parking Type <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-3 gap-3">
              {parkingTypes.map((type) => {
                const isSelected = parkingType === type.name;
                const nameLower = type.name.toLowerCase();
                const isCar = nameLower.includes("car") && !nameLower.includes("bike");
                const isBike = nameLower.includes("bike") && !nameLower.includes("car");
                return (
                  <button
                    key={type.id}
                    onClick={() => {
                      setParkingType(type.name);
                      setSelectedServiceId(type.id);
                    }}
                    className={`relative flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${
                      isSelected
                        ? "border-[#4f0073] bg-purple-50 shadow-md"
                        : "border-neutral-200 bg-white hover:border-purple-200"
                    }`}
                    data-testid={`option-${type.name.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {isSelected && (
                      <div className="absolute top-2 right-2 w-5 h-5 bg-[#4f0073] rounded-full flex items-center justify-center">
                        <Check size={12} className="text-white" />
                      </div>
                    )}
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      isSelected ? "bg-[#4f0073]" : "bg-neutral-100"
                    }`}>
                      {isCar ? (
                        <Car size={24} className={isSelected ? "text-white" : "text-neutral-500"} />
                      ) : isBike ? (
                        <Bike size={24} className={isSelected ? "text-white" : "text-neutral-500"} />
                      ) : (
                        <div className="flex items-center gap-0.5">
                          <Car size={18} className={isSelected ? "text-white" : "text-neutral-500"} />
                          <Bike size={14} className={isSelected ? "text-white" : "text-neutral-500"} />
                        </div>
                      )}
                    </div>
                    <span className={`text-xs font-semibold text-center leading-tight ${
                      isSelected ? "text-[#4f0073]" : "text-neutral-600"
                    }`}>
                      {type.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-neutral-800">
                Address / Location <span className="text-red-500">*</span>
              </label>
              <button
                onClick={handleAutoDetect}
                disabled={isDetecting}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-[#4f0073] to-[#6b21a8] text-white text-xs font-bold rounded-full hover:shadow-lg hover:shadow-purple-300/40 transition-all active:scale-95 disabled:opacity-50"
                data-testid="button-auto-detect"
              >
                {isDetecting ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <Navigation size={14} className="fill-white" />
                )}
                Auto Detect
              </button>
            </div>
            <textarea
              value={address}
              onChange={(e) => {
                const val = e.target.value.replace(/[0-9]/g, '');
                setAddress(val);
              }}
              placeholder="Enter full address or use GPS (no numbers)"
              rows={3}
              className="w-full px-4 py-3.5 bg-white border border-neutral-200 rounded-2xl text-sm resize-none shadow-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100 transition-all placeholder:text-neutral-400"
              data-testid="input-address"
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-neutral-800 mb-2 block">
              Monthly Rent (₹) <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-[#4f0073] to-[#6b21a8] rounded-l-2xl flex items-center justify-center">
                <IndianRupee size={18} className="text-white" />
              </div>
              <input
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                value={rent}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                  setRent(val);
                }}
                maxLength={4}
                placeholder="e.g. 2500"
                style={{ fontSize: "30px" }}
                className="w-full pl-16 pr-4 py-2.5 bg-white border border-neutral-200 rounded-2xl shadow-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-100 transition-all placeholder:text-neutral-400 font-bold"
                data-testid="input-rent"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold text-neutral-800 mb-2 block">
              Description <span className="text-red-500">*</span>
            </label>
            <div className="flex flex-col gap-2">
              {[
                "Safe covered parking inside compound or building",
                "Open area parking suitable for car or bike",
                "Parking space inside a house or apartment area",
              ].map((option) => {
                const isSelected = description === option;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setDescription(isSelected ? "" : option)}
                    className={`w-full text-left px-4 py-3 rounded-2xl border-2 text-sm transition-all flex items-center gap-3 ${
                      isSelected
                        ? "border-[#4f0073] bg-purple-50 text-[#4f0073] font-medium"
                        : "border-neutral-200 bg-white text-neutral-600 hover:border-purple-200"
                    }`}
                    data-testid={`option-desc-${option.split(" ").slice(0, 3).join("-").toLowerCase()}`}
                  >
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                      isSelected ? "border-[#4f0073] bg-[#4f0073]" : "border-neutral-300"
                    }`}>
                      {isSelected && <Check size={12} className="text-white" />}
                    </div>
                    {option}
                  </button>
                );
              })}
            </div>
          </div>

          {submitError && (
            <div className="bg-red-50 border border-red-200 rounded-2xl px-4 py-3 text-red-700 text-sm" data-testid="text-submit-error">
              {submitError}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={!isFormValid || isSubmitting}
            className={`w-full py-4 rounded-2xl font-bold text-white text-base shadow-xl transition-all duration-300 ${
              isFormValid
                ? "bg-gradient-to-r from-[#4f0073] via-[#6b21a8] to-[#9333ea] hover:shadow-2xl active:scale-[0.98]"
                : "bg-neutral-300 cursor-not-allowed"
            }`}
            data-testid="button-post-space"
          >
            {isSubmitting ? (
              <div className="flex items-center justify-center gap-2">
                <Loader2 size={20} className="animate-spin" />
                {editMode ? "Updating..." : "Posting..."}
              </div>
            ) : (
              editMode ? "Update My Space" : "Post My Space"
            )}
          </button>
        </div>

        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-6"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="bg-white rounded-3xl p-8 text-center shadow-2xl max-w-sm w-full"
              >
                <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 size={44} className="text-green-500" />
                </div>
                <h3 className="text-xl font-bold text-neutral-900 mb-2">{editMode ? "Space Updated!" : "Space Posted!"}</h3>
                <p className="text-neutral-500 text-sm mb-6">{editMode ? "Your parking space has been updated successfully." : "Your parking space has been listed successfully."}</p>
                <button
                  onClick={() => {
                    setShowSuccess(false);
                    setLocation("/customer/home");
                  }}
                  className="w-full py-3.5 bg-gradient-to-r from-[#4f0073] via-[#6b21a8] to-[#9333ea] text-white font-bold rounded-2xl shadow-lg hover:shadow-xl active:scale-[0.98] transition-all"
                  data-testid="button-go-home"
                >
                  Go to Home
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </MobileLayout>
  );
}
