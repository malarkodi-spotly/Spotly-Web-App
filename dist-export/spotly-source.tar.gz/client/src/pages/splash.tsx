import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import splashLogo from "@assets/splash_logo_transparent.png";

export default function SplashPage() {
  const [, setLocation] = useLocation();
  const [show, setShow] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setShow(true), 80);
    const navTimer = setTimeout(() => {
      const userId = localStorage.getItem("userId");
      const userRole = localStorage.getItem("userRole");
      if (userId && userRole) {
        if (userRole === "customer") setLocation("/customer/home");
        else if (userRole === "worker") setLocation("/worker/home");
        else setLocation("/role-selection");
      } else {
        setLocation("/role-selection");
      }
    }, 2600);
    return () => {
      clearTimeout(t1);
      clearTimeout(navTimer);
    };
  }, [setLocation]);

  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden flex flex-col items-center justify-center bg-[#4f0073]">
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 35%, rgba(147,51,234,0.55) 0%, rgba(79,0,115,0.95) 50%, #2e0044 100%)",
        }}
      />

      <div className="absolute bottom-0 left-0 right-0 h-[42%] overflow-hidden pointer-events-none">
        <div
          className="absolute left-1/2 bottom-0"
          style={{
            transform: "translateX(-50%)",
            width: "180%",
            height: "100%",
            perspective: "600px",
            perspectiveOrigin: "50% 0%",
          }}
        >
          <div
            className="absolute inset-x-0 bottom-0 h-full"
            style={{
              transform: "rotateX(72deg)",
              transformOrigin: "50% 100%",
              background:
                "linear-gradient(to top, rgba(46,0,68,0.95) 0%, rgba(79,0,115,0.4) 60%, transparent 100%)",
            }}
          >
            <svg
              className="absolute inset-0 w-full h-full"
              xmlns="http://www.w3.org/2000/svg"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="lineFade" x1="0" y1="100%" x2="0" y2="0">
                  <stop offset="0%" stopColor="rgba(255,255,255,0.55)" />
                  <stop offset="100%" stopColor="rgba(255,255,255,0)" />
                </linearGradient>
                <pattern
                  id="lanes"
                  x="0"
                  y="0"
                  width="100"
                  height="60"
                  patternUnits="userSpaceOnUse"
                >
                  <line x1="50" y1="0" x2="50" y2="30" stroke="url(#lineFade)" strokeWidth="3" />
                </pattern>
              </defs>
              <line x1="0%" y1="100%" x2="0%" y2="0%" stroke="url(#lineFade)" strokeWidth="2" />
              <line x1="100%" y1="100%" x2="100%" y2="0%" stroke="url(#lineFade)" strokeWidth="2" />
              <line x1="25%" y1="100%" x2="40%" y2="0%" stroke="url(#lineFade)" strokeWidth="1.5" />
              <line x1="50%" y1="100%" x2="50%" y2="0%" stroke="url(#lineFade)" strokeWidth="1.5" />
              <line x1="75%" y1="100%" x2="60%" y2="0%" stroke="url(#lineFade)" strokeWidth="1.5" />
              <motion.g
                animate={{ y: [0, 60] }}
                transition={{ duration: 1.4, repeat: Infinity, ease: "linear" }}
              >
                <rect width="100%" height="100%" fill="url(#lanes)" />
              </motion.g>
            </svg>
          </div>
        </div>
      </div>

      <div
        className="absolute inset-x-0 top-0 h-[12%] pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at 50% 0%, rgba(255,255,255,0.18) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 flex flex-col items-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.92 }}
          animate={{ opacity: show ? 1 : 0, y: show ? 0 : 20, scale: show ? 1 : 0.92 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative"
        >
          <div className="absolute inset-0 -m-10 rounded-full bg-white/15 blur-3xl" />
          <img
            src={splashLogo}
            alt="Spotly"
            className="relative w-[160px] h-auto object-contain drop-shadow-[0_10px_40px_rgba(0,0,0,0.45)]"
          />
        </motion.div>

        <motion.div
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: show ? 60 : 0, opacity: show ? 1 : 0 }}
          transition={{ duration: 0.6, delay: 0.5, ease: "easeOut" }}
          className="h-[3px] rounded-full bg-gradient-to-r from-transparent via-white/80 to-transparent mt-5"
        />

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: show ? 1 : 0, y: show ? 0 : 10 }}
          transition={{ duration: 0.7, delay: 0.7, ease: "easeOut" }}
          className="mt-4 text-white/85 text-[14px] font-semibold tracking-[0.15em] uppercase text-center"
        >
          Car &amp; Bike Parking
        </motion.p>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: show ? 1 : 0, y: show ? 0 : 10 }}
          transition={{ duration: 0.7, delay: 0.85, ease: "easeOut" }}
          className="mt-1 text-white/55 text-[12px] font-medium tracking-wide text-center"
        >
          Made simple, near you
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: show ? 1 : 0 }}
          transition={{ duration: 0.5, delay: 1.1 }}
          className="mt-7 w-[120px] h-[3px] rounded-full bg-white/10 overflow-hidden"
        >
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-white/60 to-white"
            initial={{ x: "-100%" }}
            animate={{ x: "100%" }}
            transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            style={{ width: "60%" }}
          />
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: show ? 1 : 0 }}
        transition={{ duration: 0.6, delay: 1.2 }}
        className="absolute bottom-7 left-0 right-0 flex flex-col items-center"
      >
        <p className="text-white/45 text-[10px] font-semibold tracking-[0.3em] uppercase">
          Spotly India
        </p>
      </motion.div>
    </div>
  );
}
