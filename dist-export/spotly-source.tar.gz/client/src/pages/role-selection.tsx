import { useLocation } from "wouter";
import { ParkingCircle, Car, Bike, ShieldCheck, Search, Sparkles, BadgeCheck, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import logo from "@assets/file_00000000a1c8720881e8312ea1ae4e07_1775941652727.png";
import { vibrate } from "@/lib/vibrate";

export default function RoleSelectionPage() {
  const [, setLocation] = useLocation();
  const [comingSoonMode, setComingSoonMode] = useState(false);
  const [selectedRole, setSelectedRole] = useState<"customer" | "worker" | null>(null);

  useEffect(() => {
    const checkComingSoonMode = async () => {
      try {
        const res = await fetch("/api/settings/coming_soon_mode");
        if (res.ok) {
          const data = await res.json();
          setComingSoonMode(data.setting?.value === "true");
        }
      } catch (error) {
        console.error("Failed to check Coming Soon mode:", error);
      }
    };
    checkComingSoonMode();
  }, []);

  const handleGetStarted = () => {
    if (!selectedRole) return;
    vibrate();
    localStorage.setItem("userRole", selectedRole);

    if (comingSoonMode) {
      localStorage.setItem("userId", `demo_${Date.now()}`);
      localStorage.setItem("disclaimerAccepted", "true");
      if (selectedRole === "customer") {
        setLocation("/customer/home");
      } else {
        setLocation("/worker/home");
      }
    } else {
      setLocation(`/auth?role=${selectedRole}`);
    }
  };

  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden bg-[#4f0073]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.18),transparent_30%),linear-gradient(180deg,#7a18a8_0%,#5e0689_35%,#4f0073_65%,#2e0044_100%)]" />
      <div className="absolute top-[-15%] left-[-20%] w-[60%] h-[55%] rounded-full bg-[#4f0073]/60 blur-3xl" />
      <div className="absolute top-[10%] right-[-15%] w-[50%] h-[50%] rounded-full bg-[#6a0099]/50 blur-3xl" />
      <div className="absolute bottom-[-15%] left-[10%] w-[55%] h-[55%] rounded-full bg-[#3a0058]/60 blur-3xl" />

      <div className="absolute top-0 left-0 right-0 h-[42%] overflow-hidden flex items-center justify-center">
        <motion.div className="relative" initial={false} animate={false}>
          <div className="relative flex flex-col items-center">
            <div className="absolute -inset-8 rounded-full bg-white/55 blur-2xl" />
            <img src={logo} alt="Spotly" className="relative w-30 h-30 object-contain drop-shadow-2xl" data-testid="img-role-selection-logo" />
            <motion.div className="absolute -top-2 -left-4 w-11 h-11 bg-white rounded-2xl flex items-center justify-center shadow-lg shadow-white/40 rotate-[-12deg]" animate={{ y: [0, -6, 0], rotate: [-12, -8, -12] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}><ParkingCircle size={20} className="text-[#4f0073]" /></motion.div>
            <motion.div className="absolute -top-1 -right-6 w-10 h-10 bg-[#fff7b8] rounded-2xl flex items-center justify-center shadow-lg shadow-yellow-300/40 rotate-[10deg]" animate={{ y: [0, -5, 0], rotate: [10, 14, 10] }} transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}><Car size={18} className="text-[#4f0073]" /></motion.div>
            <motion.div className="absolute bottom-2 -right-3 w-9 h-9 bg-[#b9fbff] rounded-xl flex items-center justify-center shadow-lg shadow-cyan-300/30 rotate-[8deg]" animate={{ y: [0, -4, 0] }} transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}><Bike size={16} className="text-[#4f0073]" /></motion.div>
          </div>
        </motion.div>
      </div>

      <div className="relative z-10 min-h-[100dvh] flex flex-col">
        <div className="flex-1" />
        <motion.div className="px-4 pb-6 -mt-6" initial={false} animate={false}>
          <div className="rounded-[2rem] shadow-2xl shadow-black/25 px-5 pt-5 pb-5 border border-white/70 bg-white/40 backdrop-blur-2xl">
            <div className="flex items-center justify-center gap-2 mb-2 text-white">
              <Sparkles size={14} />
              <span className="text-xs font-semibold uppercase tracking-[0.3em]">Pick your path</span>
            </div>
            <h1 className="text-[1.75rem] font-extrabold text-white text-center mb-2 tracking-tight">Choose your role</h1>
            <p className="text-center text-white/92 text-sm mb-6 leading-relaxed">Bright, simple, and made for parking — choose how you want to use Spotly.</p>
            <div className="grid grid-cols-2 gap-3 mb-6 px-1">
              <motion.button onClick={() => { vibrate(); setSelectedRole("customer"); }} className={`relative overflow-hidden rounded-[1.75rem] py-4 px-3 text-left transition-all duration-300 border ${selectedRole === "customer" ? "bg-white border-[#e5d4ff] shadow-[0_18px_45px_rgba(255,255,255,0.45)]" : "bg-white/45 border-white/60"}`} data-testid="button-customer-role" whileTap={{ scale: 0.97 }}>
                <div className={`absolute inset-0 ${selectedRole === "customer" ? "bg-gradient-to-br from-[#fff7c2] via-white to-[#ead6ff]" : "bg-gradient-to-br from-white/12 to-white/0"}`} />
                <div className="relative flex items-center justify-between mb-5">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-colors duration-300 ${selectedRole === "customer" ? "bg-[#4f0073]" : "bg-white/20"}`}><ParkingCircle size={24} className={`transition-colors duration-300 ${selectedRole === "customer" ? "text-white" : "text-white"}`} /></div>
                  {selectedRole === "customer" ? <BadgeCheck size={18} className="text-[#4f0073]" /> : <ArrowRight size={18} className="text-white/70" />}
                </div>
                <div className="relative">
                  <h3 className={`font-bold text-[15px] mb-1 transition-colors duration-300 ${selectedRole === "customer" ? "text-[#2f0044]" : "text-white/90"}`}>Space Provider</h3>
                  <p className={`text-[11px] leading-relaxed ${selectedRole === "customer" ? "text-[#5d4c72]" : "text-white/75"}`}>List spaces, get bookings, earn monthly.</p>
                </div>
              </motion.button>

              <motion.button onClick={() => { vibrate(); setSelectedRole("worker"); }} className={`relative overflow-hidden rounded-[1.75rem] py-4 px-3 text-left transition-all duration-300 border ${selectedRole === "worker" ? "bg-white border-[#e5d4ff] shadow-[0_18px_45px_rgba(255,255,255,0.45)]" : "bg-white/45 border-white/60"}`} data-testid="button-worker-role" whileTap={{ scale: 0.97 }}>
                <div className={`absolute inset-0 ${selectedRole === "worker" ? "bg-gradient-to-br from-[#e6f6ff] via-white to-[#ffe0fb]" : "bg-gradient-to-br from-white/12 to-white/0"}`} />
                <div className="relative flex items-center justify-between mb-5">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-colors duration-300 ${selectedRole === "worker" ? "bg-[#4f0073]" : "bg-white/20"}`}><Search size={20} className={`transition-colors duration-300 ${selectedRole === "worker" ? "text-white" : "text-white"}`} /></div>
                  {selectedRole === "worker" ? <BadgeCheck size={18} className="text-[#4f0073]" /> : <ArrowRight size={18} className="text-white/70" />}
                </div>
                <div className="relative">
                  <h3 className={`font-bold text-[15px] mb-1 transition-colors duration-300 ${selectedRole === "worker" ? "text-[#2f0044]" : "text-white/90"}`}>Space Seeker</h3>
                  <p className={`text-[11px] leading-relaxed ${selectedRole === "worker" ? "text-[#5d4c72]" : "text-white/75"}`}>Find nearby parking in seconds.</p>
                </div>
              </motion.button>
            </div>
            <motion.button onClick={handleGetStarted} disabled={!selectedRole} className={`w-full h-[52px] rounded-2xl font-extrabold text-base transition-all duration-300 ${selectedRole ? "bg-gradient-to-r from-[#ffffff] via-[#fff0b8] to-[#f8d3ff] text-[#4f0073] shadow-xl shadow-black/15 active:scale-[0.98]" : "bg-white/20 text-white/50 cursor-not-allowed"}`} data-testid="button-get-started" whileTap={selectedRole ? { scale: 0.98 } : {}}>Get started</motion.button>
            <div className="flex items-center justify-center gap-2 mt-5"><ShieldCheck size={13} className="text-white" /><p className="text-white text-xs">Secure and trusted parking platform</p></div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
