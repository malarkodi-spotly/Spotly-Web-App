import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Loader2, ArrowLeft, ArrowRight, X, AlertCircle, Car, Search, Shield, Clock, MapPin } from "lucide-react";
import { getApiUrl } from "@/lib/api-config";
import { vibrate } from "@/lib/vibrate";
import { enterGuestMode } from "@/lib/guest";
import spotlyLogoWhite from "@assets/spotly_logo_transparent.png";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [isLoading, setIsLoading] = useState(false);
  const [mobile, setMobile] = useState("");
  const [otpDigits, setOtpDigits] = useState(["", "", "", ""]);
  const [userRole, setUserRole] = useState<"customer" | "worker">("customer");
  const [errorMessage, setErrorMessage] = useState("");
  const [resendTimer, setResendTimer] = useState(59);
  const [canResend, setCanResend] = useState(false);
  const [otpAutofilled, setOtpAutofilled] = useState(false);
  const otpRefs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];
  const phoneInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const role = params.get("role") as "customer" | "worker";
    if (role === "customer" || role === "worker") {
      setUserRole(role);
      localStorage.setItem("userRole", role);
    }
    const rememberedMobile = localStorage.getItem("rememberedMobile");
    const rememberedRole = localStorage.getItem("rememberedRole");
    if (rememberedMobile) {
      setMobile(rememberedMobile);
      if (!role && (rememberedRole === "customer" || rememberedRole === "worker")) {
        setUserRole(rememberedRole);
      }
    }
  }, []);

  useEffect(() => {
    if (step === "phone") {
      setTimeout(() => phoneInputRef.current?.focus(), 400);
    } else if (step === "otp") {
      setTimeout(() => otpRefs[0].current?.focus(), 400);
    }
  }, [step]);

  useEffect(() => {
    if (step !== "otp") return;
    setResendTimer(59);
    setCanResend(false);
    const interval = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          setCanResend(true);
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [step]);

  useEffect(() => {
    if (step !== "otp") return;
    let cancelled = false;
    const isWebOTPSupported = typeof window !== "undefined" && "OTPCredential" in window && !!navigator.credentials && typeof navigator.credentials.get === "function";
    if (!isWebOTPSupported) return;
    const abortController = new AbortController();
    (async () => {
      try {
        const otpCredential = await (navigator.credentials as any).get({ otp: { transport: ["sms"] }, signal: abortController.signal });
        if (cancelled || !otpCredential?.code) return;
        const digits = otpCredential.code.replace(/\D/g, "").slice(0, 4).split("");
        while (digits.length < 4) digits.push("");
        setOtpDigits(digits);
        setOtpAutofilled(true);
      } catch {}
    })();
    return () => {
      cancelled = true;
      abortController.abort();
    };
  }, [step]);

  useEffect(() => {
    if (step !== "otp" || !otpAutofilled) return;
    if (otpDigits.every((d) => d !== "")) {
      const timer = setTimeout(() => {
        const form = document.querySelector("form[data-otp-form]");
        if (form) (form as HTMLFormElement).requestSubmit();
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [step, otpAutofilled, otpDigits]);

  const handleOtpChange = (index: number, value: string) => {
    const digit = value.replace(/\D/g, "").slice(-1);
    const newDigits = [...otpDigits];
    newDigits[index] = digit;
    setOtpDigits(newDigits);
    setOtpAutofilled(false);
    if (digit && index < 3) otpRefs[index + 1].current?.focus();
    if (digit && index === 3) otpRefs[3].current?.blur();
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) otpRefs[index - 1].current?.focus();
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const text = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 4);
    if (text.length > 0) {
      const newDigits = ["", "", "", ""];
      for (let i = 0; i < text.length; i++) newDigits[i] = text[i];
      setOtpDigits(newDigits);
      setOtpAutofilled(false);
      if (text.length === 4) otpRefs[3].current?.blur();
      else if (text.length < 4) otpRefs[text.length].current?.focus();
    }
  };

  const handleResendOtp = async () => {
    vibrate();
    setIsLoading(true);
    setErrorMessage("");
    setOtpAutofilled(false);
    try {
      const response = await fetch(getApiUrl('/api/auth/login'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, role: userRole })
      });
      setIsLoading(false);
      if (response.ok) {
        setResendTimer(59);
        setCanResend(false);
      } else {
        const data = await response.json();
        setErrorMessage(data.error || "Failed to resend OTP.");
      }
    } catch { setIsLoading(false); setErrorMessage("Network error."); }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    vibrate();
    setIsLoading(true);
    setErrorMessage("");
    setOtpAutofilled(false);
    try {
      const response = await fetch(getApiUrl('/api/auth/login'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, role: userRole })
      });
      const data = await response.json();
      setIsLoading(false);
      if (response.ok) {
        if (data.userId) localStorage.setItem("userId", data.userId);
        if (data.isNewUser) localStorage.setItem("isNewUser", "true");
        else localStorage.removeItem("isNewUser");
        setStep("otp");
      } else {
        setErrorMessage(data.error || "Failed to send OTP.");
      }
    } catch { setIsLoading(false); setErrorMessage("Network error."); }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    vibrate();
    setIsLoading(true);
    const otp = otpDigits.join("");
    try {
      const response = await fetch(getApiUrl('/api/auth/verify-otp'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, otp, role: userRole })
      });
      const data = await response.json();
      setIsLoading(false);
      if (!response.ok) { setErrorMessage(data.error || "Verification failed."); return; }
      localStorage.removeItem("isGuest");
      localStorage.setItem("userRole", userRole);
      localStorage.setItem("userMobile", mobile);
      if (data.user?.id) localStorage.setItem("userId", data.user.id);
      if (data.user?.name) localStorage.setItem("userName", data.user.name);
      if (data.sessionToken) localStorage.setItem("sessionToken", data.sessionToken);
      if (data.isNewUser) setLocation(`/register?role=${userRole}`);
      else setLocation(userRole === "worker" ? "/worker/home" : "/customer/home");
    } catch { setIsLoading(false); setErrorMessage("Network error."); }
  };

  const isProvider = userRole === "customer";
  const RoleIcon = isProvider ? Car : Search;
  const roleLabel = isProvider ? "Space Provider" : "Space Seeker";
  const heroTagline = isProvider ? "List your space,\nearn monthly" : "Find parking\nnear you";
  const features = isProvider
    ? [
        { icon: Shield, text: "Verified seekers only" },
        { icon: Clock, text: "Monthly rentals" },
        { icon: MapPin, text: "Nearby matches" },
      ]
    : [
        { icon: MapPin, text: "Spaces within 3 km" },
        { icon: Clock, text: "Monthly parking" },
        { icon: Shield, text: "Verified providers" },
      ];
  const otpFull = otpDigits.every(d => d !== "");

  return (
    <div className="w-full max-w-[430px] mx-auto min-h-[100dvh] relative overflow-hidden">
      <div className="fixed inset-0 w-full h-full bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea]">
        <div className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute top-1/3 -right-20 w-64 h-64 rounded-full bg-fuchsia-400/20 blur-3xl" />
        <div className="absolute -bottom-24 left-1/4 w-72 h-72 rounded-full bg-purple-300/15 blur-3xl" />
        {isProvider ? (
          <>
            <div className="absolute top-[14%] right-[8%] w-20 h-20 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center rotate-12 shadow-2xl backdrop-blur-sm">
              <span className="text-white/90 text-4xl font-black drop-shadow">P</span>
            </div>
            <div className="absolute top-[42%] left-[6%] w-14 h-14 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center -rotate-6 backdrop-blur-sm">
              <Car size={26} className="text-white/80" />
            </div>
            <div className="absolute bottom-[26%] right-[10%] w-12 h-12 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center rotate-6 backdrop-blur-sm">
              <span className="text-white/80 text-2xl">₹</span>
            </div>
            <div className="absolute top-[68%] left-[12%] w-10 h-10 rounded-lg bg-white/10 border border-white/20 flex items-center justify-center rotate-12 backdrop-blur-sm">
              <Shield size={18} className="text-white/70" />
            </div>
            <svg className="absolute inset-0 w-full h-full opacity-[0.06]" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="park-grid" width="60" height="60" patternUnits="userSpaceOnUse">
                  <path d="M 30 5 L 30 55 M 5 30 L 55 30" fill="none" stroke="white" strokeWidth="1.5" strokeDasharray="4 4" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#park-grid)" />
            </svg>
          </>
        ) : (
          <>
            <div className="absolute top-[16%] right-[10%] w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center backdrop-blur-sm shadow-2xl">
              <MapPin size={28} className="text-white/85" />
            </div>
            <div className="absolute top-[40%] left-[8%] w-14 h-14 rounded-full bg-white/10 border border-white/20 flex items-center justify-center backdrop-blur-sm">
              <Search size={24} className="text-white/80" />
            </div>
            <div className="absolute bottom-[28%] right-[12%] w-12 h-12 rounded-full bg-white/10 border border-white/20 flex items-center justify-center backdrop-blur-sm">
              <Car size={22} className="text-white/75" />
            </div>
            <div className="absolute top-[70%] left-[14%] w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center backdrop-blur-sm">
              <Clock size={18} className="text-white/70" />
            </div>
            <svg className="absolute inset-0 w-full h-full opacity-[0.07]" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="dots" width="32" height="32" patternUnits="userSpaceOnUse">
                  <circle cx="16" cy="16" r="1.5" fill="white" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#dots)" />
            </svg>
          </>
        )}
      </div>

      <div className="relative z-10 min-h-[100dvh] flex flex-col">
        <div className="p-5 pb-2 text-left">
          <div className="mb-3 flex items-center justify-between">
            <img src={spotlyLogoWhite} alt="Spotly" className="h-10 object-contain drop-shadow-lg" />
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-md border border-white/25" data-testid="badge-role">
              <RoleIcon size={14} className="text-white" />
              <span className="text-[11px] font-bold text-white tracking-wide">{roleLabel}</span>
            </div>
          </div>
          <h1 className="text-white text-[1.75rem] font-extrabold leading-[1.15] mt-2 whitespace-pre-line drop-shadow-lg">{heroTagline}</h1>
          <div className="flex flex-wrap gap-2 mt-3">
            {features.map((f, i) => (
              <div key={i} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm">
                <f.icon size={11} className="text-white/90" />
                <span className="text-[10.5px] font-semibold text-white/90">{f.text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex-1 flex items-center justify-center px-4 py-8">
          <div className="w-full max-w-[360px] rounded-3xl shadow-2xl shadow-black/20 px-5 pt-5 pb-[36px] border border-white/30" style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)" }}>
            {step === "phone" ? (
              <form onSubmit={handleSendOtp}>
                <h2 className="text-lg font-extrabold text-white mb-4" data-testid="text-auth-title">Login or sign up</h2>
                <div className="mb-4">
                  <p className="text-sm font-semibold text-white/80 mb-2">Enter phone number <span className="text-red-300">*</span></p>
                  <div className="flex items-center border-2 border-white/30 rounded-xl overflow-hidden focus-within:border-white/60 transition-colors h-[50px]" style={{ background: "rgba(255,255,255,0.12)" }}>
                    <div className="flex items-center px-3 border-r border-white/20 h-full flex-shrink-0">
                      <span className="text-sm font-semibold text-white/90">+91</span>
                    </div>
                    <input ref={phoneInputRef} id="mobile" type="tel" inputMode="numeric" pattern="[0-9]*" placeholder="Enter 10 digit number" className="flex-1 min-w-0 pl-3 pr-2 text-base font-medium text-white outline-none bg-transparent placeholder:text-white/40" value={mobile} onChange={(e) => { const val = e.target.value.replace(/\D/g, '').slice(0, 10); setMobile(val); if (val.length === 10) { (e.target as HTMLInputElement).blur(); } }} onFocus={(e) => setTimeout(() => e.target.scrollIntoView({ behavior: "smooth", block: "center" }), 300)} maxLength={10} data-testid="input-mobile" required />
                    {mobile && (<button type="button" onClick={() => setMobile("")} className="flex-shrink-0 px-3 h-full flex items-center text-white/50 hover:text-white/80"><X size={18} /></button>)}
                  </div>
                </div>
                <button type="submit" disabled={isLoading || mobile.length !== 10} className="w-full h-[50px] flex items-center justify-center text-base font-extrabold rounded-xl text-[#4f0073] shadow-xl shadow-black/15 transition-all active:scale-[0.98] disabled:opacity-40 disabled:shadow-none mb-3 bg-white" data-testid="button-submit">{isLoading ? <Loader2 className="animate-spin" size={22} /> : "Get OTP"}</button>
                <div className="flex items-center gap-3 my-3">
                  <div className="flex-1 h-px bg-white/25"></div>
                  <span className="text-[11px] font-semibold text-white/70 uppercase tracking-wider">or</span>
                  <div className="flex-1 h-px bg-white/25"></div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    vibrate();
                    enterGuestMode(userRole);
                    setLocation(userRole === "customer" ? "/customer/location-setup" : "/worker/location-setup");
                  }}
                  className="w-full h-[50px] flex items-center justify-center gap-2 text-[15px] font-extrabold rounded-xl text-[#4f0073] bg-yellow-400 hover:bg-yellow-300 active:scale-[0.98] transition-all mb-3 shadow-lg shadow-yellow-500/30 ring-2 ring-yellow-200/50"
                  data-testid="button-skip-login"
                >
                  Skip for now
                  <ArrowRight size={18} strokeWidth={3} />
                </button>
                <p className="text-[11px] text-white/50 text-center leading-relaxed px-2">By continuing, you agree to Spotly's Terms of service & Privacy policy</p>
              </form>
            ) : (
              <form data-otp-form onSubmit={handleVerifyOtp}>
                <div className="flex items-center gap-3 mb-3">
                  <button type="button" onClick={() => { setStep("phone"); setOtpDigits(["", "", "", ""]); setErrorMessage(""); setOtpAutofilled(false); }} className="text-white/80 hover:text-white active:scale-90 transition-transform" data-testid="button-back-otp"><ArrowLeft size={22} /></button>
                  <h2 className="text-lg font-extrabold text-white" data-testid="text-verify-title">Verify your number</h2>
                </div>
                <p className="text-sm text-white/70 mb-4">Enter OTP sent to <span className="font-bold text-white">{mobile}</span></p>
                <div className="grid grid-cols-4 gap-3 mb-3" onPaste={handleOtpPaste}>
                  {otpDigits.map((digit, idx) => (
                    <input key={idx} ref={otpRefs[idx]} type="tel" inputMode="numeric" maxLength={1} value={digit} onChange={(e) => handleOtpChange(idx, e.target.value)} onKeyDown={(e) => handleOtpKeyDown(idx, e)} autoComplete={idx === 0 ? "one-time-code" : "off"} className="w-full h-[50px] text-center text-2xl font-extrabold rounded-xl border-2 outline-none transition-colors" style={{ borderColor: digit ? "#ffffff" : "rgba(255,255,255,0.3)", backgroundColor: digit ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.08)", color: "#ffffff" }} data-testid={`input-otp-${idx}`} />
                  ))}
                </div>
                <div className="mb-4">
                  {!canResend ? (<p className="text-sm text-white/60">OTP sent. Retry in <span className="font-bold text-white">{resendTimer} seconds</span></p>) : (<button type="button" onClick={handleResendOtp} disabled={isLoading} className="text-sm font-bold text-white hover:underline" data-testid="button-resend-otp">{isLoading ? <Loader2 className="animate-spin inline mr-1" size={14} /> : null}Resend OTP</button>)}
                </div>
                <button type="submit" disabled={isLoading || !otpFull} className="w-full h-[50px] flex items-center justify-center text-base font-extrabold rounded-xl text-[#4f0073] shadow-xl shadow-black/15 transition-all active:scale-[0.98] disabled:opacity-40 disabled:shadow-none bg-white" data-testid="button-verify">{isLoading ? <Loader2 className="animate-spin" size={22} /> : "Verify & Continue"}</button>
              </form>
            )}
          </div>
        </div>
      </div>

      {errorMessage && (
        <div
          className="fixed inset-0 z-[200] flex items-center justify-center px-8"
          style={{ backgroundColor: "rgba(0,0,0,0.5)", backdropFilter: "blur(2px)" }}
          onClick={() => setErrorMessage("")}
          data-testid="alert-error-overlay"
        >
          <div
            className="w-full max-w-[280px] rounded-[14px] overflow-hidden shadow-2xl"
            style={{ backgroundColor: "rgba(245,245,245,0.96)", backdropFilter: "blur(20px)", animation: "alertPop 0.18s ease-out" }}
            onClick={(e) => e.stopPropagation()}
            data-testid="alert-error-dialog"
          >
            <div className="px-5 pt-5 pb-4 text-center">
              <div className="w-11 h-11 mx-auto mb-3 rounded-full bg-red-100 flex items-center justify-center">
                <AlertCircle size={26} className="text-red-500" />
              </div>
              <h3 className="text-[17px] font-semibold text-neutral-900 mb-1.5" data-testid="alert-error-title">
                {step === "otp" ? "Verification Failed" : "Couldn't Send OTP"}
              </h3>
              <p className="text-[13px] text-neutral-700 leading-snug" data-testid="alert-error-message">
                {errorMessage.includes("registered as") ? errorMessage.split(". ")[0] + "." : errorMessage}
              </p>
            </div>
            {errorMessage.includes("registered as") ? (
              <div className="grid grid-cols-2 border-t border-neutral-300/60">
                <button
                  type="button"
                  onClick={() => { vibrate(); setErrorMessage(""); }}
                  className="py-3 text-[16px] font-normal text-[#007aff] active:bg-neutral-200/50 border-r border-neutral-300/60"
                  data-testid="button-alert-cancel"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => { vibrate(); setErrorMessage(""); setLocation("/role-selection"); }}
                  className="py-3 text-[16px] font-semibold text-[#007aff] active:bg-neutral-200/50"
                  data-testid="button-alert-switch-role"
                >
                  Switch Role
                </button>
              </div>
            ) : (
              <div className="border-t border-neutral-300/60">
                <button
                  type="button"
                  onClick={() => { vibrate(); setErrorMessage(""); }}
                  className="w-full py-3 text-[16px] font-semibold text-[#007aff] active:bg-neutral-200/50"
                  data-testid="button-alert-ok"
                >
                  OK
                </button>
              </div>
            )}
          </div>
          <style>{`@keyframes alertPop { 0% { transform: scale(0.85); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }`}</style>
        </div>
      )}
    </div>
  );
}