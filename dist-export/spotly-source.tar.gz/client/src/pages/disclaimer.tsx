import { useState } from "react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { FileText } from "lucide-react";
import { motion } from "framer-motion";
import { vibrate } from "@/lib/vibrate";

export default function DisclaimerPage() {
  const [, setLocation] = useLocation();
  const [isAccepted, setIsAccepted] = useState(false);

  const role = localStorage.getItem("userRole") as "customer" | "worker" || "customer";

  const handleProceed = () => {
    if (!isAccepted) return;
    vibrate();
    
    localStorage.setItem("disclaimerAccepted", "true");
    localStorage.removeItem("isNewRegistration");
    
    // Navigate to location setup page based on role
    if (role === "worker") {
      setLocation("/worker/location-setup");
    } else {
      setLocation("/customer/location-setup");
    }
  };

  const getCheckboxLabel = () => {
    if (role === "worker") {
      return "I confirm that I am registering as a Space Seeker looking for parking spaces. I understand that I will be able to view parking space listings and contact Space Providers through the Spotly app. I accept that all communication, agreements, and outcomes with Space Providers are my sole responsibility, and Spotly is not responsible for any disputes, payments, or misuse. I agree to abide by the platform's Terms and Conditions and to use the app responsibly.";
    }
    return "I confirm that I am registering as a Space Provider to list parking spaces. I understand that my parking space details and contact information will be displayed to registered Space Seekers through the app. All agreements, discussions, and outcomes with Space Seekers are my sole responsibility, and Spotly is not responsible for any disputes, payments, or misuse. I agree to use the platform responsibly and in good faith.";
  };

  return (
    <MobileLayout>
      <div className="h-full flex flex-col bg-white">
        <div className="flex-1 overflow-y-auto p-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center"
          >
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <FileText className="w-8 h-8 text-primary" />
            </div>

            <h1 className="text-2xl font-bold text-neutral-900 mb-6 text-center">
              Terms & Conditions
            </h1>

            <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-5 mb-6 w-full text-sm">
              <div className="space-y-5">
                <section>
                  <h2 className="text-base font-bold text-primary mb-3">1. Terms of Service</h2>
                  
                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">1.1 Platform Overview</h3>
                    <p className="text-neutral-600 leading-relaxed">
                      Spotly is a mobile-based platform that connects parking Space Providers with Space Seekers. Space Providers can list their available car and bike parking spaces, and Space Seekers can browse and connect with them for parking needs.
                    </p>
                  </div>

                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">1.2 User Roles</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-2">
                      <li><strong>Space Providers:</strong> Individuals with available parking spaces can register to list their spaces with details like location, rent, and photos. Upon registration, Space Providers consent to their listing details being displayed to registered Space Seekers.</li>
                      <li><strong>Space Seekers:</strong> Users looking for parking spaces can register to browse available listings and contact Space Providers directly. Only registered Space Seekers can view provider contact details.</li>
                    </ul>
                  </div>

                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">1.3 User Responsibilities</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>Users must use the platform responsibly and in good faith.</li>
                      <li>All interactions, agreements, negotiations, payments, or services arranged are between users only.</li>
                      <li>Spotly does not verify users, mediate disputes, or act as an employer, agent, or contractor.</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-neutral-800 mb-1">1.4 Prohibited Use</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>Misusing the app to harass, scam, or defraud other users is strictly prohibited.</li>
                      <li>Users must not share false information or impersonate other users.</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h2 className="text-base font-bold text-primary mb-3">2. Privacy Policy</h2>
                  
                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">2.1 Information Collected</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>Space Providers: Name, contact number, parking space details (location, rent, photos).</li>
                      <li>Space Seekers: Name, contact information, and location preferences.</li>
                    </ul>
                  </div>

                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">2.2 Purpose of Data Collection</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>To facilitate communication between Space Providers and Space Seekers for parking arrangements.</li>
                      <li>To display Space Provider contact details and parking space listings only to registered Space Seekers.</li>
                    </ul>
                  </div>

                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">2.3 Consent to Share Contact Information</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>By registering, Space Providers consent to their parking space details being shared with registered Space Seekers for parking-related communication.</li>
                      <li>Users are responsible for safeguarding their own privacy during interactions.</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-neutral-800 mb-1">2.4 Data Security</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>Spotly stores data securely, but cannot guarantee user behavior outside the platform.</li>
                      <li>Users are advised to communicate responsibly and verify information before engaging in any service or payment.</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h2 className="text-base font-bold text-primary mb-3">3. Payment Policy</h2>
                  
                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">3.1 Premium Services / Subscription</h3>
                    <p className="text-neutral-600 leading-relaxed">
                      Spotly may offer premium services or subscriptions for enhanced visibility or features.
                    </p>
                  </div>

                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">3.2 Payment & Refunds</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>All payments must be completed through the app's payment gateway.</li>
                      <li><strong>Cancellation & Refund Policy:</strong> Once a payment for a premium subscription is made, it is non-refundable. Users must ensure they understand the payment before confirming.</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-neutral-800 mb-1">3.3 User Responsibility</h3>
                    <p className="text-neutral-600 leading-relaxed">
                      Users are responsible for managing their subscriptions, payments, and access to premium features.
                    </p>
                  </div>
                </section>

                <section>
                  <h2 className="text-base font-bold text-primary mb-3">4. Liability & Disputes</h2>
                  
                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">4.1 Platform Limitation</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>Spotly operates solely as a facilitation platform.</li>
                      <li>The company does not verify users, oversee services, guarantee quality, or mediate agreements.</li>
                    </ul>
                  </div>

                  <div className="mb-3">
                    <h3 className="font-semibold text-neutral-800 mb-1">4.2 User Responsibility</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>All negotiations, service arrangements, payments, and disputes are the sole responsibility of the users.</li>
                      <li>Users engage with the platform at their own risk, and Spotly is not liable for any disputes, losses, or damages.</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-neutral-800 mb-1">4.3 Dispute Resolution</h3>
                    <ul className="text-neutral-600 leading-relaxed list-disc pl-4 space-y-1">
                      <li>Users should attempt to resolve disputes directly with the other party.</li>
                      <li>Spotly will not intervene or act as a mediator.</li>
                    </ul>
                  </div>
                </section>
              </div>
            </div>

            <div className="w-full bg-primary/5 border border-primary/20 p-4 rounded-xl mb-4">
              <p className="text-xs text-primary font-medium mb-2">
                {role === "worker" ? "For Space Seekers:" : "For Space Providers:"}
              </p>
              <div className="flex items-start gap-3">
                <Checkbox
                  id="accept"
                  checked={isAccepted}
                  onCheckedChange={(checked) => setIsAccepted(checked === true)}
                  className="mt-0.5"
                  data-testid="checkbox-accept-disclaimer"
                />
                <label htmlFor="accept" className="text-xs text-neutral-700 cursor-pointer leading-relaxed">
                  {getCheckboxLabel()}
                </label>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="p-6 border-t bg-white">
          <Button
            onClick={handleProceed}
            disabled={!isAccepted}
            className="w-full h-12 rounded-xl text-lg shadow-md"
            data-testid="button-proceed-disclaimer"
          >
            Accept & Continue
          </Button>
        </div>
      </div>
    </MobileLayout>
  );
}
