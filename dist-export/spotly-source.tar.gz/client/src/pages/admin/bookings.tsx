import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { adminFetch } from "@/lib/api-config";
import { 
  Globe,
  MapPin, 
  Users, 
  LogOut,
  TrendingUp,
  Calendar,
  Car,
  Briefcase,
  Settings,
  Search,
  Filter,
  Heart,
  IndianRupee,
  FileText,
  Phone,
  User
} from "lucide-react";
import logo from "@assets/spotly_logo_transparent.png";

interface ParkingSpace {
  id: string;
  customerId: string;
  serviceId: string;
  serviceName: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  city: string | null;
  comments: string | null;
  status: string;
  date: string;
  time: string;
  bookedAt: string;
  customerName?: string;
  customerMobile?: string;
  interestCount?: number;
}

function parseComments(comments: string | null) {
  if (!comments) return { rent: "", description: "", photos: [] as string[] };
  let rent = "";
  let description = comments;
  let photos: string[] = [];

  const rentMatch = comments.match(/Rent:\s*₹([\d,]+)\/month/);
  if (rentMatch) {
    rent = rentMatch[1];
  }

  const pipeIndex = comments.indexOf(" | ");
  if (pipeIndex !== -1) {
    description = comments.substring(pipeIndex + 3);
  }

  const photosMatch = description.match(/\[PHOTOS\](.*?)\[\/PHOTOS\]/s);
  if (photosMatch) {
    description = description.replace(/\[PHOTOS\].*?\[\/PHOTOS\]/s, "").trim();
    photos = photosMatch[1].split(",").filter(p => p.trim());
  }

  return { rent, description, photos };
}

export default function AdminBookings() {
  const [, setLocation] = useLocation();
  const [spaces, setSpaces] = useState<ParkingSpace[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [cityFilter, setCityFilter] = useState("");
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  useEffect(() => {
    const isAdmin = localStorage.getItem("isAdmin");
    if (!isAdmin) {
      setLocation("/admin");
      return;
    }
    fetchSpaces();
  }, []);

  const fetchSpaces = async () => {
    try {
      const [bookingsRes, usersRes] = await Promise.all([
        adminFetch("/api/admin/bookings"),
        adminFetch("/api/admin/users"),
      ]);
      
      if (bookingsRes.ok) {
        const bookingsData = await bookingsRes.json();
        const usersData = usersRes.ok ? await usersRes.json() : { users: [] };
        const userMap = new Map<string, { name: string; mobile: string }>();
        (usersData.users || []).forEach((u: any) => {
          userMap.set(u.id, { name: u.name, mobile: u.mobile });
        });

        const interestsRes = await adminFetch("/api/interests/counts");
        const interestsData = interestsRes.ok ? await interestsRes.json() : { counts: {} };

        const enrichedSpaces = (bookingsData.bookings || []).map((b: any) => ({
          ...b,
          customerName: userMap.get(b.customerId)?.name || "Unknown",
          customerMobile: userMap.get(b.customerId)?.mobile || "",
          interestCount: interestsData.counts?.[b.id] || 0,
        }));
        setSpaces(enrichedSpaces);
      }
    } catch (error) {
      console.error("Failed to fetch parking spaces:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminLevel");
    setLocation("/admin");
  };

  const cities = Array.from(new Set(spaces.map(s => s.city).filter(Boolean))) as string[];

  const filteredSpaces = spaces.filter(space => {
    const matchesSearch = searchQuery === "" || 
      space.serviceName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      space.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      space.customerName?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCity = cityFilter === "" || space.city === cityFilter;
    return matchesSearch && matchesCity;
  });

  const navItems = [
    { label: "Dashboard", path: "/admin/dashboard", icon: TrendingUp },
    { label: "Parking Types", path: "/admin/services", icon: Briefcase },
    { label: "Service States", path: "/admin/pincodes", icon: Globe },
    { label: "Space Providers", path: "/admin/customers", icon: Users },
    { label: "Space Seekers", path: "/admin/workers", icon: Users },
    { label: "Parking Spaces", path: "/admin/bookings", icon: Car, active: true },
    { label: "Settings", path: "/admin/settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-neutral-100">
      <header className="bg-primary text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Spotly" className="h-9 w-auto object-contain" />
            <div>
              <h1 className="text-xl font-bold" data-testid="text-admin-title">Spotly Admin</h1>
              <p className="text-sm text-white/70">Parking Space Management</p>
            </div>
          </div>
          <Button
            variant="ghost"
            onClick={() => setShowLogoutConfirm(true)}
            className="text-white hover:bg-white/20"
            data-testid="button-logout"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-sm mx-4 shadow-xl">
            <h3 className="text-lg font-bold text-neutral-900 mb-2">Confirm Logout</h3>
            <p className="text-neutral-600 mb-6">Are you sure you want to logout from the admin panel?</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowLogoutConfirm(false)} data-testid="button-cancel-logout">
                Cancel
              </Button>
              <Button className="flex-1 bg-red-600 hover:bg-red-700" onClick={handleLogout} data-testid="button-confirm-logout">
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto p-6">
        <nav className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {navItems.map((item) => (
            <Button
              key={item.path}
              variant={item.active ? "default" : "outline"}
              onClick={() => setLocation(item.path)}
              className="rounded-full whitespace-nowrap"
              data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <item.icon size={16} className="mr-2" />
              {item.label}
            </Button>
          ))}
        </nav>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-xl font-bold" data-testid="text-page-title">Parking Spaces ({filteredSpaces.length})</h2>
          <div className="flex gap-2 flex-wrap items-center">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                placeholder="Search by type, location, provider..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 rounded-full border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 w-64"
                data-testid="input-search"
              />
            </div>
            <div className="relative">
              <Filter size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <select
                value={cityFilter}
                onChange={(e) => setCityFilter(e.target.value)}
                className="pl-9 pr-8 py-2 rounded-full border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 appearance-none bg-white"
                data-testid="select-city-filter"
              >
                <option value="">All Cities</option>
                {cities.map(city => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredSpaces.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center">
            <Car className="w-16 h-16 mx-auto mb-4 text-neutral-300" />
            <h3 className="text-lg font-bold text-neutral-900 mb-2" data-testid="text-empty-title">No Parking Spaces Found</h3>
            <p className="text-neutral-500" data-testid="text-empty-message">No parking spaces match your search criteria</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="table-parking-spaces">
                <thead className="bg-neutral-50 border-b">
                  <tr>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Parking Type</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Location</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Rent</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Description</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Posted By</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Mobile</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Date Posted</th>
                    <th className="text-left p-4 font-semibold text-neutral-600 text-sm">Interests</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredSpaces.map((space) => {
                    const parsed = parseComments(space.comments);
                    return (
                      <tr key={space.id} className="hover:bg-neutral-50" data-testid={`row-space-${space.id}`}>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <Car size={16} className="text-primary shrink-0" />
                            <span className="font-medium text-neutral-900 text-sm" data-testid={`text-type-${space.id}`}>{space.serviceName}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-start gap-1 text-neutral-600 max-w-[200px]">
                            <MapPin size={14} className="shrink-0 mt-0.5" />
                            <span className="text-sm leading-snug" data-testid={`text-location-${space.id}`}>{space.location}</span>
                          </div>
                          {space.city && (
                            <p className="text-xs text-neutral-400 mt-1 ml-5">{space.city}</p>
                          )}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1">
                            <IndianRupee size={14} className="text-green-600 shrink-0" />
                            <span className="font-semibold text-green-700 text-sm" data-testid={`text-rent-${space.id}`}>
                              {parsed.rent ? `${parsed.rent}/mo` : "N/A"}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="max-w-[180px]">
                            <span className="text-sm text-neutral-600 line-clamp-2" data-testid={`text-description-${space.id}`}>
                              {parsed.description || "No description"}
                            </span>
                            {parsed.photos.length > 0 && (
                              <p className="text-xs text-primary mt-1">{parsed.photos.length} photo(s)</p>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5">
                            <User size={14} className="text-neutral-400 shrink-0" />
                            <span className="font-medium text-neutral-900 text-sm" data-testid={`text-provider-${space.id}`}>
                              {space.customerName || "Unknown"}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5">
                            <Phone size={14} className="text-neutral-400 shrink-0" />
                            <span className="text-sm text-neutral-600 font-mono" data-testid={`text-mobile-${space.id}`}>
                              {space.customerMobile || "N/A"}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1 text-neutral-600">
                            <Calendar size={14} className="shrink-0" />
                            <span className="text-sm whitespace-nowrap" data-testid={`text-date-${space.id}`}>
                              {new Date(space.bookedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1 text-pink-600">
                            <Heart size={14} />
                            <span className="font-medium" data-testid={`text-interests-${space.id}`}>
                              {space.interestCount ?? 0}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
