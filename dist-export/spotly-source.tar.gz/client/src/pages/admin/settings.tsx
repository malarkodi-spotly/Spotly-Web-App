import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getApiUrl, adminFetch } from "@/lib/api-config";
import { 
  Settings, 
  LogOut,
  TrendingUp,
  Users,
  Car,
  Briefcase,
  Wrench,
  Save,
  Loader2,
  Bell,
  Send,
  Rocket,
  Phone,
  Mail,
  Globe,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import logo from "@assets/spotly_logo_transparent.png";

export default function AdminSettings() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  
  const [premiumBasicPrice, setPremiumBasicPrice] = useState("199");
  const [premiumBasicEnabled, setPremiumBasicEnabled] = useState(true);
  const [premiumBasicViews, setPremiumBasicViews] = useState("10");
  const [premiumStandardPrice, setPremiumStandardPrice] = useState("299");
  const [premiumStandardEnabled, setPremiumStandardEnabled] = useState(true);
  const [premiumStandardViews, setPremiumStandardViews] = useState("20");
  const [premiumPremiumPrice, setPremiumPremiumPrice] = useState("399");
  const [premiumPremiumEnabled, setPremiumPremiumEnabled] = useState(true);
  const [isSavingPlans, setIsSavingPlans] = useState(false);
  const [appVersion, setAppVersion] = useState("1.0.0");
  const [supportPhone, setSupportPhone] = useState("+91 9742545584");
  const [supportEmail, setSupportEmail] = useState("info@spotlyindia.org");
  const [isSavingSupport, setIsSavingSupport] = useState(false);
  const [adVideoUrl, setAdVideoUrl] = useState("");
  const [isSavingVideo, setIsSavingVideo] = useState(false);
  const [videoFileName, setVideoFileName] = useState("");
  const [adVideoEnabled, setAdVideoEnabled] = useState(true);
  
  const [broadcastTitle, setBroadcastTitle] = useState("");
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [broadcastTarget, setBroadcastTarget] = useState<"workers" | "customers" | "all">("all");
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [comingSoonMode, setComingSoonMode] = useState(false);
  const [isSavingComingSoon, setIsSavingComingSoon] = useState(false);
  const [showComingSoonConfirm, setShowComingSoonConfirm] = useState(false);
  const [pendingComingSoonValue, setPendingComingSoonValue] = useState(false);

  useEffect(() => {
    const validateAndFetch = async () => {
      const isAdmin = localStorage.getItem("isAdmin");
      const adminToken = localStorage.getItem("adminToken");
      if (!isAdmin || !adminToken) {
        setLocation("/admin");
        return;
      }
      
      // Validate session with server
      try {
        const sessionRes = await adminFetch("/api/admin/session");
        if (!sessionRes.ok) {
          // Session expired or invalid - clear and redirect to login
          localStorage.removeItem("isAdmin");
          localStorage.removeItem("adminLevel");
          localStorage.removeItem("adminToken");
          setLocation("/admin");
          return;
        }
      } catch (error) {
        console.error("Session validation failed:", error);
        setLocation("/admin");
        return;
      }
      
      fetchSettings();
    };
    validateAndFetch();
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem("adminToken");
    return {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    };
  };

  const fetchSettings = async () => {
    try {
      const [plansRes, versionRes, comingSoonRes, phoneRes, emailRes, videoRes] = await Promise.all([
        fetch(getApiUrl("/api/settings/premium-plans")),
        fetch(getApiUrl("/api/settings/app_version")),
        fetch(getApiUrl("/api/settings/coming_soon_mode")),
        fetch(getApiUrl("/api/settings/support_phone")),
        fetch(getApiUrl("/api/settings/support_email")),
        fetch(getApiUrl("/api/settings/ad_video_url"))
      ]);
      
      if (plansRes.ok) {
        const data = await plansRes.json();
        if (data.plans) {
          const basic = data.plans.find((p: any) => p.key === "basic");
          const standard = data.plans.find((p: any) => p.key === "standard");
          const premium = data.plans.find((p: any) => p.key === "premium");
          if (basic) { setPremiumBasicPrice(String(basic.price)); setPremiumBasicEnabled(basic.enabled); setPremiumBasicViews(String(basic.views)); }
          if (standard) { setPremiumStandardPrice(String(standard.price)); setPremiumStandardEnabled(standard.enabled); setPremiumStandardViews(String(standard.views)); }
          if (premium) { setPremiumPremiumPrice(String(premium.price)); setPremiumPremiumEnabled(premium.enabled); }
        }
      }
      if (versionRes.ok) {
        const data = await versionRes.json();
        if (data.setting?.value) {
          setAppVersion(data.setting.value);
        }
      }
      if (comingSoonRes.ok) {
        const data = await comingSoonRes.json();
        if (data.setting?.value) {
          setComingSoonMode(data.setting.value === "true");
        }
      }
      if (phoneRes.ok) {
        const data = await phoneRes.json();
        if (data.setting?.value) {
          setSupportPhone(data.setting.value);
        }
      }
      if (emailRes.ok) {
        const data = await emailRes.json();
        if (data.setting?.value) {
          setSupportEmail(data.setting.value);
        }
      }
      if (videoRes.ok) {
        const data = await videoRes.json();
        if (data.setting?.value) {
          setAdVideoUrl(data.setting.value);
        }
      }
      const videoEnabledRes = await fetch(getApiUrl("/api/settings/ad_video_enabled"));
      if (videoEnabledRes.ok) {
        const data = await videoEnabledRes.json();
        if (data.setting?.value !== undefined) {
          setAdVideoEnabled(data.setting.value === "true");
        }
      }
    } catch (error) {
      console.error("Failed to fetch settings:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const [errorMessage, setErrorMessage] = useState("");

  const handleSavePremiumPlans = async () => {
    setIsSavingPlans(true);
    setErrorMessage("");
    try {
      const settings = [
        { key: "premium_basic_price", value: premiumBasicPrice, description: "Basic plan price in INR" },
        { key: "premium_basic_enabled", value: String(premiumBasicEnabled), description: "Basic plan enabled" },
        { key: "premium_basic_views", value: premiumBasicViews, description: "Basic plan view count" },
        { key: "premium_standard_price", value: premiumStandardPrice, description: "Standard plan price in INR" },
        { key: "premium_standard_enabled", value: String(premiumStandardEnabled), description: "Standard plan enabled" },
        { key: "premium_standard_views", value: premiumStandardViews, description: "Standard plan view count" },
        { key: "premium_premium_price", value: premiumPremiumPrice, description: "Premium plan price in INR" },
        { key: "premium_premium_enabled", value: String(premiumPremiumEnabled), description: "Premium plan enabled" },
      ];

      for (const s of settings) {
        const res = await adminFetch("/api/admin/settings", {
          method: "POST",
          body: JSON.stringify(s),
        });
        if (!res.ok) {
          const errorData = await res.json();
          setErrorMessage(errorData.error || "Failed to save premium plans.");
          return;
        }
      }
      setSuccessMessage("Premium plans saved successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Failed to save premium plans:", error);
      setErrorMessage("Failed to save. Please check your connection.");
    } finally {
      setIsSavingPlans(false);
    }
  };

  const handleSaveAppVersion = async () => {
    setIsSaving(true);
    setErrorMessage("");
    try {
      const res = await adminFetch("/api/admin/settings", {
        method: "POST",
        body: JSON.stringify({
          key: "app_version",
          value: appVersion,
          description: "Current app version"
        }),
      });
      if (!res.ok) {
        const errorData = await res.json();
        setErrorMessage(errorData.error || "Failed to save app version.");
        return;
      }
      setSuccessMessage("App version saved successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Failed to save app version:", error);
      setErrorMessage("Failed to save. Please check your connection.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveSupportInfo = async () => {
    setIsSavingSupport(true);
    setErrorMessage("");
    try {
      const [phoneRes, emailRes] = await Promise.all([
        adminFetch("/api/admin/settings", {
          method: "POST",
          body: JSON.stringify({
            key: "support_phone",
            value: supportPhone,
            description: "Support phone number"
          }),
        }),
        adminFetch("/api/admin/settings", {
          method: "POST",
          body: JSON.stringify({
            key: "support_email",
            value: supportEmail,
            description: "Support email address"
          }),
        })
      ]);
      if (!phoneRes.ok || !emailRes.ok) {
        const errorData = !phoneRes.ok ? await phoneRes.json() : await emailRes.json();
        setErrorMessage(errorData.error || "Failed to save support info.");
        return;
      }
      setSuccessMessage("Customer care info saved successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Failed to save support info:", error);
      setErrorMessage("Failed to save. Please check your connection.");
    } finally {
      setIsSavingSupport(false);
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("video/")) {
      setErrorMessage("Please select a valid video file.");
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      setErrorMessage("Video file must be under 50MB.");
      return;
    }
    setIsSavingVideo(true);
    setErrorMessage("");
    setVideoFileName(file.name);
    
    const formData = new FormData();
    formData.append("video", file);
    
    try {
      const token = localStorage.getItem("adminToken");
      const res = await fetch(getApiUrl("/api/admin/upload-video"), {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` },
        body: formData,
      });
      if (!res.ok) {
        const errorData = await res.json();
        setErrorMessage(errorData.error || "Failed to upload video.");
        return;
      }
      const data = await res.json();
      setAdVideoUrl(data.url);
      setSuccessMessage("Ad video uploaded successfully!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Failed to upload video:", error);
      setErrorMessage("Failed to upload. Please check your connection.");
    } finally {
      setIsSavingVideo(false);
    }
  };

  const handleToggleVideo = async (enabled: boolean) => {
    setAdVideoEnabled(enabled);
    try {
      await adminFetch("/api/admin/settings", {
        method: "POST",
        body: JSON.stringify({
          key: "ad_video_enabled",
          value: String(enabled),
          description: "Ad video enabled/disabled"
        }),
      });
      setSuccessMessage(enabled ? "Ad video enabled!" : "Ad video disabled!");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      setAdVideoEnabled(!enabled);
    }
  };

  const handleRemoveVideo = async () => {
    setIsSavingVideo(true);
    setErrorMessage("");
    try {
      const res = await adminFetch("/api/admin/settings", {
        method: "POST",
        body: JSON.stringify({
          key: "ad_video_url",
          value: "",
          description: "Ad video URL for home pages"
        }),
      });
      if (res.ok) {
        setAdVideoUrl("");
        setVideoFileName("");
        setSuccessMessage("Ad video removed!");
        setTimeout(() => setSuccessMessage(""), 3000);
      }
    } catch (error) {
      setErrorMessage("Failed to remove video.");
    } finally {
      setIsSavingVideo(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("adminLevel");
    localStorage.removeItem("adminToken");
    setLocation("/admin");
  };

  const handleComingSoonSwitchChange = (enabled: boolean) => {
    setPendingComingSoonValue(enabled);
    setShowComingSoonConfirm(true);
  };

  const handleConfirmComingSoon = async () => {
    setShowComingSoonConfirm(false);
    setIsSavingComingSoon(true);
    setComingSoonMode(pendingComingSoonValue);
    try {
      const res = await adminFetch("/api/admin/settings", {
        method: "POST",
        body: JSON.stringify({
          key: "coming_soon_mode",
          value: pendingComingSoonValue.toString(),
          description: "When enabled, shows 'Launching Soon' message to all users"
        }),
      });
      if (!res.ok) {
        setComingSoonMode(!pendingComingSoonValue);
        setErrorMessage("Failed to update Coming Soon mode");
        return;
      }
      setSuccessMessage(`Coming Soon mode ${pendingComingSoonValue ? "enabled" : "disabled"} successfully!`);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Failed to toggle coming soon mode:", error);
      setComingSoonMode(!pendingComingSoonValue);
      setErrorMessage("Failed to update. Please check your connection.");
    } finally {
      setIsSavingComingSoon(false);
    }
  };

  const handleBroadcastNotification = async () => {
    if (!broadcastTitle.trim() || !broadcastMessage.trim()) {
      setErrorMessage("Title and message are required for broadcast");
      return;
    }
    
    setIsBroadcasting(true);
    setErrorMessage("");
    try {
      const res = await adminFetch("/api/admin/broadcast", {
        method: "POST",
        body: JSON.stringify({
          title: broadcastTitle,
          message: broadcastMessage,
          target: broadcastTarget
        }),
      });
      if (!res.ok) {
        const errorData = await res.json();
        setErrorMessage(errorData.error || "Failed to send broadcast");
        return;
      }
      setSuccessMessage(`Broadcast sent to ${broadcastTarget === 'all' ? 'all users' : broadcastTarget === 'customers' ? 'Space Providers' : 'Space Seekers'} successfully!`);
      setBroadcastTitle("");
      setBroadcastMessage("");
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Failed to send broadcast:", error);
      setErrorMessage("Failed to send broadcast. Please check your connection.");
    } finally {
      setIsBroadcasting(false);
    }
  };

  const navItems = [
    { icon: TrendingUp, label: "Dashboard", path: "/admin/dashboard" },
    { icon: Wrench, label: "Parking Types", path: "/admin/services" },
    { icon: Globe, label: "Service States", path: "/admin/pincodes" },
    { icon: Users, label: "Space Providers", path: "/admin/customers" },
    { icon: Briefcase, label: "Space Seekers", path: "/admin/workers" },
    { icon: Car, label: "Parking Spaces", path: "/admin/bookings" },
    { icon: Settings, label: "Settings", path: "/admin/settings" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="w-64 bg-[#4f0073] text-white min-h-screen p-4 hidden md:block">
        <div className="flex items-center gap-3 mb-8">
          <img src={logo} alt="Spotly" className="h-9 w-auto object-contain" />
          <h1 className="text-lg font-bold">Spotly</h1>
        </div>
        <nav className="space-y-2">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => setLocation(item.path)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                item.path === "/admin/settings" ? "bg-white/20" : "hover:bg-white/10"
              }`}
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>
        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left hover:bg-white/10 mt-8 text-red-200"
          data-testid="button-logout"
        >
          <LogOut size={20} />
          Logout
        </button>
      </aside>

      <main className="flex-1 p-6">
        <div className="md:hidden flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Spotly" className="h-7 w-auto object-contain" />
            <h1 className="text-lg font-bold text-[#4f0073]">Spotly Admin</h1>
          </div>
          <button
            onClick={() => setShowLogoutConfirm(true)}
            className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
            data-testid="button-logout-mobile"
          >
            <LogOut size={20} />
          </button>
        </div>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-[#4f0073]/10 rounded-xl flex items-center justify-center">
            <Settings className="text-[#4f0073]" size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
            <p className="text-gray-500">Manage app settings</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin text-[#4f0073]" size={32} />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Coming Soon Mode Toggle */}
            <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl shadow-sm border border-purple-200 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                    <Rocket className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-purple-900">Coming Soon Mode</h3>
                    <p className="text-sm text-purple-700">When enabled, shows "Launching Soon" message to all app users</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {isSavingComingSoon && (
                    <Loader2 className="animate-spin text-purple-600" size={16} />
                  )}
                  <Switch
                    checked={comingSoonMode}
                    onCheckedChange={handleComingSoonSwitchChange}
                    disabled={isSavingComingSoon}
                    data-testid="switch-coming-soon"
                  />
                </div>
              </div>
              <div className={`mt-4 p-3 rounded-lg ${comingSoonMode ? 'bg-purple-200 text-purple-800' : 'bg-white text-gray-600'}`}>
                <p className="text-sm font-medium">
                  {comingSoonMode 
                    ? "✨ App is in pre-launch mode. Users will see 'Launching Soon' message."
                    : "App is live. Users can access all features normally."}
                </p>
              </div>
            </div>

            {successMessage && (
              <div className="bg-green-50 text-green-700 px-4 py-3 rounded-lg text-sm">
                {successMessage}
              </div>
            )}

            {errorMessage && (
              <div className="bg-red-50 text-red-700 px-4 py-3 rounded-lg text-sm">
                {errorMessage}
              </div>
            )}

            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <span className="text-green-600 text-lg font-bold">₹</span>
                </div>
                <div>
                  <h3 className="font-bold text-lg">Space Seekers Premium</h3>
                  <p className="text-sm text-gray-500">Configure premium subscription plans for Space Seekers</p>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className={`border rounded-xl p-4 ${premiumBasicEnabled ? "border-blue-200 bg-blue-50/30" : "border-gray-200 bg-gray-50 opacity-60"}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-blue-600">Basic Plan</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">{premiumBasicEnabled ? "Active" : "Off"}</span>
                      <Switch
                        checked={premiumBasicEnabled}
                        onCheckedChange={setPremiumBasicEnabled}
                        data-testid="switch-basic-plan"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <Label className="text-xs text-gray-500">Price (₹)</Label>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-sm font-bold text-gray-400">₹</span>
                        <Input
                          type="number"
                          value={premiumBasicPrice}
                          onChange={(e) => setPremiumBasicPrice(e.target.value)}
                          className="h-9"
                          data-testid="input-basic-price"
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <Label className="text-xs text-gray-500">Views</Label>
                      <Input
                        type="number"
                        value={premiumBasicViews}
                        onChange={(e) => setPremiumBasicViews(e.target.value)}
                        className="h-9 mt-1"
                        data-testid="input-basic-views"
                      />
                    </div>
                  </div>
                </div>

                <div className={`border rounded-xl p-4 ${premiumStandardEnabled ? "border-purple-200 bg-purple-50/30" : "border-gray-200 bg-gray-50 opacity-60"}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-purple-600">Standard Plan</span>
                      <span className="text-[9px] bg-purple-600 text-white px-1.5 py-0.5 rounded-full font-bold">Popular</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">{premiumStandardEnabled ? "Active" : "Off"}</span>
                      <Switch
                        checked={premiumStandardEnabled}
                        onCheckedChange={setPremiumStandardEnabled}
                        data-testid="switch-standard-plan"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <Label className="text-xs text-gray-500">Price (₹)</Label>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-sm font-bold text-gray-400">₹</span>
                        <Input
                          type="number"
                          value={premiumStandardPrice}
                          onChange={(e) => setPremiumStandardPrice(e.target.value)}
                          className="h-9"
                          data-testid="input-standard-price"
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <Label className="text-xs text-gray-500">Views</Label>
                      <Input
                        type="number"
                        value={premiumStandardViews}
                        onChange={(e) => setPremiumStandardViews(e.target.value)}
                        className="h-9 mt-1"
                        data-testid="input-standard-views"
                      />
                    </div>
                  </div>
                </div>

                <div className={`border rounded-xl p-4 ${premiumPremiumEnabled ? "border-yellow-200 bg-yellow-50/30" : "border-gray-200 bg-gray-50 opacity-60"}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-yellow-600">Premium Plan</span>
                      <span className="text-[9px] bg-yellow-500 text-white px-1.5 py-0.5 rounded-full font-bold">Unlimited</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">{premiumPremiumEnabled ? "Active" : "Off"}</span>
                      <Switch
                        checked={premiumPremiumEnabled}
                        onCheckedChange={setPremiumPremiumEnabled}
                        data-testid="switch-premium-plan"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <Label className="text-xs text-gray-500">Price (₹)</Label>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-sm font-bold text-gray-400">₹</span>
                        <Input
                          type="number"
                          value={premiumPremiumPrice}
                          onChange={(e) => setPremiumPremiumPrice(e.target.value)}
                          className="h-9"
                          data-testid="input-premium-price"
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <Label className="text-xs text-gray-500">Views</Label>
                      <Input
                        type="text"
                        value="Unlimited"
                        disabled
                        className="h-9 mt-1 bg-gray-100"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleSavePremiumPlans}
                disabled={isSavingPlans}
                className="bg-[#4f0073] hover:bg-[#3d005a]"
                data-testid="button-save-premium"
              >
                {isSavingPlans ? (
                  <Loader2 className="animate-spin mr-2" size={16} />
                ) : (
                  <Save className="mr-2" size={16} />
                )}
                Save Premium Plans
              </Button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-blue-600 text-sm font-bold">V</span>
                </div>
                <div>
                  <h3 className="font-bold text-lg">App Version</h3>
                  <p className="text-sm text-gray-500">Set the current app version</p>
                </div>
              </div>

              <div className="mb-6">
                <Label htmlFor="app-version" className="text-sm font-medium">Version</Label>
                <Input
                  id="app-version"
                  type="text"
                  value={appVersion}
                  onChange={(e) => setAppVersion(e.target.value)}
                  placeholder="e.g., 1.0.0"
                  className="mt-2 max-w-[200px]"
                  data-testid="input-app-version"
                />
                <p className="text-xs text-gray-400 mt-1">Current version displayed in the app</p>
              </div>

              <Button
                onClick={handleSaveAppVersion}
                disabled={isSaving}
                className="bg-[#4f0073] hover:bg-[#3d005a]"
                data-testid="button-save-version"
              >
                {isSaving ? (
                  <Loader2 className="animate-spin mr-2" size={16} />
                ) : (
                  <Save className="mr-2" size={16} />
                )}
                Save App Version
              </Button>
            </div>

            {/* Customer Care Settings */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Phone className="text-green-600" size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Customer Care Info</h3>
                  <p className="text-sm text-gray-500">Set contact details shown across the app</p>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div>
                  <Label htmlFor="support-phone" className="text-sm font-medium flex items-center gap-2">
                    <Phone size={14} />
                    Phone Number
                  </Label>
                  <Input
                    id="support-phone"
                    type="tel"
                    value={supportPhone}
                    onChange={(e) => setSupportPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="mt-2"
                    data-testid="input-support-phone"
                  />
                </div>
                <div>
                  <Label htmlFor="support-email" className="text-sm font-medium flex items-center gap-2">
                    <Mail size={14} />
                    Email Address
                  </Label>
                  <Input
                    id="support-email"
                    type="email"
                    value={supportEmail}
                    onChange={(e) => setSupportEmail(e.target.value)}
                    placeholder="info@spotlyindia.org"
                    className="mt-2"
                    data-testid="input-support-email"
                  />
                </div>
              </div>

              <Button
                onClick={handleSaveSupportInfo}
                disabled={isSavingSupport}
                className="bg-[#4f0073] hover:bg-[#3d005a]"
                data-testid="button-save-support"
              >
                {isSavingSupport ? (
                  <Loader2 className="animate-spin mr-2" size={16} />
                ) : (
                  <Save className="mr-2" size={16} />
                )}
                Save Customer Care Info
              </Button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <Globe className="text-red-600" size={20} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">Ad Video</h3>
                  <p className="text-sm text-gray-500">Upload a video to auto-play on home pages</p>
                </div>
                <Switch
                  checked={adVideoEnabled}
                  onCheckedChange={handleToggleVideo}
                  data-testid="switch-ad-video"
                />
              </div>

              {adVideoUrl ? (
                <div className="mb-6">
                  <div className="relative aspect-[2/1] rounded-xl overflow-hidden bg-black mb-3">
                    <video
                      src={adVideoUrl}
                      className="w-full h-full object-cover"
                      autoPlay
                      loop
                      muted
                      playsInline
                    />
                  </div>
                  <p className="text-xs text-green-600 font-medium mb-3">Video uploaded and playing on home pages</p>
                  <Button
                    onClick={handleRemoveVideo}
                    disabled={isSavingVideo}
                    variant="destructive"
                    data-testid="button-remove-video"
                  >
                    {isSavingVideo ? (
                      <Loader2 className="animate-spin mr-2" size={16} />
                    ) : null}
                    Remove Video
                  </Button>
                </div>
              ) : (
                <div className="mb-6">
                  <label
                    htmlFor="ad-video-upload"
                    className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[#4f0073] hover:bg-purple-50/30 transition-colors"
                  >
                    {isSavingVideo ? (
                      <div className="flex flex-col items-center gap-2">
                        <Loader2 className="animate-spin text-[#4f0073]" size={24} />
                        <span className="text-sm text-gray-500">Uploading {videoFileName}...</span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <Globe className="text-gray-400" size={24} />
                        <span className="text-sm text-gray-500 font-medium">Click to upload video</span>
                        <span className="text-xs text-gray-400">MP4, WebM (max 50MB)</span>
                      </div>
                    )}
                  </label>
                  <input
                    id="ad-video-upload"
                    type="file"
                    accept="video/*"
                    className="hidden"
                    onChange={handleVideoUpload}
                    disabled={isSavingVideo}
                    data-testid="input-ad-video-upload"
                  />
                </div>
              )}
            </div>

            <div className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Bell className="text-purple-600" size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Broadcast Notification</h3>
                  <p className="text-sm text-gray-500">Send notification to all users</p>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div>
                  <Label htmlFor="broadcast-target" className="text-sm font-medium">Send To</Label>
                  <div className="flex gap-2 mt-2">
                    {[
                      { value: "all", label: "All Users" },
                      { value: "customers", label: "Space Providers" },
                      { value: "workers", label: "Space Seekers" }
                    ].map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setBroadcastTarget(option.value as "all" | "customers" | "workers")}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                          broadcastTarget === option.value
                            ? "bg-[#4f0073] text-white"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                        data-testid={`button-target-${option.value}`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="broadcast-title" className="text-sm font-medium">Title</Label>
                  <Input
                    id="broadcast-title"
                    type="text"
                    value={broadcastTitle}
                    onChange={(e) => setBroadcastTitle(e.target.value)}
                    placeholder="Enter notification title"
                    className="mt-2"
                    data-testid="input-broadcast-title"
                  />
                </div>

                <div>
                  <Label htmlFor="broadcast-message" className="text-sm font-medium">Message</Label>
                  <textarea
                    id="broadcast-message"
                    value={broadcastMessage}
                    onChange={(e) => setBroadcastMessage(e.target.value)}
                    placeholder="Enter notification message"
                    className="mt-2 w-full p-3 border border-gray-200 rounded-lg text-sm resize-none focus:outline-none focus:ring-2 focus:ring-purple-500"
                    rows={3}
                    data-testid="input-broadcast-message"
                  />
                </div>
              </div>

              <Button
                onClick={handleBroadcastNotification}
                disabled={isBroadcasting || !broadcastTitle.trim() || !broadcastMessage.trim()}
                className="bg-[#4f0073] hover:bg-[#3d005a]"
                data-testid="button-send-broadcast"
              >
                {isBroadcasting ? (
                  <Loader2 className="animate-spin mr-2" size={16} />
                ) : (
                  <Send className="mr-2" size={16} />
                )}
                Send Broadcast
              </Button>
            </div>

            <div className="md:hidden">
              <p className="text-xs text-gray-500 text-center mb-4">Quick Navigation</p>
              <div className="grid grid-cols-4 gap-2">
                {navItems.slice(0, 8).map((item) => (
                  <button
                    key={item.path}
                    onClick={() => setLocation(item.path)}
                    className={`p-3 rounded-lg text-center ${
                      item.path === "/admin/settings"
                        ? "bg-[#4f0073] text-white"
                        : "bg-white border hover:bg-gray-50"
                    }`}
                  >
                    <item.icon size={20} className="mx-auto mb-1" />
                    <span className="text-xs">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      <ConfirmDialog
        isOpen={showLogoutConfirm}
        onCancel={() => setShowLogoutConfirm(false)}
        title="Logout"
        message="Are you sure you want to logout from the admin panel?"
        confirmText="Logout"
        onConfirm={handleLogout}
        variant="info"
      />

      <ConfirmDialog
        isOpen={showComingSoonConfirm}
        onCancel={() => setShowComingSoonConfirm(false)}
        title={pendingComingSoonValue ? "Enable Coming Soon Mode" : "Disable Coming Soon Mode"}
        message={pendingComingSoonValue 
          ? "This will show a 'Launching Soon' message to all app users. They won't be able to use the app until you disable this mode. Are you sure?"
          : "This will allow all users to access the app normally. Are you sure you want to disable Coming Soon mode?"}
        confirmText={pendingComingSoonValue ? "Enable" : "Disable"}
        onConfirm={handleConfirmComingSoon}
        variant={pendingComingSoonValue ? "warning" : "info"}
      />
    </div>
  );
}

