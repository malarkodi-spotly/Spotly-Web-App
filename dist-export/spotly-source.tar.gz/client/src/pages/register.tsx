import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Loader2, X } from "lucide-react";
import { getApiUrl } from "@/lib/api-config";
import { vibrate } from "@/lib/vibrate";
import spotlyLogoWhite from "@assets/spotly_logo_transparent.png";

export default function RegisterPage() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [name, setName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [userRole, setUserRole] = useState<"customer" | "worker">("customer");
  const nameInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const role = params.get("role") as "customer" | "worker";
    if (role === "customer" || role === "worker") {
      setUserRole(role);
    } else {
      const storedRole = localStorage.getItem("userRole") as "customer" | "worker";
      if (storedRole) setUserRole(storedRole);
    }
    setTimeout(() => nameInputRef.current?.focus(), 400);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    vibrate();
    setIsLoading(true);
    setErrorMessage("");

    const userId = localStorage.getItem("userId");
    if (!userId) {
      setErrorMessage("Session expired. Please login again.");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch(getApiUrl(`/api/users/${userId}`), {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim() }),
      });

      if (response.ok) {
        localStorage.setItem("userName", name.trim());

        if (userRole === "worker") {
          try {
            await fetch(getApiUrl("/api/workers/profile"), {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                userId,
                services: [],
              }),
            });
          } catch (err) {
            console.error("Failed to create worker profile:", err);
          }
        }

        setLocation("/disclaimer");
      } else {
        const data = await response.json();
        setErrorMessage(data.error || "Failed to save. Please try again.");
      }
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
      setErrorMessage("Network error. Please try again.");
    }
  };

  const heroImage = userRole === "customer" ? "/images/provider-hero.png" : "/images/seeker-hero.png";
  const heroTagline = userRole === "customer" ? "list your space,\nearn monthly" : "find parking\nnear you";

  return (
    <div className="w-full max-w-[430px] mx-auto min-h-[100dvh] relative overflow-hidden">
      <div className="fixed inset-0 w-full h-full">
        <div className="absolute inset-0 bg-[#4f0073]" />
        <img src={heroImage} alt="" className="absolute inset-0 w-full h-full object-cover object-center" style={{ objectPosition: "center 20%" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(79,0,115,0.55) 0%, rgba(79,0,115,0.15) 30%, rgba(79,0,115,0.15) 50%, rgba(79,0,115,0.7) 100%)" }} />
      </div>

      <div className="relative z-10 min-h-[100dvh] flex flex-col">
        <div className="p-5 pb-2 text-left">
          <div className="mb-1">
            <img src={spotlyLogoWhite} alt="Spotly" className="h-10 object-contain drop-shadow-lg" />
          </div>
          <h1 className="text-white text-[1.75rem] font-extrabold leading-[1.15] mt-2 whitespace-pre-line drop-shadow-lg">{heroTagline}</h1>
        </div>

        <div className="flex-1 flex items-center justify-center px-4">
          <div className="w-full max-w-[360px] rounded-3xl shadow-2xl shadow-black/20 px-5 pt-5 pb-[36px] border border-white/30" style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)" }}>
            <form onSubmit={handleSubmit}>
              <h2 className="text-lg font-extrabold text-white mb-4" data-testid="text-register-title">What's your name?</h2>
              <div className="mb-4">
                <p className="text-sm font-semibold text-white/80 mb-2">Enter your name <span className="text-red-300">*</span></p>
                <div className="flex items-center border-2 border-white/30 rounded-xl overflow-hidden focus-within:border-white/60 transition-colors h-[50px]" style={{ background: "rgba(255,255,255,0.12)" }}>
                  <input ref={nameInputRef} id="name" type="text" placeholder="Enter your full name" className="flex-1 px-4 text-base font-medium text-white outline-none bg-transparent placeholder:text-white/40" value={name} onChange={(e) => setName(e.target.value.replace(/[0-9]/g, '').slice(0, 14))} onFocus={(e) => setTimeout(() => e.target.scrollIntoView({ behavior: "smooth", block: "center" }), 300)} maxLength={14} data-testid="input-name" required minLength={2} />
                  {name && (<button type="button" onClick={() => setName("")} className="pr-3 text-white/50 hover:text-white/80"><X size={18} /></button>)}
                </div>
              </div>
              {errorMessage && (<div className="bg-red-50 border border-red-200 rounded-xl p-3 mb-4"><p className="text-red-600 text-sm text-center" data-testid="error-register">{errorMessage}</p></div>)}
              <button type="submit" disabled={isLoading || name.trim().length < 2} className="w-full h-[50px] flex items-center justify-center text-base font-extrabold rounded-xl text-[#4f0073] shadow-xl shadow-black/15 transition-all active:scale-[0.98] disabled:opacity-40 disabled:shadow-none mb-3 bg-white" data-testid="button-register-submit">{isLoading ? <Loader2 className="animate-spin" size={22} /> : "Continue"}</button>
              <p className="text-[11px] text-white/50 text-center leading-relaxed px-2">By continuing, you agree to Spotly's Terms of service & Privacy policy</p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}