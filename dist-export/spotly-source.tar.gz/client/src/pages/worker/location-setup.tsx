import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import { Button } from "@/components/ui/button";
import { MapPin, Loader2, Navigation, AlertTriangle, CheckCircle, Shield, RotateCcw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getApiUrl } from "@/lib/api-config";
import { motion, AnimatePresence } from "framer-motion";
import spotlyIcon from "@assets/file_00000000a1c8720881e8312ea1ae4e07_1775941652727.png";

interface City {
  id: string;
  name: string;
  latitude?: number;
  longitude?: number;
}

export default function WorkerLocationSetup() {
  const [, setLocation] = useLocation();
  const [status, setStatus] = useState<"detecting" | "error">("detecting");
  const [detectedLocationName, setDetectedLocationName] = useState("");
  const [pulsePhase, setPulsePhase] = useState(0);

  const { data: citiesData } = useQuery({
    queryKey: ["cities"],
    queryFn: async () => {
      const res = await fetch(getApiUrl("/api/cities"));
      if (!res.ok) throw new Error("Failed to fetch cities");
      return res.json();
    },
  });

  const cities: City[] = citiesData?.cities || [];

  useEffect(() => {
    detectLocation();
  }, []);

  useEffect(() => {
    if (status === "detecting") {
      const interval = setInterval(() => {
        setPulsePhase(p => (p + 1) % 3);
      }, 600);
      return () => clearInterval(interval);
    }
  }, [status]);

  const updateWorkerProfile = async (cityName: string, latitude?: number, longitude?: number, address?: string) => {
    const userId = localStorage.getItem("userId");
    const sessionToken = localStorage.getItem("sessionToken");
    if (!userId) return;

    const profileData: Record<string, unknown> = {
      userId,
      city: cityName,
    };

    if (latitude !== undefined && longitude !== undefined) {
      profileData.latitude = latitude;
      profileData.longitude = longitude;
    }

    if (address) {
      profileData.location = address.split(",").slice(0, 3).join(", ");
    }

    try {
      await fetch(getApiUrl("/api/workers/profile"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profileData),
      });
    } catch (e) {
      console.error("Failed to update worker profile:", e);
    }

    if (sessionToken) {
      try {
        await fetch(getApiUrl("/api/users/me"), {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${sessionToken}`
          },
          body: JSON.stringify({ city: cityName }),
        });
      } catch (e) {
        console.error("Failed to update user city:", e);
      }
    }
  };

  const detectLocation = async () => {
    setStatus("detecting");
    if (!navigator.geolocation) {
      setStatus("error");
      setDetectedLocationName("Location not supported by your browser");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;

        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1&accept-language=en`
          );
          const data = await response.json();
          const cityName = data.address?.city || data.address?.town || data.address?.village || data.address?.county || data.address?.state_district || "";
          const stateName = data.address?.state || "";
          const displayLocation = cityName ? `${cityName}${stateName ? `, ${stateName}` : ""}` : stateName || "Unknown location";

          setDetectedLocationName(displayLocation);

          const actualCityName = cityName || stateName || "Unknown location";

          localStorage.setItem("userLatitude", latitude.toString());
          localStorage.setItem("userLongitude", longitude.toString());
          localStorage.setItem("userDetectedCity", actualCityName);
          localStorage.setItem("userDetectedAddress", data.display_name || "");
          localStorage.setItem("userState", stateName);
          localStorage.setItem("selectedServiceAreaName", actualCityName);
          localStorage.setItem("workerLocationCompleted", "true");
          localStorage.setItem("workerState", stateName);
          await updateWorkerProfile(actualCityName, latitude, longitude, data.display_name);
          setLocation("/worker/home");
        } catch (error) {
          console.error("Reverse geocoding error:", error);
          setStatus("error");
          setDetectedLocationName("Unable to detect location");
        }
      },
      (error) => {
        console.error("Geolocation error:", error);
        setStatus("error");
        if (error.code === error.PERMISSION_DENIED) {
          setDetectedLocationName("Location access denied");
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          setDetectedLocationName("Location unavailable");
        } else if (error.code === error.TIMEOUT) {
          setDetectedLocationName("Location request timed out");
        } else {
          setDetectedLocationName("Unable to get location");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 30000,
        maximumAge: 0
      }
    );
  };

  const detectingDots = ["Searching", "Verifying", "Almost there"];

  return (
    <MobileLayout>
      <div className="h-full flex flex-col relative overflow-hidden" style={{ background: "linear-gradient(135deg, #4f0073 0%, #7b1fa2 40%, #9c27b0 70%, #6a1b9a 100%)" }}>
        <div className="relative z-10 flex-1 flex flex-col">
          <AnimatePresence mode="wait">
            {status === "detecting" && (
              <motion.div
                key="detecting"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center px-8"
              >
                <div className="relative mb-10" style={{ width: 200, height: 200 }}>
                  {[0, 1, 2, 3].map(i => (
                    <motion.div
                      key={`ripple-${i}`}
                      className="absolute rounded-full border-2 border-white/30"
                      style={{
                        top: "50%",
                        left: "50%",
                        translateX: "-50%",
                        translateY: "-50%",
                      }}
                      animate={{
                        width: [60, 200],
                        height: [60, 200],
                        opacity: [0.6, 0],
                      }}
                      transition={{
                        duration: 2.4,
                        repeat: Infinity,
                        ease: "easeOut",
                        delay: i * 0.6,
                      }}
                    />
                  ))}

                  <div
                    className="absolute rounded-full bg-white/10"
                    style={{
                      width: 120,
                      height: 120,
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  />
                  <div
                    className="absolute rounded-full bg-white/15"
                    style={{
                      width: 90,
                      height: 90,
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  />

                  <motion.div
                    className="absolute"
                    style={{
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                    animate={{ y: [0, -6, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <img src={spotlyIcon} alt="Spotly" className="w-20 h-20 object-contain drop-shadow-2xl" />
                  </motion.div>
                </div>

                <motion.h1
                  className="text-2xl font-bold text-white mb-2 text-center"
                  initial={{ y: 20 }}
                  animate={{ y: 0 }}
                >
                  Finding Your Location
                </motion.h1>
                <p className="text-white/70 text-sm mb-10 text-center">
                  Please allow location access when prompted
                </p>

                <div className="flex items-center gap-3 bg-white/15 backdrop-blur-sm rounded-2xl px-6 py-4">
                  <Loader2 className="w-5 h-5 text-white animate-spin flex-shrink-0" />
                  <span className="text-white/90 text-sm font-medium">
                    {detectingDots[pulsePhase]}...
                  </span>
                </div>

                <div className="flex gap-2 mt-8">
                  {[0, 1, 2].map(i => (
                    <motion.div
                      key={i}
                      className="w-2.5 h-2.5 rounded-full"
                      animate={{
                        backgroundColor: pulsePhase === i ? "#ffffff" : "rgba(255,255,255,0.3)",
                        scale: pulsePhase === i ? 1.4 : 1
                      }}
                      transition={{ duration: 0.3 }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {status === "state_invalid" && (
              <motion.div
                key="invalid"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col px-6 pt-8 pb-6"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-amber-400/20 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-amber-300" />
                  </div>
                  <div>
                    <h1 className="text-lg font-bold text-white">Area Not Covered</h1>
                    <p className="text-white/60 text-xs">Select an available service area</p>
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-4 mb-5">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-amber-300 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-white/50 text-[11px] uppercase tracking-wider mb-0.5">Detected Location</p>
                      <p className="text-white font-medium text-sm truncate">{detectedLocationName}</p>
                      {detectedState && (
                        <p className="text-amber-300/80 text-xs mt-0.5">{detectedState}</p>
                      )}
                    </div>
                  </div>
                </div>

                <p className="text-white/70 text-xs font-medium uppercase tracking-wider mb-3 px-1">
                  Available Service Areas
                </p>

                <div className="flex-1 overflow-y-auto space-y-2 mb-5">
                  {availableServiceAreas.map((area, index) => (
                    <motion.button
                      key={area.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      data-testid={`service-area-${area.stateName}`}
                      onClick={() => handleSelectServiceArea(area)}
                      className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all duration-200 ${
                        selectedServiceArea?.id === area.id
                          ? "bg-white/25 border-2 border-white/50 shadow-lg"
                          : "bg-white/10 border border-white/15 hover:bg-white/15"
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        selectedServiceArea?.id === area.id ? "bg-white/30" : "bg-white/10"
                      }`}>
                        <MapPin className={`w-5 h-5 ${selectedServiceArea?.id === area.id ? "text-white" : "text-white/60"}`} />
                      </div>
                      <div className="flex-1 text-left">
                        <p className={`font-semibold text-sm ${selectedServiceArea?.id === area.id ? "text-white" : "text-white/80"}`}>
                          {area.displayName}
                        </p>
                        <p className={`text-xs ${selectedServiceArea?.id === area.id ? "text-white/70" : "text-white/50"}`}>
                          {area.stateName}
                        </p>
                      </div>
                      {selectedServiceArea?.id === area.id && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        >
                          <CheckCircle className="w-6 h-6 text-white" />
                        </motion.div>
                      )}
                    </motion.button>
                  ))}
                </div>

                <Button
                  onClick={handleProceedWithSelectedArea}
                  disabled={!selectedServiceArea}
                  data-testid="button-proceed-service-area"
                  className="w-full bg-white text-[#4f0073] hover:bg-white/90 font-semibold py-6 rounded-2xl disabled:opacity-30 disabled:cursor-not-allowed shadow-lg"
                >
                  <Navigation className="w-5 h-5 mr-2" />
                  {selectedServiceArea ? `Continue with ${selectedServiceArea.displayName}` : "Select an Area"}
                </Button>

                <div className="flex items-center justify-center gap-2 mt-4">
                  <Shield className="w-3 h-3 text-white/40" />
                  <p className="text-white/40 text-[11px]">
                    Parking spaces will be shown for your selected area
                  </p>
                </div>
              </motion.div>
            )}

            {status === "error" && (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center px-8"
              >
                <div className="relative mb-6">
                  <div className="w-24 h-24 rounded-full bg-white/10 border border-white/20 flex items-center justify-center">
                    <MapPin className="w-11 h-11 text-red-300" />
                  </div>
                </div>

                <h1 className="text-xl font-bold text-white mb-2 text-center">
                  Location Error
                </h1>
                <p className="text-white/70 text-sm mb-2 text-center leading-relaxed">
                  {detectedLocationName}
                </p>
                <p className="text-white/50 text-xs mb-8 text-center max-w-[240px]">
                  Please enable location access in your browser settings and try again
                </p>

                <Button
                  onClick={detectLocation}
                  className="w-full max-w-[280px] bg-white text-[#4f0073] hover:bg-white/90 font-semibold py-6 rounded-2xl shadow-lg"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Try Again
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="relative z-10 px-6 pb-6 pt-2">
            <div className="flex items-center justify-center gap-1.5">
              <div className="w-1 h-1 rounded-full bg-white/30" />
              <p className="text-white/40 text-[10px] tracking-wide">
                SPOTLY PARKING
              </p>
              <div className="w-1 h-1 rounded-full bg-white/30" />
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
