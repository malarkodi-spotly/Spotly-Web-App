import { useLocation } from "wouter";
import MobileLayout from "@/components/layout/mobile-layout";
import { Lock, LogIn, Sparkles, Eye, ThumbsUp, MapPin } from "lucide-react";
import { motion } from "framer-motion";
import { exitGuestMode } from "@/lib/guest";
import { vibrate } from "@/lib/vibrate";

export default function GuestAccountView({ role }: { role: "customer" | "worker" }) {
  const [, setLocation] = useLocation();

  const handleLogin = () => {
    vibrate();
    exitGuestMode();
    setLocation(`/auth?role=${role}`);
  };

  const benefits = role === "customer"
    ? [
        { icon: MapPin, text: "Post your parking spaces" },
        { icon: ThumbsUp, text: "Get interested seekers" },
        { icon: Sparkles, text: "Earn monthly rent" },
      ]
    : [
        { icon: Eye, text: "View contact details" },
        { icon: ThumbsUp, text: "Show interest in spaces" },
        { icon: Sparkles, text: "Unlock Premium features" },
      ];

  return (
    <MobileLayout showNav userType={role}>
      <div className="min-h-[calc(100dvh-120px)] flex flex-col">
        <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-4 pt-3 pb-10 relative overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute top-1 right-3 w-16 h-16 rounded-full bg-white/10 blur-sm" />
            <div className="absolute -bottom-2 -left-2 w-18 h-18 rounded-full bg-pink-400/15 blur-md" />
          </div>
          <h2 className="text-xl font-bold text-white relative z-10 drop-shadow-md">My Profile</h2>
          <p className="text-white/70 text-sm relative z-10 mt-1">
            {role === "customer" ? "Space Provider" : "Space Seeker"}
          </p>
        </div>

        <div className="px-5 -mt-6 relative z-10 flex-1 flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="w-full max-w-[360px] bg-white rounded-3xl p-6 border border-purple-100"
            style={{ boxShadow: "0 8px 28px rgba(79,0,115,0.12)" }}
          >
            <div className="flex flex-col items-center text-center mb-5">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4f0073] to-[#9333ea] flex items-center justify-center mb-3 shadow-lg shadow-purple-300/40">
                <Lock size={28} className="text-white" />
              </div>
              <h3 className="text-[17px] font-extrabold text-neutral-900 mb-1.5">You're browsing as Guest</h3>
              <p className="text-[12.5px] text-neutral-500 leading-relaxed max-w-[260px]">
                Log in to manage your profile and unlock all features of Spotly.
              </p>
            </div>

            <div className="space-y-2.5 mb-5">
              {benefits.map((b, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 + i * 0.06 }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-purple-50 border border-purple-100"
                >
                  <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm">
                    <b.icon size={15} className="text-[#4f0073]" />
                  </div>
                  <span className="text-[12.5px] font-semibold text-neutral-700">{b.text}</span>
                </motion.div>
              ))}
            </div>

            <button
              onClick={handleLogin}
              className="w-full h-12 rounded-2xl bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-extrabold text-[15px] shadow-lg shadow-[#4f0073]/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
              data-testid="button-guest-login"
            >
              <LogIn size={17} />
              Login / Sign Up
            </button>
          </motion.div>
        </div>
      </div>
    </MobileLayout>
  );
}
