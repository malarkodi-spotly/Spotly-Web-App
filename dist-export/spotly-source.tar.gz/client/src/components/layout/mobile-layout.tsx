import React, { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { Bell, Trash2 } from "lucide-react";
import BottomNav from "./bottom-nav";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { getApiUrl } from "@/lib/api-config";
import { useScroll } from "@/contexts/scroll-context";

interface Notification {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  bookingId: string | null;
  isRead: boolean;
  createdAt: string;
}

interface MobileLayoutProps {
  children: React.ReactNode;
  showNav?: boolean;
  userType?: "customer" | "worker";
}

export default function MobileLayout({ children, showNav = false, userType }: MobileLayoutProps) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const userId = localStorage.getItem("userId");

  const fetchNotifications = async () => {
    if (!userId) return;
    setIsLoading(true);
    try {
      const res = await fetch(getApiUrl(`/api/notifications/${userId}`));
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch (error) {
      console.error("Failed to fetch notifications:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (notificationsOpen && userId) {
      fetchNotifications();
      // Mark all as read when opening
      fetch(getApiUrl(`/api/notifications/${userId}/read-all`), { method: "POST" }).catch(() => {});
    }
  }, [notificationsOpen, userId]);

  const handleClearAll = async () => {
    if (!userId) return;
    try {
      const res = await fetch(getApiUrl(`/api/notifications/${userId}/clear`), {
        method: "DELETE",
      });
      if (res.ok) {
        setNotifications([]);
      }
    } catch (error) {
      console.error("Failed to clear notifications:", error);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "new_job": return "💼";
      case "job_accepted": return "✓";
      case "job_rejected": return "❌";
      case "rating_received": return "⭐";
      default: return "🔔";
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;
  
  const { setScrollY } = useScroll();
  
  const handleScroll = useCallback((e: React.UIEvent<HTMLElement>) => {
    const target = e.target as HTMLElement;
    setScrollY(target.scrollTop);
  }, [setScrollY]);

  return (
    <div className="min-h-screen bg-neutral-100 flex items-center justify-center p-0 md:p-4 font-sans">
      <div className="mobile-container w-full h-screen md:h-[800px] md:max-w-[430px] md:rounded-[3rem] bg-background md:border-8 md:border-neutral-800 overflow-hidden flex flex-col relative shadow-2xl safe-area-top">
        <main id="mobile-scroll-container" className="flex-1 overflow-y-auto hide-scrollbar relative" onScroll={handleScroll}>
          {children}
        </main>

        {showNav && userType && <BottomNav userType={userType} />}
        {!showNav && <div className="safe-area-bottom" />}

        {/* Notifications Sheet */}
        <Sheet open={notificationsOpen} onOpenChange={setNotificationsOpen}>
          <SheetContent side="right" className="w-full sm:w-96 p-0">
            <SheetHeader className="border-b p-4 sticky top-0 bg-white">
              <div className="flex items-center justify-between">
                <SheetTitle className="text-lg font-bold">Notifications</SheetTitle>
                {notifications.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClearAll}
                    className="text-red-500 hover:text-red-600 hover:bg-red-50 text-xs gap-1"
                    data-testid="button-clear-notifications"
                  >
                    <Trash2 size={14} />
                    Clear All
                  </Button>
                )}
              </div>
            </SheetHeader>
            
            <div className="overflow-y-auto h-[calc(100vh-100px)]">
              {isLoading ? (
                <div className="p-8 text-center text-neutral-500">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                  <p className="text-sm">Loading...</p>
                </div>
              ) : notifications.length === 0 ? (
                <div className="p-8 text-center text-neutral-500">
                  <Bell className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No notifications yet</p>
                </div>
              ) : (
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 cursor-pointer transition-colors hover:bg-neutral-50 ${
                        !notification.isRead ? "bg-blue-50" : ""
                      }`}
                      data-testid={`notification-${notification.id}`}
                    >
                      <div className="flex gap-3 items-start">
                        <div className="text-xl mt-1">{getNotificationIcon(notification.type)}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-sm text-neutral-900">
                              {notification.title}
                            </h3>
                            {!notification.isRead && (
                              <span className="w-2 h-2 bg-primary rounded-full"></span>
                            )}
                          </div>
                          <p className="text-xs text-neutral-600 mt-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-xs text-neutral-400 mt-2">
                            {formatTime(notification.createdAt)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
}
