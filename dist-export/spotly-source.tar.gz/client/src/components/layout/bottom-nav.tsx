import { useLocation } from "wouter";
import { Home, PlusCircle, User, Car } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { isGuest } from "@/lib/guest";
import { useAuthGuard } from "@/contexts/auth-guard";

interface BottomNavProps {
  userType: "customer" | "worker";
}

const GUEST_PROTECTED_PATHS = new Set([
  "/customer/contacts",
  "/customer/bookings",
  "/worker/account",
]);

export default function BottomNav({ userType }: BottomNavProps) {
  const [location, setLocation] = useLocation();
  const { requireLogin } = useAuthGuard();

  const customerLinks = [
    { href: "/customer/home", icon: Home, label: "Home" },
    { href: "/customer/bookings", icon: PlusCircle, label: "Post Space" },
    { href: "/customer/contacts", icon: User, label: "Profile" },
  ];

  const workerLinks = [
    { href: "/worker/home", icon: Car, label: "Spaces" },
    { href: "/worker/account", icon: User, label: "Account" },
  ];

  const links = userType === "customer" ? customerLinks : workerLinks;

  return (
    <div className="shrink-0 z-40 safe-area-bottom relative">
      <div className="bg-white/80 backdrop-blur-xl border-t border-neutral-200/60 shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
        <div className="h-[68px] flex items-center justify-around px-3">
          {links.map((link) => {
            const isActive = location === link.href;
            return (
              <button
                key={link.href}
                onClick={() => {
                  if (isGuest() && GUEST_PROTECTED_PATHS.has(link.href)) {
                    requireLogin(link.label.toLowerCase());
                    return;
                  }
                  setLocation(link.href);
                }}
                className="flex flex-col items-center justify-center flex-1 h-full relative"
                data-testid={`nav-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div className="relative">
                  {isActive && (
                    <motion.div
                      layoutId="bottomNavActive"
                      className="absolute -inset-2 bg-gradient-to-br from-[#4f0073]/15 to-[#9333ea]/10 rounded-2xl"
                      transition={{ type: "spring", stiffness: 350, damping: 30 }}
                    />
                  )}
                  <motion.div
                    animate={isActive ? { y: -2 } : { y: 0 }}
                    transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    className="relative z-10 p-1.5"
                  >
                    <link.icon
                      className={cn(
                        "w-[22px] h-[22px] transition-colors duration-200",
                        isActive ? "text-[#4f0073]" : "text-neutral-400"
                      )}
                      strokeWidth={isActive ? 2.5 : 1.8}
                      fill={isActive ? "rgba(79,0,115,0.15)" : "none"}
                    />
                  </motion.div>
                </div>
                <motion.span
                  animate={isActive ? { y: -1, opacity: 1 } : { y: 0, opacity: 0.6 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  className={cn(
                    "text-[10px] mt-0.5 transition-colors duration-200",
                    isActive
                      ? "font-bold text-[#4f0073]"
                      : "font-medium text-neutral-400"
                  )}
                >
                  {link.label}
                </motion.span>
                {isActive && (
                  <motion.div
                    layoutId="bottomNavDot"
                    className="absolute bottom-1.5 w-1 h-1 rounded-full bg-[#4f0073]"
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
