export function isGuest(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem("isGuest") === "true";
}

export function enterGuestMode(role: "customer" | "worker") {
  localStorage.setItem("isGuest", "true");
  localStorage.setItem("userRole", role);
  localStorage.setItem("disclaimerAccepted", "true");
  localStorage.removeItem("userId");
  localStorage.removeItem("sessionToken");
}

export function exitGuestMode() {
  localStorage.removeItem("isGuest");
}
