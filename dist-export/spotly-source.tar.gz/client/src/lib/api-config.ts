// =============================================================================
// API CONFIGURATION FOR MOBILE APK BUILD
// =============================================================================
// 
// When building this app as a mobile APK (using Capacitor, Cordova, etc.):
// 
// 1. First, publish your app on Replit to get a production URL
//    (e.g., https://your-app-name.replit.app)
// 
// 2. Set the PRODUCTION_API_URL below to your published Replit URL
// 
// 3. Build the APK - the app will connect to your Replit server
// 
// =============================================================================

// SET YOUR PUBLISHED REPLIT URL HERE (e.g., "https://spotly.replit.app")
const PRODUCTION_API_URL = "";

// Detect if running inside Replit or as a standalone app
const isRunningOnReplit = typeof window !== 'undefined' && 
  (window.location.hostname.includes('replit') || 
   window.location.hostname.includes('localhost') ||
   window.location.hostname === '0.0.0.0');

// Use environment variable if set, otherwise use production URL for mobile builds
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 
  (isRunningOnReplit ? '' : PRODUCTION_API_URL);

export function getApiUrl(path: string): string {
  if (path.startsWith('/')) {
    return `${API_BASE_URL}${path}`;
  }
  return `${API_BASE_URL}/${path}`;
}

export async function adminFetch(path: string, options: RequestInit = {}): Promise<Response> {
  const token = localStorage.getItem("adminToken");
  const headers = new Headers(options.headers || {});
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  if (!headers.has("Content-Type") && options.body) {
    headers.set("Content-Type", "application/json");
  }
  const res = await fetch(getApiUrl(path), { ...options, headers });
  if (res.status === 401 && path.startsWith("/api/admin")) {
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminLevel");
    window.location.href = "/admin";
  }
  return res;
}
