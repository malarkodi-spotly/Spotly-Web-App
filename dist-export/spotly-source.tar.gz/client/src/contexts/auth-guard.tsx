import { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, X } from "lucide-react";
import { isGuest, exitGuestMode } from "@/lib/guest";
import { vibrate } from "@/lib/vibrate";

type AuthGuardContextType = {
  requireLogin: (actionLabel?: string) => boolean;
};

const AuthGuardContext = createContext<AuthGuardContextType | null>(null);

export function AuthGuardProvider({ children }: { children: ReactNode }) {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [actionLabel, setActionLabel] = useState<string>("");

  const requireLogin = useCallback((label?: string) => {
    if (isGuest() || !localStorage.getItem("userId")) {
      setActionLabel(label || "");
      setOpen(true);
      return false;
    }
    return true;
  }, []);

  const handleLogin = () => {
    vibrate();
    const role = localStorage.getItem("userRole") || "customer";
    exitGuestMode();
    setOpen(false);
    setLocation(`/auth?role=${role}`);
  };

  return (
    <AuthGuardContext.Provider value={{ requireLogin }}>
      {children}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[300] flex items-center justify-center px-6"
            style={{ backgroundColor: "rgba(0,0,0,0.55)", backdropFilter: "blur(4px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            data-testid="dialog-login-required"
          >
            <motion.div
              className="w-full max-w-[340px] rounded-3xl overflow-hidden shadow-2xl bg-white relative"
              initial={{ scale: 0.85, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", stiffness: 320, damping: 26 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setOpen(false)}
                className="absolute top-3 right-3 w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-500 z-10"
                data-testid="button-close-login-required"
                aria-label="Close"
              >
                <X size={16} />
              </button>
              <div className="bg-gradient-to-br from-[#4f0073] via-[#6b21a8] to-[#9333ea] px-6 pt-7 pb-5 text-center">
                <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shadow-lg">
                  <Lock size={28} className="text-white" />
                </div>
                <h3 className="text-white text-lg font-extrabold mb-1">Login Required</h3>
                <p className="text-white/85 text-[12.5px] leading-relaxed">
                  {actionLabel
                    ? `Please log in to ${actionLabel}.`
                    : "Please log in to continue using this feature."}
                </p>
              </div>
              <div className="px-5 pt-4 pb-5">
                <p className="text-[12.5px] text-neutral-600 text-center leading-relaxed mb-4">
                  You're browsing as a guest. Create an account or log in to unlock all features.
                </p>
                <button
                  onClick={handleLogin}
                  className="w-full h-12 rounded-2xl bg-gradient-to-r from-[#4f0073] to-[#7b1fa2] text-white font-extrabold text-[15px] shadow-lg shadow-[#4f0073]/25 active:scale-[0.98] transition-transform"
                  data-testid="button-login-now"
                >
                  Login Now
                </button>
                <button
                  onClick={() => setOpen(false)}
                  className="w-full h-11 mt-2 rounded-2xl bg-neutral-100 text-neutral-600 font-semibold text-[13.5px] active:scale-[0.98] transition-transform"
                  data-testid="button-continue-browsing"
                >
                  Continue Browsing
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AuthGuardContext.Provider>
  );
}

export function useAuthGuard() {
  const ctx = useContext(AuthGuardContext);
  if (!ctx) throw new Error("useAuthGuard must be used within AuthGuardProvider");
  return ctx;
}
