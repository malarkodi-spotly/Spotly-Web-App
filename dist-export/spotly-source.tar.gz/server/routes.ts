import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, otpVerificationSchema, updateUserSchema, insertWorkerProfileSchema, insertCitySchema, insertBookingSchema, insertServiceSchema } from "@shared/schema";
import { z } from "zod";
import path from "path";
import fs from "fs";

// InstantAlerts SMS Configuration
const INSTANTALERTS_CONFIG = {
  apiKey: process.env.INSTANTALERTS_API_KEY || "",
  senderId: "INSTNE",
  route: "2", // Transactional
  templateId: "1407175635875846099",
  baseUrl: "https://instantalerts.in/api/smsapi"
};

// Send SMS via InstantAlerts API
async function sendSMS(mobile: string, otp: string): Promise<boolean> {
  try {
    // Format mobile number (remove +91 if present, ensure 10 digits)
    const cleanMobile = mobile.replace(/^\+91/, "").replace(/\D/g, "").slice(-10);
    
    // DLT registered message template - must match exactly the approved template
    const message = `Your OTP for CookandCare is ${otp}. Please do not share`;
    
    const url = new URL(INSTANTALERTS_CONFIG.baseUrl);
    url.searchParams.append("key", INSTANTALERTS_CONFIG.apiKey);
    url.searchParams.append("route", INSTANTALERTS_CONFIG.route);
    url.searchParams.append("sender", INSTANTALERTS_CONFIG.senderId);
    url.searchParams.append("number", cleanMobile);
    url.searchParams.append("templateid", INSTANTALERTS_CONFIG.templateId);
    url.searchParams.append("sms", message);
    
    console.log(`Sending OTP SMS to ${cleanMobile}...`);
    
    const response = await fetch(url.toString());
    const responseText = await response.text();
    
    console.log(`SMS API Response: ${responseText}`);
    
    // Check if SMS was sent successfully
    if (response.ok && !responseText.toLowerCase().includes("error")) {
      console.log(`OTP SMS sent successfully to ${cleanMobile}`);
      return true;
    } else {
      console.error(`SMS API Error: ${responseText}`);
      return false;
    }
  } catch (error) {
    console.error("Failed to send SMS:", error);
    return false;
  }
}

// Haversine formula to calculate distance between two points
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in km
}

// Simple in-memory OTP storage (in production, use Redis)
const otpStorage = new Map<string, { otp: string; expiresAt: number; lastSentAt: number }>();

// Minimum time between OTP sends (30 seconds)
const OTP_COOLDOWN_MS = 30000;

// Admin session storage (in production, use Redis or database)
const adminSessions = new Map<string, { level: 'super' | 'sub'; expiresAt: number }>();

// User session storage (in production, use Redis or database)
const userSessions = new Map<string, { userId: string; expiresAt: number }>();

const SUPER_ADMIN_PASSWORD = process.env.SUPER_ADMIN_PASSWORD || "supadmin@123#";
const SUB_ADMIN_PASSWORD = process.env.SUB_ADMIN_PASSWORD || "admin@123#";

function generateOTP(): string {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

function generateSessionToken(): string {
  return `admin_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

function generateUserSessionToken(): string {
  return `user_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

function validateAdminSession(token: string | undefined): { valid: boolean; level?: 'super' | 'sub' } {
  if (!token) return { valid: false };
  const session = adminSessions.get(token);
  if (!session) return { valid: false };
  if (Date.now() > session.expiresAt) {
    adminSessions.delete(token);
    return { valid: false };
  }
  return { valid: true, level: session.level };
}

function validateUserSession(token: string | undefined): { valid: boolean; userId?: string } {
  if (!token) return { valid: false };
  const session = userSessions.get(token);
  if (!session) return { valid: false };
  if (Date.now() > session.expiresAt) {
    userSessions.delete(token);
    return { valid: false };
  }
  return { valid: true, userId: session.userId };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.use("/api/admin", (req, res, next) => {
    if (req.path === "/login" || req.path === "/session") {
      return next();
    }
    const token = req.headers.authorization?.replace("Bearer ", "");
    const session = validateAdminSession(token);
    if (!session.valid) {
      return res.status(401).json({ error: "Admin authentication required" });
    }
    (req as any).adminLevel = session.level;
    next();
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);

      let user = await storage.getUserByMobile(data.mobile, data.role);
      let isNewUser = false;

      if (!user) {
        user = await storage.createUser({
          name: "User",
          email: null,
          mobile: data.mobile,
          role: data.role,
        });
        isNewUser = true;
      }

      const existingOtp = otpStorage.get(data.mobile);
      const now = Date.now();
      
      if (existingOtp && existingOtp.lastSentAt && (now - existingOtp.lastSentAt) < OTP_COOLDOWN_MS) {
        console.log(`OTP for ${data.mobile}: Using existing OTP (cooldown active)`);
        return res.json({
          success: true,
          message: "OTP already sent",
          userId: user.id,
          mobile: user.mobile,
          isNewUser,
        });
      }

      const otp = generateOTP();
      otpStorage.set(data.mobile, {
        otp,
        expiresAt: now + 10 * 60 * 1000,
        lastSentAt: now,
      });

      const smsSent = await sendSMS(data.mobile, otp);
      console.log(`OTP for ${data.mobile}: ${otp} (SMS sent: ${smsSent})`);

      res.json({
        success: true,
        message: smsSent ? "OTP sent" : "OTP generated",
        userId: user.id,
        mobile: user.mobile,
        isNewUser,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // OTP Verification route
  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const data = otpVerificationSchema.parse(req.body);

      if (data.otp.length !== 4 || !/^\d{4}$/.test(data.otp)) {
        return res.status(400).json({ error: "OTP must be 4 digits" });
      }

      const storedOtp = otpStorage.get(data.mobile);
      if (!storedOtp) {
        return res.status(400).json({ error: "OTP expired or not requested. Please request a new OTP." });
      }
      if (Date.now() > storedOtp.expiresAt) {
        otpStorage.delete(data.mobile);
        return res.status(400).json({ error: "OTP expired. Please request a new OTP." });
      }
      if (storedOtp.otp !== data.otp) {
        return res.status(400).json({ error: "Invalid OTP. Please check and try again." });
      }

      let user = await storage.getUserByMobile(data.mobile, data.role);
      if (!user) {
        user = await storage.createUser({
          name: "User",
          email: null,
          mobile: data.mobile,
          role: data.role,
        });
      }

      const isNewUser = user.name === "User" || !user.name;

      if (!user.isVerified) {
        user = (await storage.updateUserVerification(user.id))!;
      }

      otpStorage.delete(data.mobile);

      for (const [token, session] of userSessions.entries()) {
        if (session.userId === user.id) {
          userSessions.delete(token);
        }
      }

      const sessionToken = generateUserSessionToken();
      userSessions.set(sessionToken, {
        userId: user.id,
        expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
      });

      res.json({
        success: true,
        message: "OTP verified successfully",
        sessionToken,
        isNewUser,
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          role: user.role,
          isPremium: user.isPremium,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({
        id: user.id,
        name: user.name,
        mobile: user.mobile,
        email: user.email,
        role: user.role,
        isPremium: user.isPremium,
        premiumPlan: user.premiumPlan,
        premiumViewsRemaining: user.premiumViewsRemaining,
        premiumExpiresAt: user.premiumExpiresAt,
        premiumActivatedAt: user.premiumActivatedAt,
      });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Activate premium membership with plan selection
  app.post("/api/users/:id/premium", async (req, res) => {
    try {
      const { plan, amount } = req.body;
      const validPlans = ["basic", "standard", "premium"];
      if (!plan || !validPlans.includes(plan)) {
        return res.status(400).json({ error: "Invalid plan. Must be basic, standard, or premium." });
      }
      if (!amount || typeof amount !== "number" || amount <= 0) {
        return res.status(400).json({ error: "Invalid amount." });
      }

      const enabledSetting = await storage.getSetting(`premium_${plan}_enabled`);
      if (enabledSetting?.value === "false") {
        return res.status(400).json({ error: "This plan is currently unavailable." });
      }

      const defaultPrices: Record<string, number> = { basic: 199, standard: 299, premium: 399 };
      const priceSetting = await storage.getSetting(`premium_${plan}_price`);
      const expectedPrice = parseInt(priceSetting?.value || String(defaultPrices[plan]));
      if (amount !== expectedPrice * 100) {
        return res.status(400).json({ error: "Payment amount does not match plan price." });
      }

      const viewsSetting = await storage.getSetting(`premium_${plan}_views`);
      const defaultViews: Record<string, number> = { basic: 10, standard: 20, premium: -1 };
      const views = plan === "premium" ? -1 : parseInt(viewsSetting?.value || String(defaultViews[plan]));

      const selectedPlan = { views, label: plan.charAt(0).toUpperCase() + plan.slice(1) };
      const user = await storage.activatePremiumWithPlan(
        req.params.id,
        plan || "standard",
        selectedPlan.views
      );
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      await storage.createPayment({
        customerId: user.id,
        amount: amount || 29900,
        currency: "INR",
        type: "premium_membership",
        status: "completed",
        reference: `PREM-${plan?.toUpperCase() || "STD"}-${Date.now()}`,
        paidAt: new Date().toISOString(),
      });

      res.json({
        success: true,
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          role: user.role,
          isPremium: user.isPremium,
          premiumPlan: user.premiumPlan,
          premiumViewsRemaining: user.premiumViewsRemaining,
          premiumExpiresAt: user.premiumExpiresAt,
          premiumActivatedAt: user.premiumActivatedAt,
        },
      });
    } catch (error) {
      console.error("Premium activation error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Use a premium view (decrement views remaining)
  app.post("/api/users/:id/premium/use-view", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      if (!user.isPremium) {
        return res.status(403).json({ error: "Not a premium member" });
      }
      if (user.premiumExpiresAt && new Date(user.premiumExpiresAt) < new Date()) {
        return res.status(403).json({ error: "Premium membership expired", expired: true });
      }
      if (user.premiumPlan !== "premium" && (user.premiumViewsRemaining ?? 0) <= 0) {
        return res.status(403).json({ error: "No views remaining" });
      }

      const updated = await storage.usePremiumView(req.params.id);
      res.json({
        success: true,
        viewsRemaining: updated?.premiumViewsRemaining,
        plan: updated?.premiumPlan,
      });
    } catch (error) {
      console.error("Use premium view error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get viewed contacts for a user
  app.get("/api/users/:id/viewed-contacts", async (req, res) => {
    try {
      const viewedBookingIds = await storage.getViewedContacts(req.params.id);
      res.json({ viewedBookingIds });
    } catch (error) {
      console.error("Get viewed contacts error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Save a viewed contact
  app.post("/api/users/:id/viewed-contacts", async (req, res) => {
    try {
      const { bookingId } = req.body;
      if (!bookingId) {
        return res.status(400).json({ error: "bookingId is required" });
      }
      await storage.addViewedContact(req.params.id, bookingId);
      res.json({ success: true });
    } catch (error) {
      console.error("Save viewed contact error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Update current user profile (using session token)
  app.patch("/api/users/me", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const token = authHeader.split(" ")[1];
      const session = userSessions.get(token);
      if (!session || Date.now() > session.expiresAt) {
        if (session) userSessions.delete(token);
        return res.status(401).json({ error: "Session expired" });
      }
      const userId = session.userId;
      
      const data = updateUserSchema.parse(req.body);
      const updateData = {
        ...data,
        email: data.email === "" ? null : data.email
      };
      const user = await storage.updateUser(userId, updateData);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({
        success: true,
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          role: user.role,
          city: user.city,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      console.error("Error updating user:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Update user profile
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const data = updateUserSchema.parse(req.body);
      // Convert empty email to null for database storage
      const updateData = {
        ...data,
        email: data.email === "" ? null : data.email
      };
      const user = await storage.updateUser(req.params.id, updateData);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({
        success: true,
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          role: user.role,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Delete user account (self-deletion - requires authentication)
  app.delete("/api/users/:id", async (req, res) => {
    try {
      // Verify the user's session token
      const authHeader = req.headers.authorization;
      const token = authHeader?.replace("Bearer ", "");
      const session = validateUserSession(token);
      
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized - please log in again" });
      }
      
      // Verify the authenticated user matches the account being deleted
      if (session.userId !== req.params.id) {
        return res.status(403).json({ error: "Forbidden - you can only delete your own account" });
      }
      
      // Verify the user exists
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Delete the user
      await storage.deleteUser(req.params.id);
      
      // Also clear their session
      if (token) {
        userSessions.delete(token);
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get worker profile by user ID
  app.get("/api/workers/profile/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const profile = await storage.getWorkerProfileByUserId(userId);
      
      if (!profile) {
        return res.status(404).json({ error: "Worker profile not found" });
      }
      
      res.json({ profile });
    } catch (error) {
      console.error("Get worker profile error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Create or update worker profile
  app.post("/api/workers/profile", async (req, res) => {
    try {
      const profile = insertWorkerProfileSchema.parse(req.body);
      
      // Get user's mobile number to include in worker profile
      const user = await storage.getUser(profile.userId);
      const profileWithMobile = {
        ...profile,
        mobile: profile.mobile || user?.mobile || null,
        whatsapp: profile.whatsapp || user?.mobile || null,
      };
      
      // Check if profile already exists
      const existing = await storage.getWorkerProfileByUserId(profile.userId);
      
      if (existing) {
        const updateData: Record<string, any> = { ...profileWithMobile };
        Object.keys(updateData).forEach(key => {
          if (updateData[key] === null || updateData[key] === undefined) {
            if ((existing as any)[key] !== null && (existing as any)[key] !== undefined) {
              delete updateData[key];
            }
          }
        });
        const updated = await storage.updateWorkerProfile(profile.userId, updateData);
        return res.json({ success: true, profile: updated });
      }
      
      const created = await storage.createWorkerProfile(profileWithMobile);
      res.json({ success: true, profile: created });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      console.error("Worker profile error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get all workers with optional location-based sorting and city filtering
  app.get("/api/workers", async (req, res) => {
    try {
      const lat = req.query.lat ? parseFloat(req.query.lat as string) : null;
      const lng = req.query.lng ? parseFloat(req.query.lng as string) : null;
      const city = req.query.city as string | undefined;
      const userId = req.query.userId as string | undefined;
      
      // If userId is provided, return that specific worker's profile
      if (userId) {
        const workerProfile = await storage.getWorkerProfileByUserId(userId);
        if (workerProfile) {
          return res.json({ workers: [workerProfile] });
        }
        return res.json({ workers: [] });
      }
      
      const workers = await storage.getAllWorkerProfiles(city);
      
      // Calculate distance and sort if user location provided
      const workersWithDistance = workers.map(worker => {
        let distance: number | null = null;
        if (lat && lng && worker.latitude && worker.longitude) {
          distance = calculateDistance(lat, lng, worker.latitude, worker.longitude);
        }
        return { ...worker, distance };
      });
      
      // Sort by distance if location provided, otherwise by rating
      if (lat && lng) {
        workersWithDistance.sort((a, b) => {
          if (a.distance === null) return 1;
          if (b.distance === null) return -1;
          return a.distance - b.distance;
        });
      } else {
        workersWithDistance.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      }
      
      res.json({ workers: workersWithDistance });
    } catch (error) {
      console.error("Get workers error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/workers/:userId/location", async (req, res) => {
    try {
      const { userId } = req.params;
      const { latitude, longitude } = req.body;
      if (typeof latitude !== "number" || typeof longitude !== "number") {
        return res.status(400).json({ error: "Invalid coordinates" });
      }
      const user = await storage.getUser(userId);
      if (!user || user.role !== "worker") {
        return res.status(403).json({ error: "Unauthorized" });
      }
      const profile = await storage.getWorkerProfileByUserId(userId);
      if (profile) {
        await storage.updateWorkerProfileLocation(userId, latitude, longitude);
      } else {
        await storage.createWorkerProfile({
          userId,
          latitude,
          longitude,
          mobile: user.mobile,
        });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Update worker location error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get active cities for customers
  app.get("/api/cities", async (req, res) => {
    try {
      const citiesList = await storage.getActiveCities();
      // Return only active cities - no hardcoded fallback
      // If admin disables all cities, app will show "service not available"
      res.json({ cities: citiesList });
    } catch (error) {
      console.error("Get cities error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all cities (including inactive)
  app.get("/api/admin/cities", async (req, res) => {
    try {
      const citiesList = await storage.getAllCities();
      res.json({ cities: citiesList });
    } catch (error) {
      console.error("Get all cities error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Create a new city
  app.post("/api/admin/cities", async (req, res) => {
    try {
      const cityData = insertCitySchema.parse(req.body);
      const city = await storage.createCity(cityData);
      res.json({ success: true, city });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      console.error("Create city error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Update a city
  app.patch("/api/admin/cities/:id", async (req, res) => {
    try {
      const city = await storage.updateCity(req.params.id, req.body);
      if (!city) {
        return res.status(404).json({ error: "City not found" });
      }
      res.json({ success: true, city });
    } catch (error) {
      console.error("Update city error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Delete a city
  app.delete("/api/admin/cities/:id", async (req, res) => {
    try {
      await storage.deleteCity(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete city error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all users with worker profiles
  app.get("/api/admin/users", async (req, res) => {
    try {
      const usersList = await storage.getAllUsers();
      const workerProfiles = await storage.getAllWorkerProfiles();
      const allBookings = await storage.getAllBookings();
      
      const usersWithStats = usersList.map(user => {
        if (user.role === "customer") {
          const userBookings = allBookings.filter(b => b.customerId === user.id);
          const spacesPosted = userBookings.length;
          const cityFromBooking = !user.city && userBookings.length > 0 
            ? userBookings[0].city 
            : null;
          return {
            ...user,
            spacesPosted,
            city: user.city || cityFromBooking || null,
          };
        }
        return user;
      });
      
      res.json({ users: usersWithStats, workerProfiles });
    } catch (error) {
      console.error("Get all users error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all bookings
  app.get("/api/admin/bookings", async (req, res) => {
    try {
      const bookingsList = await storage.getAllBookings();
      res.json({ bookings: bookingsList });
    } catch (error) {
      console.error("Get all bookings error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all services
  app.get("/api/admin/services", async (req, res) => {
    try {
      const servicesList = await storage.getAllServices();
      res.json({ services: servicesList });
    } catch (error) {
      console.error("Get all services error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Create a service
  app.post("/api/admin/services", async (req, res) => {
    try {
      const { name, icon, description, isActive, displayOrder } = req.body;
      
      // Validate required fields
      if (!name || !icon) {
        return res.status(400).json({ error: "Name and icon are required" });
      }
      
      const service = await storage.createService({ 
        name, 
        icon, 
        description: description || null, 
        isActive: isActive ?? true, 
        displayOrder: displayOrder ?? 0 
      });
      res.json({ success: true, service });
    } catch (error) {
      console.error("Create service error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Update a service
  app.patch("/api/admin/services/:id", async (req, res) => {
    try {
      const service = await storage.updateService(req.params.id, req.body);
      if (!service) {
        return res.status(404).json({ error: "Service not found" });
      }
      res.json({ success: true, service });
    } catch (error) {
      console.error("Update service error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Delete a service
  app.delete("/api/admin/services/:id", async (req, res) => {
    try {
      await storage.deleteService(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete service error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get active service pincodes (public endpoint for app)
  app.get("/api/pincodes", async (req, res) => {
    try {
      const pincodes = await storage.getActiveServicePincodes();
      res.json({ pincodes });
    } catch (error) {
      console.error("Get pincodes error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all service pincodes
  app.get("/api/admin/pincodes", async (req, res) => {
    try {
      const pincodes = await storage.getAllServicePincodes();
      res.json({ pincodes });
    } catch (error) {
      console.error("Get all pincodes error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Create a service pincode
  app.post("/api/admin/pincodes", async (req, res) => {
    try {
      const { prefix, cityName, isActive, displayOrder } = req.body;
      
      if (!prefix || !cityName) {
        return res.status(400).json({ error: "Prefix and city name are required" });
      }
      
      const pincode = await storage.createServicePincode({
        prefix,
        cityName,
        isActive: isActive ?? true,
        displayOrder: displayOrder ?? 0
      });
      res.json({ success: true, pincode });
    } catch (error) {
      console.error("Create pincode error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Update a service pincode
  app.patch("/api/admin/pincodes/:id", async (req, res) => {
    try {
      const pincode = await storage.updateServicePincode(req.params.id, req.body);
      if (!pincode) {
        return res.status(404).json({ error: "Pincode not found" });
      }
      res.json({ success: true, pincode });
    } catch (error) {
      console.error("Update pincode error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Delete a service pincode
  app.delete("/api/admin/pincodes/:id", async (req, res) => {
    try {
      await storage.deleteServicePincode(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete pincode error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Edit a user
  app.patch("/api/admin/users/:id", async (req, res) => {
    try {
      const { name, email, city, mobile } = req.body;
      const updateData: any = {};
      if (name !== undefined) updateData.name = name;
      if (email !== undefined) updateData.email = email;
      if (city !== undefined) updateData.city = city;
      const user = await storage.updateUser(req.params.id, updateData);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ success: true, user });
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Delete a user
  app.delete("/api/admin/users/:id", async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Create a worker with profile
  app.post("/api/admin/workers", async (req, res) => {
    try {
      const { name, mobile, email, age, gender, services, location, city, latitude, longitude, foodType, workConditions, whatsapp } = req.body;
      
      // Validate required fields
      if (!name || !mobile) {
        return res.status(400).json({ error: "Name and mobile are required" });
      }
      if (!/^\d{10}$/.test(mobile)) {
        return res.status(400).json({ error: "Mobile must be 10 digits" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByMobile(mobile, "worker");
      if (existingUser) {
        return res.status(409).json({ error: "Worker with this mobile already exists" });
      }
      
      const result = await storage.createWorkerWithProfile(
        { name, mobile, email: email || null, role: "worker" },
        { age, gender, services, location, city, latitude, longitude, foodType, workConditions, mobile, whatsapp: whatsapp || mobile }
      );
      
      res.json({ success: true, user: result.user, profile: result.profile });
    } catch (error) {
      console.error("Create worker error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Update worker profile
  app.patch("/api/admin/workers/:userId", async (req, res) => {
    try {
      const { name, email, ...profileData } = req.body;
      
      // Update user basic info
      if (name || email !== undefined) {
        await storage.updateUser(req.params.userId, { name, email });
      }
      
      // Update worker profile
      const profile = await storage.updateWorkerProfile(req.params.userId, profileData);
      if (!profile) {
        return res.status(404).json({ error: "Worker profile not found" });
      }
      
      res.json({ success: true, profile });
    } catch (error) {
      console.error("Update worker error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Delete worker
  app.delete("/api/admin/workers/:userId", async (req, res) => {
    try {
      await storage.deleteUser(req.params.userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete worker error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Login endpoint with server-side validation
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { password } = req.body;
      
      let level: 'super' | 'sub' | null = null;
      
      if (password === SUPER_ADMIN_PASSWORD) {
        level = 'super';
      } else if (password === SUB_ADMIN_PASSWORD) {
        level = 'sub';
      }
      
      if (!level) {
        return res.status(401).json({ error: "Invalid password" });
      }
      
      const token = generateSessionToken();
      adminSessions.set(token, {
        level,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
      });
      
      res.json({ success: true, token, level });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Validate session endpoint
  app.get("/api/admin/session", async (req, res) => {
    const token = req.headers.authorization?.replace("Bearer ", "");
    const session = validateAdminSession(token);
    
    if (!session.valid) {
      return res.status(401).json({ error: "Invalid or expired session" });
    }
    
    res.json({ valid: true, level: session.level });
  });

  // Admin: Logout endpoint
  app.post("/api/admin/logout", async (req, res) => {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (token) {
      adminSessions.delete(token);
    }
    res.json({ success: true });
  });

  // Admin: Get payment totals (super-admin only with server-side validation)
  app.get("/api/admin/payments/totals", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      const session = validateAdminSession(token);
      
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      if (session.level !== "super") {
        return res.status(403).json({ error: "Access denied. Super admin only." });
      }
      
      const { startDate, endDate, plan } = req.query;
      
      const totals = await storage.getPaymentTotals(
        startDate as string | undefined,
        endDate as string | undefined,
        plan as string | undefined
      );
      
      res.json({
        totalAmount: totals.total / 100, // Convert paise to rupees
        totalAmountPaise: totals.total,
        transactionCount: totals.count,
        currency: "INR"
      });
    } catch (error) {
      console.error("Get payment totals error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all payments list (super-admin only with server-side validation)
  app.get("/api/admin/payments", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      const session = validateAdminSession(token);
      
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      if (session.level !== "super") {
        return res.status(403).json({ error: "Access denied. Super admin only." });
      }
      
      const { startDate, endDate, plan } = req.query;
      
      let paymentsList;
      if (startDate && endDate) {
        paymentsList = await storage.getPaymentsByDateRange(startDate as string, endDate as string, plan as string | undefined);
      } else {
        paymentsList = await storage.getAllPayments(plan as string | undefined);
      }
      
      res.json({ payments: paymentsList });
    } catch (error) {
      console.error("Get payments error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get active services (for customers)
  app.get("/api/services", async (req, res) => {
    try {
      const servicesList = await storage.getActiveServices();
      res.json({ services: servicesList });
    } catch (error) {
      console.error("Get services error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Create a new booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      
      const user = await storage.getUser(bookingData.customerId);
      if (!user) {
        return res.status(404).json({ error: "User not found. Please log in again." });
      }
      
      const booking = await storage.createBooking(bookingData);
      
      let notifiedNearbyIds: string[] = [];
      if (booking.latitude && booking.longitude) {
        notifiedNearbyIds = await storage.createNotificationForNearbyWorkers({
          type: "new_job",
          title: "New Parking Space Nearby!",
          message: `New ${booking.serviceName} posted near you in ${booking.location}`,
          bookingId: booking.id,
          createdAt: new Date().toISOString(),
        }, booking.latitude, booking.longitude, 10);
      }
      
      await storage.createNotificationForAllWorkers({
        type: "new_job",
        title: "New Parking Space Available",
        message: `New ${booking.serviceName} in ${booking.location}`,
        bookingId: booking.id,
        createdAt: new Date().toISOString(),
      }, booking.city || undefined, notifiedNearbyIds);
      
      res.json({ success: true, booking });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      console.error("Create booking error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/bookings/:id", async (req, res) => {
    try {
      const { serviceName, location, comments, date, time } = req.body;
      const booking = await storage.updateBooking(req.params.id, {
        serviceName, location, comments, date, time,
      });
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }
      res.json({ success: true, booking });
    } catch (error) {
      console.error("Update booking error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      await storage.deleteBooking(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete booking error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get bookings by customer (with worker details for accepted bookings)
  app.get("/api/bookings/customer/:customerId", async (req, res) => {
    try {
      const limitRaw = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offsetRaw = req.query.offset ? parseInt(req.query.offset as string) : undefined;
      const limit = limitRaw != null && Number.isFinite(limitRaw) && limitRaw > 0 ? limitRaw : undefined;
      const offset = offsetRaw != null && Number.isFinite(offsetRaw) && offsetRaw >= 0 ? offsetRaw : undefined;
      const includePhotos = req.query.includePhotos === "true";
      const { bookings, total } = await storage.getBookingsByCustomer(req.params.customerId, limit, offset);

      // Strip heavy base64 photo payload from list responses (saves MBs per request).
      // Replace [PHOTOS]...[/PHOTOS] with [PHOTOS_COUNT:n] so the client can still show counts.
      const stripPhotos = (comments: string | null | undefined) => {
        if (!comments) return comments;
        return comments.replace(/\[PHOTOS\](.*?)\[\/PHOTOS\]/s, (_m, payload) => {
          try {
            const arr = JSON.parse(payload);
            return Array.isArray(arr) ? `[PHOTOS_COUNT:${arr.length}]` : "";
          } catch {
            return "";
          }
        });
      };

      // Enrich bookings with worker details for accepted/completed bookings
      const enrichedBookings = await Promise.all(
        bookings.map(async (booking) => {
          const lean = includePhotos ? booking : { ...booking, comments: stripPhotos(booking.comments) };
          if (booking.workerId && (booking.status === "accepted" || booking.status === "completed")) {
            const worker = await storage.getUser(booking.workerId);
            const workerProfile = await storage.getWorkerProfileByUserId(booking.workerId);
            if (worker) {
              return {
                ...lean,
                worker: {
                  id: worker.id,
                  name: worker.name,
                  mobile: workerProfile?.mobile || worker.mobile,
                  rating: workerProfile?.rating || 4.5,
                  reviews: workerProfile?.reviews || 0,
                  gender: workerProfile?.gender || "Unknown",
                  age: workerProfile?.age,
                  workConditions: workerProfile?.workConditions || ""
                }
              };
            }
          }
          return { ...lean, worker: null };
        })
      );
      
      res.json({ bookings: enrichedBookings, total });
    } catch (error) {
      console.error("Get customer bookings error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get bookings for worker (pending jobs they can accept)
  app.get("/api/bookings/worker/:workerId", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const bookings = await storage.getBookingsByWorker(req.params.workerId, status);
      res.json({ bookings });
    } catch (error) {
      console.error("Get worker bookings error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get all pending bookings (for workers to see available jobs)
  app.get("/api/bookings/pending", async (req, res) => {
    try {
      const city = req.query.city as string | undefined;
      const limitRaw = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offsetRaw = req.query.offset ? parseInt(req.query.offset as string) : undefined;
      const limit = limitRaw != null && Number.isFinite(limitRaw) && limitRaw > 0 ? limitRaw : undefined;
      const offset = offsetRaw != null && Number.isFinite(offsetRaw) && offsetRaw >= 0 ? offsetRaw : undefined;
      const latRaw = req.query.lat ? parseFloat(req.query.lat as string) : undefined;
      const lngRaw = req.query.lng ? parseFloat(req.query.lng as string) : undefined;
      const radiusRaw = req.query.radius ? parseFloat(req.query.radius as string) : undefined;
      const userLat = latRaw != null && Number.isFinite(latRaw) ? latRaw : undefined;
      const userLng = lngRaw != null && Number.isFinite(lngRaw) ? lngRaw : undefined;
      const radiusKm = radiusRaw != null && Number.isFinite(radiusRaw) && radiusRaw > 0 ? radiusRaw : undefined;
      const { bookings: bookingsList, total } = await storage.getPendingBookings(city, limit, offset, userLat, userLng, radiusKm);
      const ownerIds = [...new Set(bookingsList.map(b => b.customerId))];
      const ownerMap: Record<string, { name: string; phone: string }> = {};
      await Promise.all(ownerIds.map(async (id) => {
        try {
          const user = await storage.getUser(id);
          if (user) ownerMap[id] = { name: user.name || "Space Owner", phone: user.mobile || "" };
        } catch {}
      }));
      const enriched = bookingsList.map(b => ({
        ...b,
        ownerName: ownerMap[b.customerId]?.name || "Space Owner",
        ownerPhone: ownerMap[b.customerId]?.phone || "",
      }));
      res.json({ bookings: enriched, total });
    } catch (error) {
      console.error("Get pending bookings error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Update booking status (accept, complete, cancel)
  app.patch("/api/bookings/:id/status", async (req, res) => {
    try {
      const { status, workerId, previousWorkerId } = req.body;
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }
      
      // Get the current booking to check if there's a worker being rejected
      const currentBooking = await storage.getBookingById(req.params.id);
      const workerBeingRejected = currentBooking?.workerId;
      
      const booking = await storage.updateBookingStatus(req.params.id, status, workerId);
      if (!booking) {
        // For acceptance, this likely means another worker already accepted
        if (status === "accepted") {
          return res.status(409).json({ error: "This job was already accepted by another worker" });
        }
        return res.status(404).json({ error: "Booking not found" });
      }
      
      // Notify worker if they were rejected by customer (status = pending and workerId = null)
      if (status === "pending" && workerId === null && workerBeingRejected) {
        const customer = await storage.getUser(booking.customerId);
        await storage.createNotification({
          userId: workerBeingRejected,
          type: "job_rejected_by_customer",
          title: "Job Reassigned",
          message: `${customer?.name || 'The customer'} has chosen a different worker for their ${booking.serviceName} request. Keep checking for more opportunities!`,
          bookingId: booking.id,
          createdAt: new Date().toISOString(),
        });
        
        // Also notify other workers in the city that the job is available again
        await storage.createNotificationForAllWorkers({
          type: "new_job",
          title: "Job Available Again",
          message: `${booking.serviceName} job in ${booking.location} is available again`,
          bookingId: booking.id,
          createdAt: new Date().toISOString(),
        }, booking.city || undefined);
      }
      
      res.json({ success: true, booking });
    } catch (error) {
      console.error("Update booking status error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Worker accepts a job
  app.post("/api/bookings/:id/accept", async (req, res) => {
    try {
      const { workerId } = req.body;
      if (!workerId) {
        return res.status(400).json({ error: "Worker ID is required" });
      }
      const booking = await storage.updateBookingStatus(req.params.id, "accepted", workerId);
      if (!booking) {
        return res.status(409).json({ error: "This job was already accepted by another worker" });
      }
      
      // Notify customer that worker accepted their job
      const worker = await storage.getUser(workerId);
      await storage.createNotification({
        userId: booking.customerId,
        type: "job_accepted",
        title: "Job Accepted",
        message: `${worker?.name || 'A worker'} has accepted your ${booking.serviceName} request`,
        bookingId: booking.id,
        createdAt: new Date().toISOString(),
      });
      
      res.json({ success: true, booking });
    } catch (error) {
      console.error("Accept booking error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Worker cancels an accepted job (returns it to pending)
  app.post("/api/bookings/:id/cancel", async (req, res) => {
    try {
      const { workerId } = req.body;
      if (!workerId) {
        return res.status(400).json({ error: "Worker ID is required" });
      }
      
      // First verify the worker owns this booking
      const workerBookings = await storage.getBookingsByWorker(workerId, "accepted");
      const targetBooking = workerBookings.find(b => b.id === req.params.id);
      if (!targetBooking) {
        return res.status(403).json({ error: "You cannot cancel a job you haven't accepted" });
      }
      
      // Get worker name for notification
      const worker = await storage.getUser(workerId);
      
      // Reset status to pending and clear workerId
      const booking = await storage.updateBookingStatus(req.params.id, "pending", null);
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }
      
      // Notify customer that worker rejected/cancelled with reassurance message
      await storage.createNotification({
        userId: booking.customerId,
        type: "job_rejected",
        title: "Job Cancelled by Worker",
        message: `${worker?.name || 'The worker'} has cancelled your ${booking.serviceName} request. Don't worry! Your job is now available for other workers and you'll be notified soon.`,
        bookingId: booking.id,
        createdAt: new Date().toISOString(),
      });
      
      // Notify workers in the same city that job is available again
      await storage.createNotificationForAllWorkers({
        type: "new_job",
        title: "Job Available Again",
        message: `${booking.serviceName} job in ${booking.location} is available again`,
        bookingId: booking.id,
        createdAt: new Date().toISOString(),
      }, booking.city || undefined);
      
      res.json({ success: true, booking });
    } catch (error) {
      console.error("Cancel booking error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Rate a booking
  app.post("/api/interests/:bookingId", async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) return res.status(400).json({ error: "userId is required" });
      const interest = await storage.addInterest(req.params.bookingId, userId);
      const count = await storage.getInterestCount(req.params.bookingId);

      const booking = await storage.getBookingById(req.params.bookingId);
      if (booking && booking.customerId) {
        const seeker = await storage.getUser(userId);
        const seekerName = seeker?.name || "Someone";
        const spaceName = booking.serviceName || "your parking space";
        await storage.createNotification({
          userId: booking.customerId,
          type: "interest_received",
          title: "New Interest!",
          message: `${seekerName} is interested in ${spaceName}`,
          bookingId: req.params.bookingId,
          createdAt: new Date().toISOString(),
        });
      }

      res.json({ success: true, interest, count });
    } catch (error) {
      console.error("Add interest error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/interests/:bookingId", async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) return res.status(400).json({ error: "userId is required" });
      await storage.removeInterest(req.params.bookingId, userId);
      const count = await storage.getInterestCount(req.params.bookingId);
      res.json({ success: true, count });
    } catch (error) {
      console.error("Remove interest error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/interests/counts", async (req, res) => {
    try {
      const bookingIds = (req.query.ids as string || "").split(",").filter(Boolean);
      const counts = await storage.getInterestCounts(bookingIds);
      res.json({ counts });
    } catch (error) {
      console.error("Get interest counts error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/interests/user/:userId", async (req, res) => {
    try {
      const bookingIds = await storage.getUserInterests(req.params.userId);
      res.json({ bookingIds });
    } catch (error) {
      console.error("Get user interests error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/bookings/:id/rate", async (req, res) => {
    try {
      const { rating } = req.body;
      if (!rating || rating < 1 || rating > 5) {
        return res.status(400).json({ error: "Rating must be between 1 and 5" });
      }
      const booking = await storage.rateBooking(req.params.id, rating);
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }
      
      // Notify worker about the rating
      if (booking.workerId) {
        await storage.createNotification({
          userId: booking.workerId,
          type: "rating_received",
          title: "New Rating Received",
          message: `You received a ${rating}-star rating for your ${booking.serviceName} service`,
          bookingId: booking.id,
          createdAt: new Date().toISOString(),
        });
      }
      
      res.json({ success: true, booking });
    } catch (error) {
      console.error("Rate booking error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get a single booking by ID (used for edit flow). Must be defined AFTER all
  // more specific /api/bookings/* routes so it doesn't shadow them.
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const booking = await storage.getBookingById(req.params.id);
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }
      res.json({ booking });
    } catch (error) {
      console.error("Get booking by id error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get notifications for a user
  app.get("/api/notifications/:userId", async (req, res) => {
    try {
      const notificationsList = await storage.getNotificationsByUser(req.params.userId);
      res.json({ notifications: notificationsList });
    } catch (error) {
      console.error("Get notifications error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Mark notification as read
  app.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      const notification = await storage.markNotificationAsRead(req.params.id);
      if (!notification) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json({ success: true, notification });
    } catch (error) {
      console.error("Mark notification read error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Mark all notifications as read for a user
  app.post("/api/notifications/:userId/read-all", async (req, res) => {
    try {
      await storage.markAllNotificationsAsRead(req.params.userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark all notifications read error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Clear all notifications for a user
  app.delete("/api/notifications/:userId/clear", async (req, res) => {
    try {
      await storage.clearNotificationsByUser(req.params.userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Clear notifications error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Broadcast notification to users (requires admin authentication)
  app.post("/api/admin/broadcast", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.replace("Bearer ", "");
      const session = validateAdminSession(token);
      
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const { title, message, target } = req.body;
      if (!title || !message || !target) {
        return res.status(400).json({ error: "Title, message and target are required" });
      }
      
      const notification = {
        type: "broadcast",
        title,
        message,
        createdAt: new Date().toISOString(),
      };
      
      if (target === "workers") {
        await storage.createNotificationForAllWorkers(notification);
      } else if (target === "customers") {
        await storage.createNotificationForAllCustomers(notification);
      } else if (target === "all") {
        await storage.createNotificationForAll(notification);
      } else {
        return res.status(400).json({ error: "Invalid target. Use 'workers', 'customers', or 'all'" });
      }
      
      res.json({ success: true, message: `Broadcast sent to ${target}` });
    } catch (error) {
      console.error("Broadcast notification error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get disclaimer by language (public endpoint)
  app.get("/api/disclaimer/:language", async (req, res) => {
    try {
      const disclaimer = await storage.getDisclaimerByLanguage(req.params.language);
      if (!disclaimer) {
        // Return default English disclaimer if none found
        return res.json({ 
          disclaimer: {
            language: req.params.language,
            title: "Important Notice",
            content: "This app only helps connect house owners and workers.\nWe do not provide any safety, guarantee, or responsibility for either party.\nHouse owners and workers must communicate directly and take care of their own safety.",
            isActive: true
          }
        });
      }
      res.json({ disclaimer });
    } catch (error) {
      console.error("Get disclaimer error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all disclaimers
  app.get("/api/admin/disclaimers", async (req, res) => {
    try {
      const disclaimerList = await storage.getAllDisclaimers();
      res.json({ disclaimers: disclaimerList });
    } catch (error) {
      console.error("Get disclaimers error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Create disclaimer
  app.post("/api/admin/disclaimers", async (req, res) => {
    try {
      const { language, title, content, isActive } = req.body;
      if (!language || !title || !content) {
        return res.status(400).json({ error: "Language, title and content are required" });
      }
      const disclaimer = await storage.createDisclaimer({ language, title, content, isActive: isActive ?? true });
      res.json({ success: true, disclaimer });
    } catch (error) {
      console.error("Create disclaimer error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Update disclaimer
  app.patch("/api/admin/disclaimers/:id", async (req, res) => {
    try {
      const disclaimer = await storage.updateDisclaimer(req.params.id, req.body);
      if (!disclaimer) {
        return res.status(404).json({ error: "Disclaimer not found" });
      }
      res.json({ success: true, disclaimer });
    } catch (error) {
      console.error("Update disclaimer error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Delete disclaimer
  app.delete("/api/admin/disclaimers/:id", async (req, res) => {
    try {
      await storage.deleteDisclaimer(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete disclaimer error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Public: Get premium plan configurations
  app.get("/api/settings/premium-plans", async (req, res) => {
    try {
      const [basicPrice, standardPrice, premiumPrice, basicEnabled, standardEnabled, premiumEnabled, basicViews, standardViews, premiumViews] = await Promise.all([
        storage.getSetting("premium_basic_price"),
        storage.getSetting("premium_standard_price"),
        storage.getSetting("premium_premium_price"),
        storage.getSetting("premium_basic_enabled"),
        storage.getSetting("premium_standard_enabled"),
        storage.getSetting("premium_premium_enabled"),
        storage.getSetting("premium_basic_views"),
        storage.getSetting("premium_standard_views"),
        storage.getSetting("premium_premium_views"),
      ]);

      const plans = [
        { key: "basic", name: "Basic", price: parseInt(basicPrice?.value || "199"), views: parseInt(basicViews?.value || "10"), enabled: basicEnabled?.value !== "false" },
        { key: "standard", name: "Standard", price: parseInt(standardPrice?.value || "299"), views: parseInt(standardViews?.value || "20"), enabled: standardEnabled?.value !== "false" },
        { key: "premium", name: "Premium", price: parseInt(premiumPrice?.value || "399"), views: -1, enabled: premiumEnabled?.value !== "false" },
      ];

      res.json({ plans });
    } catch (error) {
      console.error("Get premium plans error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Public: Get app setting (for contact hours)
  app.get("/api/settings/:key", async (req, res) => {
    try {
      const setting = await storage.getSetting(req.params.key);
      res.json({ setting: setting || null });
    } catch (error) {
      console.error("Get setting error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Get all settings
  app.get("/api/admin/settings", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.replace("Bearer ", "");
      const session = validateAdminSession(token);
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const settingsList = await storage.getAllSettings();
      res.json({ settings: settingsList });
    } catch (error) {
      console.error("Get settings error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Admin: Update setting
  app.post("/api/admin/settings", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.replace("Bearer ", "");
      const session = validateAdminSession(token);
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { key, value, description } = req.body;
      if (!key || value === undefined) {
        return res.status(400).json({ error: "Key and value are required" });
      }
      const setting = await storage.upsertSetting(key, value, description);
      res.json({ success: true, setting });
    } catch (error) {
      console.error("Update setting error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Upload ad video
  app.post("/api/admin/upload-video", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.replace("Bearer ", "");
      const session = validateAdminSession(token);
      if (!session.valid) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const chunks: Buffer[] = [];
      req.on("data", (chunk: Buffer) => chunks.push(chunk));
      req.on("end", async () => {
        const body = Buffer.concat(chunks);
        const boundary = req.headers["content-type"]?.split("boundary=")[1];
        if (!boundary) {
          return res.status(400).json({ error: "Invalid form data" });
        }

        const bodyStr = body.toString("latin1");
        const parts = bodyStr.split(`--${boundary}`);
        
        let fileData: Buffer | null = null;
        let fileName = "ad-video.mp4";
        
        for (const part of parts) {
          if (part.includes("Content-Disposition") && part.includes('name="video"')) {
            const filenameMatch = part.match(/filename="([^"]+)"/);
            if (filenameMatch) fileName = filenameMatch[1];
            
            const headerEnd = part.indexOf("\r\n\r\n");
            if (headerEnd !== -1) {
              const dataStart = headerEnd + 4;
              const dataEnd = part.lastIndexOf("\r\n");
              const rawData = part.substring(dataStart, dataEnd);
              fileData = Buffer.from(rawData, "latin1");
            }
          }
        }

        if (!fileData) {
          return res.status(400).json({ error: "No video file found" });
        }

        const uploadsDir = path.join(process.cwd(), "uploads");
        if (!fs.existsSync(uploadsDir)) {
          fs.mkdirSync(uploadsDir, { recursive: true });
        }

        const ext = path.extname(fileName) || ".mp4";
        const savedFileName = `ad-video${ext}`;
        const filePath = path.join(uploadsDir, savedFileName);
        fs.writeFileSync(filePath, fileData);

        const videoUrl = `/uploads/${savedFileName}`;
        await storage.upsertSetting("ad_video_url", videoUrl, "Ad video for home pages");

        res.json({ success: true, url: videoUrl });
      });
    } catch (error) {
      console.error("Upload video error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Serve uploaded files
  app.use("/uploads", (await import("express")).default.static(path.join(process.cwd(), "uploads")));

  return httpServer;
}
